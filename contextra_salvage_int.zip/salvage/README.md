# Salvage-Paket: sichere Teilmenge aus den Jules-Sitzungen

Enthalten sind 26 Dateien in 5 Gruppen. Jede Gruppe wird als ein Commit pro
Crate integriert. Das Skript schreibt nur auf einen neuen Branch, nicht auf main.

## Voraussetzungen
- git, bash 4 oder neuer (macOS: `brew install bash`), cargo mit Toolchain 1.89.0
  (wird ueber rust-toolchain.toml gewaehlt), Netzwerk fuer Crate-Downloads
- Repo muss auf HEAD e3493d29 oder einem Nachfolger stehen, in dem diese
  Dateien nicht geaendert wurden. Das Skript prueft das.

## Ausfuehren
    cd /pfad/zum/contextra
    git pull
    /pfad/zum/salvage/integrate.sh /pfad/zum/contextra

Das Skript
1. prueft: sauberer Arbeitsbaum, Basis vorhanden, keine Zieldatei seit der Basis geaendert,
2. legt den Branch restore/salvage-int-<zeitstempel> an,
3. kopiert je Gruppe die Dateien, fuehrt `cargo check --all-targets` und
   `cargo test --no-run` fuer das Crate aus und committet nur bei Gruen,
4. pusht den Branch nach origin.

Bei rotem Gate stoppt es mit Exit-Code 2, verwirft die Gruppe und hinterlaesst keine Reste.
Bei geaenderter Zieldatei stoppt es mit Exit-Code 1, ohne etwas zu schreiben.

## Danach
Pull Request von dem Branch nach main oeffnen. Nicht direkt nach main pushen,
solange CI nicht gruen ist.

Falls du trotzdem direkt auf main willst (nach gruenem Gate):
    git -C /pfad/zum/contextra checkout main
    git -C /pfad/zum/contextra merge --ff-only restore/salvage-int-<zeitstempel>
    git -C /pfad/zum/contextra push origin main

## Dateien
- files/                 Dateien mit Repo-Pfad
- groups/*.txt           Zuordnung Gruppe → Dateien
- messages/*.txt         Commit-Nachrichten je Gruppe
- integrate.sh           Integrationsskript
- EXCLUDED.md            Ausgeschlossene Aenderungen mit Begruendung
- OFFEN.md               Was dieses Paket nicht loest
- MANIFEST.sha256        Pruefsummen

## Hinweis zur Verifikation
Das Skript wurde nur mechanisch getestet (Klon, Bare-Remote, Platzhalter-cargo):
Vorpruefung, Commit-Reihenfolge, Push und beide Abbruchpfade. Ob die Dateien
kompilieren, ist NICHT geprueft. Das leistet erst das Gate in deinem Repo.
