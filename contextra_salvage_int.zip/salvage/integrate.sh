#!/usr/bin/env bash
# Integriert das Salvage-Paket in ein Contextra-Repo.
# Aufruf:  ./integrate.sh /pfad/zum/contextra
#
# Ablauf:
#  1. Prueft: Arbeitsbaum sauber, Basis e3493d29 ist Vorfahr von HEAD,
#     und keine Zieldatei wurde seit der Basis geaendert.
#  2. Legt Branch restore/salvage-int-<datum> an (main bleibt unberuehrt).
#  3. Je Gruppe (ein Commit pro Crate): Dateien kopieren, Gate ausfuehren,
#     bei Fehler Gruppe verwerfen und abbrechen.
#  4. Pusht den Branch. Merge nach main nur ueber Pull Request.
set -euo pipefail

PKG="$(cd "$(dirname "$0")" && pwd)"
REPO="${1:?Usage: $0 /pfad/zum/contextra}"
BASE=e3493d29df766e9ae3b47d41bc5611b03d6e29f7
BRANCH="restore/salvage-int-$(date +%Y%m%d-%H%M%S)"

cd "$REPO"

echo "== 1. Vorpruefung"
[ -z "$(git status --porcelain)" ] || { echo "FEHLER: Arbeitsbaum nicht sauber. Erst committen oder stashen."; exit 1; }
git fetch origin --quiet
git cat-file -e "$BASE^{commit}" 2>/dev/null || { echo "FEHLER: Basis $BASE nicht im Repo"; exit 1; }
git merge-base --is-ancestor "$BASE" HEAD || { echo "FEHLER: $BASE ist nicht Vorfahr von HEAD. Stand pruefen."; exit 1; }

ALLFILES=$(cat "$PKG"/groups/*.txt)
for f in $ALLFILES; do
  if ! git diff --quiet "$BASE" HEAD -- "$f" 2>/dev/null; then
    echo "FEHLER: $f wurde seit $BASE geaendert. Nicht automatisch ueberschreiben."
    echo "        Pruefe: git log $BASE..HEAD -- $f"
    exit 1
  fi
done
echo "   OK: Basis passt, keine Zieldatei geaendert."

echo "== 2. Branch $BRANCH"
git checkout -b "$BRANCH"

# name -> crate
declare -A CRATE=( [rank]=contextra-rank [privacy]=contextra-privacy [license]=contextra-license [store]=contextra-store [engine]=contextra-engine )
ORDER=(rank privacy license store engine)

for g in "${ORDER[@]}"; do
  echo "== 3. Gruppe $g (${CRATE[$g]})"
  FILES=$(cat "$PKG/groups/$g.txt")
  while read -r f; do
    mkdir -p "$(dirname "$f")"
    cp "$PKG/files/$f" "$f"
  done < "$PKG/groups/$g.txt"

  # Gate: Check + Testbinaries bauen (Ausfuehrung ist bewusst nicht Teil dieses Gates)
  if cargo check --locked -p "${CRATE[$g]}" --all-targets && \
     cargo test --locked -p "${CRATE[$g]}" --no-run; then
    echo "   Gate gruen"
  else
    echo "GATE ROT bei $g. Gruppe wird verworfen, Branch bleibt bei den bisherigen Commits."
    git checkout -- . 2>/dev/null || true
    # neue (untracked) Dateien dieser Gruppe entfernen
    for f in $FILES; do git ls-files --error-unmatch "$f" >/dev/null 2>&1 || rm -f "$f"; done
    exit 2
  fi

  git add -- $FILES
  git commit -q -F "$PKG/messages/$(ls "$PKG/messages" | grep -i "$g" | head -1)"
  echo "   Commit: $(git log -1 --oneline)"
done

echo "== 4. Ergebnis"
git log --oneline "$BASE"..HEAD
echo
echo "== 5. Push (nur Branch, nicht main)"
git push -u origin "$BRANCH"
echo
echo "Fertig. Naechster Schritt: Pull Request von $BRANCH nach main oeffnen."
