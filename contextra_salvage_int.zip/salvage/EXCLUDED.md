# Nicht enthalten: Dateien aus den Jules-Sitzungen und Begruendung

Die Sitzungen haben viele Dateien veraendert. Diese Liste nennt alles, was
bewusst NICHT im Paket ist. HEAD bleibt in diesen Bereichen unveraendert.

## Verbotene Aenderungen (Prompt-Regel 2)

| Bereich | Dateien | Grund |
|---|---|---|
| contextra-simd | src/dispatch.rs, src/lib.rs, src/kernels/{avx2,avx512,neon,mod}.rs, benches/simd_bench.rs | `unsafe`-Bloecke pro Datei stark erhoeht (avx2 37→138, avx512 29→140, neon 6→32), neue `#[allow(unsafe_code)]`. Umschreibung statt Restore. dispatch.rs identisch in zwei Sessions. |
| contextra-vector | hnsw/types.rs, hnsw/core_rebuild.rs, hnsw/mod.rs, persistence/*.rs, diskann/*.rs, hnsw/arena.rs, u.a. | Entfernt `zeroize` fuer Vektordaten und Knoten sowie den Aufruf in core_rebuild.rs. Gelöschte Vektoren blieben im RAM. Der unveraenderte Test hnsw_erasure_residue.rs ruft den entfernten Schalter auf. Tests geloescht (persistence −3, diskann −6). |
| contextra-store | src/lib.rs, src/wal/mod.rs | Entfernt `#[cfg(not(loom))]` und die Methode `truncate` im Loom-Mock. |
| contextra-store | tests/erasure_fence_scope.rs | Loescht Test `test_async_runtime_blocking_attempt_rejected`. |
| contextra-adapt | src/bandit.rs, tests/bandit_sherman_morrison_long_run_stability.rs | Algorithmus-Umbau (+246), Test −2. Kein Restore. |
| contextra-sandbox | src/{merge,lib,capabilities,executor,admission}.rs | Grosse Neuimplementierung (executor +320/−134), Test −2. Kein Restore. |

## Nicht freigegeben (Scope oder Abhaengigkeiten)

| Bereich | Dateien | Grund |
|---|---|---|
| contextra-db | alle Tests, src/multistep.rs, Cargo.toml | Tests auf andere API umgeschrieben. p08_forget_canary.rs: purge_tenant → forget_tenant (aendert einen Loeschtest). graph_hybrid_search.rs: PathRag → Hops, sufficiency_threshold entfernt. Cargo.toml bringt neue Abhaengigkeiten (Cargo.lock-Aenderung noetig). |
| contextra-mvcc | Cargo.toml, tests/pin_policy_tests.rs, tests/ssi_metrics_observability.rs | Neue Dev-Dependency auf contextra-testkit. Layering-/Lockfile-Entscheidung, keine reine Restore-Aenderung. |
| contextra-rank | dibud/{state,types}.rs, drift.rs, fusion/rrf.rs, calibration/{isotonic,platt}.rs, tests/calibration_*.rs, isotonic_ece_rebuild.rs, rrf_two_phase_scaling.rs, j12closure-*.rs | Verhaltensaenderungen (rrf +171/−53) bzw. Interna eines Tier-D-Moduls. Ungeprueft. Die j12closure-*-Dateien duplizieren j12_*. |
| contextra-text | src/tokenizer.rs | Neues `pub const PROTECTED_PATTERN` erweitert die Sichtbarkeit (Regel 2). |
| Root | benches/competitive_bench.rs | Liegt in keiner Stufe. |
| Root | Cargo.lock (in allen drei Archiven) | Inhaltlich identisch zu HEAD. Nicht noetig. |

## Ergaenzt: enthaltene Dateien mit Vorbehalt

- contextra-rank `calibration/conformal.rs`: `new()` ruft jetzt `with_bounds()` auf. Gleiches Verhalten fuer Default-Werte, die Validierung laeuft aber zusaetzlich. Bitte mit dem Gate-Lauf bestaetigen.
