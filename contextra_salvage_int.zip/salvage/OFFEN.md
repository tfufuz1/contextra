# Was dieses Paket NICHT loest

Nach Integration bleiben im HEAD (e3493d29) folgende Probleme, die in den
Reviews stehen oder neu gefunden wurden:

1. `cargo test` im Root bricht weiter: `crates/contextra/tests/wiring_matrix.rs:48`
   ruft `contextra::wiring_selftest` auf, das Modul ist nicht deklariert.
   Entscheidung noetig: Modul einbinden und verdrahten, oder Test und Modul entfernen.
2. Feature `entity-extraction` ist kaputt: `crate::extraction` fehlt seit fed037d6.
   Default-Build nicht betroffen.
3. contextra-vector/src/diskann/ (12 Dateien) ist nicht deklariert. Feature
   `experimental-diskann` ist wirkungslos, nutzende Tests brechen mit dem Feature.
4. Auto-Extraktion-Registry (F2) unveraendert. Fix: geteiltes Arc<RwLock<...>>
   im Collection-Clone, nicht das einfache Feld aus dem Architektur-Review.
5. Failpoint-Statics in store/wal/mod.rs (F3) unveraendert.
6. contextra-rank dibud-Interna: nur das Feature-Gating ist enthalten.
7. contextra-db, contextra-mvcc, contextra-sandbox, contextra-adapt, contextra-simd
   und contextra-vector sind nicht im Paket. Ihre Restore-Arbeit muss gesondert
   und ohne Verbotsverletzungen erfolgen.
