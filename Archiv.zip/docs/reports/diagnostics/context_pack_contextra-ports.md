# Agentic Context Pack: `contextra-ports`

> **Werkzeug:** `agentic_context_pack.py`  
> **Erstellungszeit:** `2026-11-07T23:15:52.939032+00:00`  
> **Status/Befunde:** `1 Befunde erfasst`  

## Beschreibung
Curated, minified context pack for coding agents assigned to `contextra-ports`. Optimized for LLM window density and context engineering.

## Metriken-Übersicht
| Metrik | Wert |
|---|---|
| `crate_name` | `contextra-ports` |
| `ring` | `Unknown` |
| `class` | `Standard` |

## 1. Architektur-Zuweisung
- **Crate:** `contextra-ports`
- **Ring:** `None`
- **Rolle/Klasse:** `None`
- **Pfad:** `crates/contextra-ports`

## 2. Crate-Spezifische AGENTS.md Verträge
# AGENTS.md — `contextra-ports`

> **Ring 0** · Klasse `[K]` · Reifegrad `stable` · Unsafe: nein · Rolle: einzige Vertragsschicht des Baukastens. Alle Austausch-Traits (Ports) und deren Test-/Konformitätsmittel.
> Gemeinsame Regeln stehen in der Root-`AGENTS.md`. Stand 2026-11-07, statisch gelesen, nicht kompiliert.

## 1. Baukasten-Profil

| Aspekt | Wert |
|---|---|
| Standalone-Build | `cargo build -p contextra-ports --no-default-features --locked` |
| Contextra-Abhängigkeiten (Ist = Soll) | `contextra-types` |
| Externe Abhängigkeiten | `futures-util`, `blake3`, `bytes`, `serde`, `serde_json`, `ahash`, `thiserror` (dev: `proptest`, `tokio`) |
| Features | `contract-tests`, `testkit`; `default = []` |
| Lints | `#![forbid(unsafe_code)]`, `#![warn(missing_docs)]` |
| Re-Export | `pub use contextra_types::*;` (alle `types` erscheinen auch als `ports::…`) |

## 2. Abhängigkeiten

Nur `contextra-types`. Ports kennen **keine** konkrete Implementierung und **kein** Crate oberhalb von Ring 0. Ein Trait mit Austauschrolle außerhalb dieses Crates ist unzulässig (SPEC §4.4 Regel 9).

## 3. Modul-Karte (am Code verifiziert)

| Modul | Port / Inhalt | Anmerkung |
|---|---|---|
| `storage.rs` | `StorageEngine` (27 `BoxFuture`-Methoden), `StorageStats` | async-Grenze (siehe §6) |
| `vector_index.rs`, `text_index.rs`, `graph_index.rs`, `graph.rs` | `VectorIndex`, `TextIndex`, `GraphIndex`, Graph-Mutation | |
| `vfs.rs` | `Vfs`, `VfsFile`, `VfsOpenOptions`, `VerifiedVia` | **synchron** (siehe Root-§10 K1) |
| `clock.rs`, `rng.rs`, `id_gen.rs` | `Clock`/`SystemClock`, `Rng`/`SeededRng`, `IdGen`/`SequentialIdGen` | Umgebungs-Ports (M4) |
| `metrics.rs`, `observability.rs`, `observer.rs`, `lifecycle.rs` | `MetricsSink`, `NoopMetricsSink`, `InMemoryMetricsSink` | |
| `scanner/` (`layer`, `session`, `witness`, `mod`) | `Purger`, `LayerScanner`, `ScanSession`, `LayerWitness`, `ScanTarget`, `WitnessLayer`, `PurgeStats` | Bereinigungs-/Mess-Ports (M7) |
| `erasure.rs`, `gate.rs`, `ledger.rs`, `keys.rs`, `report_signer.rs` | `ErasureLayer`, `StorageBackend`, `ErasureTarget`, `ReadGate`, `LedgerSink`, `RecordSealer`, `FileKeyring`, `ReportSigner` | Löschdomäne: Dopplungen siehe §7 |
| `embedding.rs`, `reranker.rs`, `query_rewriter.rs`, `attention.rs`, `kv.rs`, `kv_bridge_port.rs` | Embedder, Reranker, Query-Rewriter, KV-Ports | Rand-Fähigkeiten, Zuordnung zu Archiv-/Randcrates |
| `checkpoint.rs`, `barrier.rs` | `Checkpoint`, `CheckpointCoordinator`, Barrieren | |
| `license.rs`, `plugin.rs` | `LicenseGate`; `plugin` ist laut SPEC `TEST_ONLY` | |
| `conformance.rs`, `contract_tests.rs` | Verdrahtungsmatrix; Konformitätssuite hinter `contract-tests` | Basis für Fremdadapter |

## 4. Verträge & Invarianten

1. **Nur Verträge.** Keine konkreten Implementierungen im Produktionscode. Ausnahmen mit Begründung: `SystemClock`, `SeededRng`, `SequentialIdGen`, `NoopMetricsSink`, `InMemoryMetricsSink` als Referenz-/Null-Objekte.
2. **`SystemClock` ist die einzige zulässige Stelle für `Instant::now`/`SystemTime::now`.** Sie trägt lokal `#[allow(clippy::disallowed_methods)]` (`clock.rs`); `governance/determinism-allow.toml` führt nur `thread_rng`-Ausnahmen. Jede weitere Nutzung in diesem Crate ist ein Defekt.
3. **Neue Trait-Methoden brauchen eine Default-Implementierung**, die `CapabilityUnsupported` liefert, und einen Test, der beweist, dass der Default **nicht** still greift. Sonst bricht jeder Fremdimplementierer (M3, REQ-PORT-4).
4. **Keine internen Fremdtypen in Signaturen.** Nur `types`, eigene Typen oder generische Parameter (G2: „keine Lecks interner Crate-Typen in Port-Signaturen“).
5. **`LayerWitness` hat keinen öffentlichen Konstruktor und kein `Default`** (INV-WITNESS-MINT-1). Er entsteht nur in `ScanSession::finish` nach bestandener Positivkontrolle. `compile_fail`-Doctests sichern das; sie dürfen nicht entfernt werden.
6. **Sicherheits-Ports** (`governance/security_ports.toml`: u. a. `Vfs`, `LayerScanner`, `Purger`, `KmsProvider`) dürfen in Produktion nie Null-/Accept-All-Implementierungen haben (INV-WIRING-2). **Achtung:** die dortigen `trait_path`-Angaben (`contextra_ports::kms::…`, `::purger::Purger`, `::log::DurableLog`, `::journal::ErasureJournal`) und `prod_impl`-Pfade (`contextra_store::vfs::StdVfs`, `…::sidecar::*`) existieren im Code **nicht**; reale Pfade z. B. `contextra_ports::scanner::Purger`. Die Datei ist zu korrigieren (WP 2.2/7).
7. **Semver-Disziplin (REQ-PORT-4).** Port-Signaturen sind eingefroren. Eine inkompatible Änderung verlangt neue Port-Version, Migrationsregel und ADR. Prüfe mit `cargo public-api`.
8. **Objekt-Sicherheit.** Austausch-Traits, die als `dyn` genutzt werden, bleiben dyn-kompatibel (Rückgabe `BoxFuture`, keine generischen Methoden ohne `where Self: Sized`).

## 5. Ports (Übersicht der Verantwortung)

**Definiert:** alle Ports aus §3. **Implementiert:** nur die Referenzobjekte aus §4.1. **Konsumiert:** `contextra-types`.

**Fehlend laut PLAN/SPEC (Soll, noch nicht im Code):** `EgressPolicy` (WP 2.4; `privacy` kennt bisher nur `BlockReason::EgressPolicyDenied`). `KmsProvider` liegt noch in `crypto/src/wal_crypto.rs:32` und soll hierher (SPEC §5.2), `security_ports.toml` setzt das bereits voraus. `DurableLog`, `ErasureJournal`, `EffaceableKeySlot`, `ErasedSetMirror`, `GroupRevocationListener` sind hier **nicht** als Traits zu finden (gegen `grep -rn "trait <Name>"` prüfen, bevor du sie benutzt).

## 6. Nebenläufigkeit & Performance

- `StorageEngine` ist die **async-Grenze** (`BoxFuture`). Zielbild (SPEC §6): `StorageRead` synchron, `StorageWrite` async. Diese zwei Traits existieren **noch nicht** (`.agents/rules/async-io.md` setzt sie fälschlich voraus). Neue Ports sind **synchron**, es sei denn, ein Netz- oder Laufzeit-Bezug ist belegt (M8).
- `Vfs` bleibt synchron; blockierende Aufrufer in async-Kontext nutzen `spawn_blocking`.
- Hot-Path-Ports (`VectorIndex::search`, `StorageRead::get`) werden von Konsumenten **generisch** gebunden (Monomorphisierung), nicht als `dyn`. Cold-Path-Ports (`Purger`, `LayerScanner`, `ReportSigner`) dürfen `dyn` sein.
- Ratchet: die 4 `async fn` und die `BoxFuture`-Nutzung in `ports` dürfen nicht steigen (REQ-ASYNC-1).

## 7. Anti-Patterns

- **Zweite Typfamilie für ein Konzept.** Verifiziert doppelt: `LayerWitness` (`erasure.rs:183`, `scanner/witness.rs:17`), `LayerId` und `EraseTarget` (auch in `types`). Neue Nutzung nur über `scanner::*`; Vereinigung per ADR (WP 2.2).
- **Trait ohne Contract-Test.** Jeder Port in `contract_tests.rs` (aktuell `Clock`, `Rng`, `Vfs`, `MetricsSink`) bekommt eine generische Konformitätsfunktion; Lücken: `StorageEngine`, `VectorIndex`, `TextIndex`, `GraphIndex`, `Purger`, `LayerScanner` (WP 2.5).
- **`Vfs` zu `async_trait` umbauen** (PLAN-Snippet ist veraltet, Root-§10 K1).
- **Konkrete Engine-Typen in Signaturen** (`LsmStorage`, `HnswIndex`).
- **`Default`-Implementierung, die still `Ok(())` liefert** für sicherheitsrelevante Methoden.

## 8. Tests & Messung

```bash
cargo test -p contextra-ports --locked
cargo test -p contextra-ports --locked --features contract-tests
cargo test -p contextra-ports --doc            # compile_fail-Beweise für Witness-Mint
cargo clippy -p contextra-ports --all-targets -- -D warnings
```

- Fremdadapter (`testkit`, `store`, `vector`, `text`, `graph`) rufen die Konformitätsfunktionen aus `contract_tests` und `conformance` auf.
- Property-Tests für `SeededRng`-Determinismus und `ManualClock`-Verhalten liegen in `contextra-testkit`.

## 9. Offene Arbeit

| WP | Inhalt |
|---|---|
| 2.1 | `Vfs` auf Streaming/Handle-Operationen konsolidieren (`read_at`, `write_at`, `sync_data`, `sync_all` sind in `VfsFile` vorhanden, Vereinheitlichung der zwei historischen Vfs-Konzepte, D7) |
| 2.2 | `Purger`/`LayerScanner`-Signaturen entscheiden (Root-§10 K2), doppelte Löschtypen vereinen (K3) |
| 2.3 | `StorageEngine`/`VectorIndex`/`TextIndex`/`GraphIndex` bereinigen, `StorageRead`/`StorageWrite` trennen |
| 2.4 | Port `EgressPolicy` einführen |
| 2.5 | Contract-Tests auf alle Ports erweitern |


---


# Kommentar-Syntax (verbindlich)

| Form | Zweck |
|---|---|
| `//!` | Modul-/Crate-Doku am Dateianfang (vor jedem Item, nach `#![...]`-Attributen der Datei; nie mitten in der Datei) |
| `///` | Rustdoc für das **direkt folgende** Item (Struct, Enum, Variante, Feld, Trait, Methode, Funktion, Konstante). Nie vor `let`, Ausdrücken, Match-Armen oder Makroaufrufen; dort `//` verwenden. |
| `// NOTE:` | Warum etwas so gebaut ist (nicht was) |
| `// TODO:` / `// FIXME:` / `// STUB:` | Offene Arbeit / bekanntes Risiko / Platzhalter; immer mit konkreter Aussage |
| `// SAFETY:` | Pflicht direkt über jedem unsafe-Konstrukt (Invariante, Herstellungsort, Folge bei Verletzung) |
| `// ANCHOR[contextra-ports:<BEREICH>-<NNN>]` | Sprungmarke; vor dem Item/Abschnitt, auf den sie zeigt |
| `// FILE-CONTEXT` + `// ZWECK:` / `// INVARIANTEN:` / `// HOTSPOTS: <von>-<bis>` / `// STAND: <Datum>` | Repo-Konvention für den Dateikopf. Vorhandene Blöcke ergänzen; `HOTSPOTS`-Zeilenbereiche nach dem Kommentieren auf die neuen Zeilennummern aktualisieren. `STAND` auf das heutige Datum setzen, wenn du den Block änderst. |

Weitere Tags führst du nicht ein. Beim Kommentieren markierter Altlasten gilt: `// NOTE: Deprecated Debt DEBT-NN – <Beschreibung>`.

## ANCHOR-Ids (Kollisionsschutz)

Im Repo existieren ca. 3.900 Anchors; Ids sind workspace-weit eindeutig zu halten. Format: `ANCHOR[contextra-ports:<BEREICH>-<NNN>]` mit `<BEREICH>` in Großbuchstaben/Ziffern/Bindestrichen, `<NNN>` dreistellig. Vorgehen:

1. Vor jeder neuen Id: `grep -rnF "ANCHOR[contextra-ports:<BEREICH>-<NNN>]" crates benchmarks` muss leer sein.
2. Nummeriere ab dem Maximum des Bereichs weiter. Höchste bestehende Nummern in dieser Crate:

| Bereich | Höchste Nr. | Nächste freie Id |
|---|---:|---|
| – | – | – |

3. Neue Bereiche nach dem Modul benennen (z. B. `WAL`, `PUT`, `GATE`); fange bei `001` an, nach Prüfung 1. Setze Anchors sparsam: pro Modul, pro öffentlichem Einstiegspunkt und pro nicht-trivialem Ablauf, nicht pro Zeile.
4. Bereits vorhandene doppelte Ids anderer Stellen nicht „reparieren“; nur im Report melden.

Für Abläufe in Funktionen nutze nummerierte Schritte:

```rust
// ANCHOR[contextra-ports:PUT-001]
// Ablauf von `put`:
// 1. Eingabe prüfen (Länge, Schlüsselformat).
// 2. Snapshot der Transaktion nehmen.
// 3. Eintrag ins WAL schreiben und mit fsync bestätigen; ein Fehler wird zurückgegeben (Fail-Closed).
// 4. Erst danach im Speicher übernehmen.
```

# Was zu dokumentieren ist

Gehe **jede** Rust-Datei unter `crates/contextra-ports` durch (`find crates/contextra-ports -name "*.rs"`, ohne die generierten Dateien oben) einschließlich `tests/`, `benches/`, `examples/` und `build.rs`:

- **Modul** (`//!`): Zweck, Ring-Zugehörigkeit, Nutzer, wichtigste Typen, Invarianten, Verweis auf Nachbarmodule.
- **Öffentliche Items:** Zweck in einem Satz, dann bei Bedarf `# Errors` (welcher Fehler wann), `# Panics` nur wenn der Code abbrechen kann (sollte nach Zero-Panic-Regel nicht vorkommen: dann `FIXME`), `# Safety` bei `unsafe fn`, Vorbedingungen, Nachbedingungen, Nebenwirkungen (I/O, Zeit, Zufall, IDs). Zeit, Zufall und IDs laufen nur über `Clock`/`Rng`/`IdGen`; steht es im Code, steht es im Kommentar.
- **Nicht-triviale private Funktionen:** Warum sie existieren und was sie garantieren.
- **Nebenläufigkeit:** Sperren, atomare Operationen, Reihenfolge, Warum kein Deadlock.
- **Persistenz und Fehler:** Wo Daten WAL oder Dateisystem-Port passieren; `fsync`-Fehler werden propagiert.
- **Tests:** Ein Satz je Testfunktion oder -block: welche Invariante oder welches Verhalten bewiesen wird.
- **Architektur:** Welche Ports die Crate nutzt/anbietet, welche Abhängigkeitsrichtung gilt (DAG, `may_depend_on`), was bewusst *nicht* hier liegt.

## Rustdoc-Fallen (jeder Punkt bricht sonst `cargo clippy -D warnings` oder `cargo doc`)

- Kein `///` vor Nicht-Items (`unused_doc_comments`); keine Leerzeile zwischen `///` und Item (`empty_line_after_doc_comments`).
- Fortsetzungszeilen in Listen und Zitaten korrekt einrücken (`doc_lazy_continuation`). **Vier Leerzeichen Einrückung in Doc-Text erzeugen einen Doctest**; Code immer in Fences mit Sprache. Beispiele, die nicht kompilieren oder laufen sollen: `ignore` oder `text`, begründet.
- Intra-Doc-Links `[`Typ`]` nur auf existierende, erreichbare Items; spitze Klammern im Text (`Vec<u8>`) in Backticks setzen, sonst „unclosed HTML tag“.
- `// SAFETY:` ohne Leerzeile und ohne dazwischenliegende Zeilen direkt über dem unsafe-Ausdruck.
- Doc-Beispiele müssen gegen die tatsächliche Signatur kompilieren; im Zweifel `no_run`/`ignore` mit Grund.

## 3. Bekannte Technische Schulden (DEPRECATED_DEBT.md)
- - **Beschreibung:** Ursprünglich war die mehrstufige Löschlogik (Saga, Gate, Vault, Journal, Witness, Audit Reports) hart in den Speicher- und Indexkernen verdrahtet. Dies führte zu über 660 verstreuten Fundstellen von Lösch- und Rechts-Relikten in an sich neutralen Datenstrukturen.
- - **Migrationsanweisung für Speicherkerne:** Speicherkerne implementieren ausschließlich minimale, neutrale Bereinigungs-Ports (`Purger`, `LayerScanner` in `contextra-ports`). Alle direkten Abhängigkeiten zu Deletion-Proofs, Audit-Trails und DSGVO-Kontexten werden entfernt.
- - **Beschreibung:** `contextra-core` fungiert derzeit als Re-Export-Hülle für ausgelagerte Typen nach `contextra-types`, `contextra-ports` und `contextra-mvcc`.
- - **Status:** ERLEDIGT (Paket B31). Alle Konsumenten wurden auf `contextra-types`, `contextra-ports` und `contextra-mvcc` migriert und `contextra-core` wurde aus dem Workspace entfernt.
- - **Zielarchitektur:** Entkopplung über Inversion of Control. Crates akzeptieren generische Parameter `T: StorageEngine` oder `T: VectorIndex` aus `contextra-ports`.
- | **DEBT-03** | Phase 1 & 6 | `contextra-types` / `ports` | **ERLEDIGT (Paket B31)**: `contextra-core` vollständig dekommissioniert und entfernt. |
- | **DEBT-04** | Phase 2 & 5 | `contextra-ports` | Keine konkreten Cross-Engine-Importe in Engines. |

## 4. Öffentliche Schnittstellen & Signaturen (lib.rs)
```rust
pub use contextra_types::{
pub type BoxFuture<'a, T> = Pin<Box<dyn Future<Output = T> + Send + 'a>>;
pub type BoxStream<'a, T> = Pin<Box<dyn futures_util::stream::Stream<Item = T> + Send + 'a>>;
pub mod attention;
pub mod checkpoint;
pub mod clock;
pub mod conformance;
pub mod embedding;
pub mod graph;
pub mod graph_index;
pub mod id_gen;
pub mod kv;
pub mod kv_bridge_port;
pub mod license;
pub mod lifecycle;
pub mod metrics;
pub mod observability;
pub mod plugin;
pub mod query_rewriter;
pub mod reranker;
pub mod rng;
pub mod scanner;
pub mod storage;
pub mod text_index;
pub mod vector_index;
pub mod vfs;
pub mod env;
pub mod fs;
pub mod index;
pub mod inference;
pub mod policy;
pub mod erasure_legacy;
pub use attention::*;
pub use checkpoint::*;
pub use clock::*;
pub use conformance::*;
pub use embedding::*;
pub use graph::*;
pub use graph_index::*;
pub use id_gen::*;
pub use kv::*;
pub use kv_bridge_port::*;
pub use license::*;
pub use lifecycle::*;
pub use metrics::*;
pub use observability::*;
pub use plugin::*;
pub use query_rewriter::*;
pub use reranker::*;
pub use rng::*;
```

## Detaillierte Befunde
| Crate | Datei | Zeile | Art / Beschreibung |
|---|---|---|---|
| `contextra-ports` | `crates/contextra-ports/Cargo.toml` | `1` | Generated focused context pack for contextra-ports |

---
*Automatisch generiert durch `agentic_context_pack.py` für Agentic Engineering & Context Auditing.*