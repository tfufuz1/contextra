//! # Kryptographisches Shredding für KV-Daten (`kv_shredding.rs`)
//!
//! Ermöglicht kryptografische Bereinigung einzelner Datensätze oder ganzer Mandantengruppen
//! durch gezielte Zerstörung des zugehörigen kryptographischen Schlüssels (Crypto-Erase).
//!
//! ## Invarianten
//! - Nach Zerstörung des Schlüssels ist der Chiffretext unentschlüsselbar.
//! - Gruppe und Einzelschlüssel-Hierarchie erlauben feingranulares Shredding.

// FILE-CONTEXT
// ZWECK: Envelope Encryption und Key-Registry für KV-Crypto-Shredding (AP-P0-06, Spec v17 §16.1).
// INVARIANTEN: CryptoShred vernichtet KEK (Gruppenbereinigung) oder DEK-Wrap (Einzelbereinigung) in O(1).
// Zufälliges KEK/DEK-Material via OsRng (keine deterministische Ableitung rein aus group_id).
// HOTSPOTS: [SubKey, KeyRegistry, revoke_group, revoke_record, encrypt_record, decrypt_record]

//! Envelope encryption and thread-safe key registry for KV crypto-shredding.

#![forbid(unsafe_code)]

use crate::crypto::KeyManager;
use crate::error::{CryptoError, Result};
use crate::revocation_log::{RevocationLog, RevocationTarget};
use aes_gcm_siv::{
    aead::{Aead, KeyInit},
    Aes256GcmSiv, Nonce,
};
use ahash::{AHashMap, AHashSet};
use rand::RngCore;
use serde::{Deserialize, Serialize};
use std::sync::RwLock;
use zeroize::{Zeroize, ZeroizeOnDrop};

/// Default size of a shred key group (number of records sharing one KEK).
pub const DEFAULT_SHRED_KEY_GROUP_SIZE: usize = 64;

/// Sub-key or KEK bytes (256 bits) zeroized on drop.
#[derive(ZeroizeOnDrop)]
pub struct SubKey(pub [u8; 32]);

impl Clone for SubKey {
    fn clone(&self) -> Self {
        Self(self.0)
    }
}

impl std::fmt::Debug for SubKey {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("SubKey")
            .field("bytes", &"***REDACTED***")
            .finish()
    }
}

/// Group Key Encryption Key (KEK) - 256 bits, zeroized on drop.
#[derive(ZeroizeOnDrop)]
pub struct GroupKek(pub [u8; 32]);

impl std::fmt::Debug for GroupKek {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("GroupKek")
            .field("bytes", &"***REDACTED***")
            .finish()
    }
}

/// Record Data Encryption Key (DEK) - 256 bits, zeroized on drop.
#[derive(ZeroizeOnDrop)]
pub struct RecordDek(pub [u8; 32]);

impl std::fmt::Debug for RecordDek {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("RecordDek")
            .field("bytes", &"***REDACTED***")
            .finish()
    }
}

/// Container for an encrypted record payload under Envelope Encryption.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Zeroize)]
#[zeroize(drop)]
pub struct EncryptedRecordPayload {
    /// Unique identifier for the record.
    pub record_id: u64,
    /// Shred group identifier to which this record belongs.
    pub group_id: u64,
    /// AES-256-GCM-SIV encrypted record data.
    pub ciphertext: Vec<u8>,
    /// 12-byte initialization vector (nonce) for payload decryption.
    pub nonce: [u8; 12],
    /// DEK wrapped with Group KEK.
    pub wrapped_dek: Vec<u8>,
    /// 12-byte initialization vector (nonce) for DEK unwrapping.
    pub dek_nonce: [u8; 12],
}

#[derive(Debug)]
struct RecordDekEntry {
    wrapped_dek: Vec<u8>,
    dek_nonce: [u8; 12],
    revoked: bool,
}

#[derive(Debug)]
struct GroupEntry {
    kek: GroupKek,
    wrapped_kek: Vec<u8>,
    kek_nonce: [u8; 12],
    record_deks: AHashMap<u64, RecordDekEntry>,
}

/// Derives or retrieves a random sub-key (Group KEK) for a shred group via `KeyRegistry`.
pub fn derive_subkey(
    registry: &KeyRegistry,
    master_key: &KeyManager,
    group_id: u64,
) -> Result<SubKey> {
    registry.get_or_derive(master_key, group_id)
}

/// In-memory thread-safe registry for envelope KV crypto-shredding keys.
#[derive(Debug, Default)]
pub struct KeyRegistry {
    groups: RwLock<AHashMap<u64, GroupEntry>>,
    revoked_groups: RwLock<AHashSet<u64>>,
    pub revocation_log: Option<std::sync::Arc<RevocationLog>>,
}

impl KeyRegistry {
    /// Creates a new empty `KeyRegistry`.
    pub fn new() -> Self {
        Self {
            groups: RwLock::new(AHashMap::new()),
            revoked_groups: RwLock::new(AHashSet::new()),
            revocation_log: None,
        }
    }

    /// Attaches an optional `RevocationLog` to check for persisted key/group revocations,
    /// syncing any previously logged revocations into `revoked_groups` and purging RAM keys.
    pub fn with_revocation_log(mut self, log: std::sync::Arc<RevocationLog>) -> Self {
        if let Ok(mut revoked_guard) = self.revoked_groups.write() {
            if let Ok(mut groups_guard) = self.groups.write() {
                for target in log.revoked_targets() {
                    if let RevocationTarget::Group(group_id) = target {
                        revoked_guard.insert(group_id);
                        if let Some(mut entry) = groups_guard.remove(&group_id) {
                            entry.kek.0.zeroize();
                            entry.wrapped_kek.zeroize();
                            for (_, mut rec) in entry.record_deks.drain() {
                                rec.wrapped_dek.zeroize();
                            }
                        }
                    }
                }
            }
        }
        self.revocation_log = Some(log);
        self
    }

    /// Retrieves the wrapped KEK and nonce for a group, if available and active.
    pub fn get_wrapped_kek(&self, group_id: u64) -> Option<(Vec<u8>, [u8; 12])> {
        if self.is_group_revoked(group_id) {
            return None;
        }
        let read_guard = self.groups.read().ok()?;
        let entry = read_guard.get(&group_id)?;
        Some((entry.wrapped_kek.clone(), entry.kek_nonce))
    }

    /// Retrieves the wrapped DEK and nonce for a record, if available and active.
    pub fn get_wrapped_dek(&self, group_id: u64, record_id: u64) -> Option<(Vec<u8>, [u8; 12])> {
        if self.is_group_revoked(group_id) {
            return None;
        }
        let read_guard = self.groups.read().ok()?;
        let entry = read_guard.get(&group_id)?;
        let rec = entry.record_deks.get(&record_id)?;
        if rec.revoked {
            return None;
        }
        Some((rec.wrapped_dek.clone(), rec.dek_nonce))
    }

    /// Checks if a group is revoked.
    pub fn is_group_revoked(&self, group_id: u64) -> bool {
        if let Some(ref log) = self.revocation_log {
            if log.is_revoked(&RevocationTarget::Group(group_id)) {
                return true;
            }
        }
        if let Ok(guard) = self.revoked_groups.read() {
            guard.contains(&group_id)
        } else {
            true
        }
    }

    /// Retrieves or generates a random Group KEK for `group_id`.
    /// Returns `Err(CryptoError::KeyRevoked(...))` if `group_id` has been revoked/shredded.
    pub fn get_or_derive(&self, master_key: &KeyManager, group_id: u64) -> Result<SubKey> {
        if self.is_group_revoked(group_id) {
            return Err(CryptoError::KeyRevoked(format!(
                "Shred group {group_id} has been revoked and cannot be accessed"
            )));
        }

        {
            let read_guard = self
                .groups
                .read()
                .map_err(|_| CryptoError::Crypto("KeyRegistry read lock poisoned".to_string()))?;
            if let Some(entry) = read_guard.get(&group_id) {
                return Ok(SubKey(entry.kek.0));
            }
        }

        let mut write_guard = self
            .groups
            .write()
            .map_err(|_| CryptoError::Crypto("KeyRegistry write lock poisoned".to_string()))?;

        if self.is_group_revoked(group_id) {
            return Err(CryptoError::Crypto(format!(
                "Shred group {group_id} has been revoked and cannot be accessed"
            )));
        }

        if let Some(entry) = write_guard.get(&group_id) {
            return Ok(SubKey(entry.kek.0));
        }

        // Generate a random 32-byte Group KEK (never derived from group_id)
        let mut kek_bytes = [0u8; 32];
        rand::rngs::OsRng.fill_bytes(&mut kek_bytes);

        // AEAD wrap the KEK using Master Key
        let (wrapped_kek, kek_nonce) = master_key.encrypt_auto_nonce(&kek_bytes)?;

        let entry = GroupEntry {
            kek: GroupKek(kek_bytes),
            wrapped_kek,
            kek_nonce,
            record_deks: AHashMap::new(),
        };

        write_guard.insert(group_id, entry);
        Ok(SubKey(kek_bytes))
    }

    /// Revokes (destroys) the Group KEK for `group_id` (Group Deletion / Group Crypto-Shredding).
    ///
    /// # Crash Semantics & Atomic Logging
    /// 1. If a `RevocationLog` is configured, the revocation is written to durable log storage FIRST.
    ///    If logging fails, the key in RAM is NOT revoked or modified, and the error is returned.
    /// 2. If logging succeeds (or if no log is attached), key material is zeroized and purged from RAM,
    ///    and `group_id` is recorded in `revoked_groups`.
    /// 3. Crash recovery semantics: Should a crash occur between durable log append and RAM zeroization,
    ///    recovery via `with_revocation_log` at startup reloads the log and idempotently completes
    ///    the revocation (purging RAM keys and updating revoked group tracking).
    pub fn revoke_group(&self, group_id: u64) -> Result<bool> {
        if self.is_group_revoked(group_id) {
            return Ok(false);
        }

        // Step 1: Durable log write first if RevocationLog is present
        if let Some(ref log) = self.revocation_log {
            log.append(RevocationTarget::Group(group_id))?;
        }

        // Step 2: Update RAM state & zeroize key material
        let mut revoked_guard = self
            .revoked_groups
            .write()
            .map_err(|_| CryptoError::Crypto("KeyRegistry write lock poisoned".to_string()))?;

        if revoked_guard.contains(&group_id) {
            return Ok(false);
        }

        revoked_guard.insert(group_id);

        let mut groups_guard = self
            .groups
            .write()
            .map_err(|_| CryptoError::Crypto("KeyRegistry write lock poisoned".to_string()))?;

        if let Some(mut entry) = groups_guard.remove(&group_id) {
            entry.kek.0.zeroize();
            entry.wrapped_kek.zeroize();
            for (_, mut rec) in entry.record_deks.drain() {
                rec.wrapped_dek.zeroize();
            }
        }

        Ok(true)
    }

    /// Revokes (destroys) the Group KEK for `group_id` in O(1). Alias for `revoke_group`.
    pub fn revoke_subkey(&self, group_id: u64) -> Result<bool> {
        self.revoke_group(group_id)
    }

    /// Revokes (destroys) the DEK wrap for a single record within `group_id` (Single Record Deletion).
    /// Leaves neighbor records in the same group intact and decryptable.
    pub fn revoke_record(&self, group_id: u64, record_id: u64) -> bool {
        if self.is_group_revoked(group_id) {
            return false;
        }

        if let Ok(mut groups_guard) = self.groups.write() {
            if let Some(entry) = groups_guard.get_mut(&group_id) {
                if let Some(rec) = entry.record_deks.get_mut(&record_id) {
                    if !rec.revoked {
                        rec.revoked = true;
                        rec.wrapped_dek.zeroize();
                        return true;
                    }
                }
            }
        }
        false
    }

    /// Returns `true` if `group_id` has an active KEK and is not revoked.
    pub fn is_group_active(&self, group_id: u64) -> bool {
        !self.is_group_revoked(group_id)
            && self
                .groups
                .read()
                .map(|g| g.contains_key(&group_id))
                .unwrap_or(false)
    }

    /// Returns `true` if `group_id` has an active sub-key in the registry.
    pub fn is_key_active(&self, group_id: u64) -> bool {
        self.is_group_active(group_id)
    }

    /// Returns `true` if `record_id` in `group_id` is active and not revoked.
    pub fn is_record_active(&self, group_id: u64, record_id: u64) -> bool {
        if self.is_group_revoked(group_id) {
            return false;
        }
        if let Ok(groups_guard) = self.groups.read() {
            if let Some(entry) = groups_guard.get(&group_id) {
                if let Some(rec) = entry.record_deks.get(&record_id) {
                    return !rec.revoked;
                }
            }
        }
        false
    }

    /// Encrypts a record using Envelope Encryption (Random KEK per group, Random DEK per record).
    pub fn encrypt_record(
        &self,
        master_key: &KeyManager,
        group_id: u64,
        record_id: u64,
        plaintext: &[u8],
    ) -> Result<EncryptedRecordPayload> {
        let subkey = self.get_or_derive(master_key, group_id)?;
        let kek_cipher = Aes256GcmSiv::new_from_slice(&subkey.0)
            .map_err(|e| CryptoError::Crypto(format!("Aes256GcmSiv KEK init failed: {e}")))?;

        let mut dek_bytes = [0u8; 32];
        rand::rngs::OsRng.fill_bytes(&mut dek_bytes);

        let mut dek_nonce = [0u8; 12];
        rand::rngs::OsRng.fill_bytes(&mut dek_nonce);
        let wrapped_dek = kek_cipher
            .encrypt(Nonce::from_slice(&dek_nonce), dek_bytes.as_slice())
            .map_err(|e| CryptoError::Crypto(format!("DEK wrapping failed: {e}")))?;

        let dek_cipher = Aes256GcmSiv::new_from_slice(&dek_bytes)
            .map_err(|e| CryptoError::Crypto(format!("Aes256GcmSiv DEK init failed: {e}")))?;
        let mut nonce = [0u8; 12];
        rand::rngs::OsRng.fill_bytes(&mut nonce);
        let ciphertext = dek_cipher
            .encrypt(Nonce::from_slice(&nonce), plaintext)
            .map_err(|e| CryptoError::Crypto(format!("Payload encryption failed: {e}")))?;

        if let Ok(mut groups_guard) = self.groups.write() {
            if let Some(entry) = groups_guard.get_mut(&group_id) {
                entry.record_deks.insert(
                    record_id,
                    RecordDekEntry {
                        wrapped_dek: wrapped_dek.clone(),
                        dek_nonce,
                        revoked: false,
                    },
                );
            }
        }

        dek_bytes.zeroize();

        Ok(EncryptedRecordPayload {
            record_id,
            group_id,
            ciphertext,
            nonce,
            wrapped_dek,
            dek_nonce,
        })
    }

    /// Decrypts an `EncryptedRecordPayload` using Envelope Encryption.
    /// Fails with `CryptoError::Crypto` if group or record has been revoked.
    pub fn decrypt_record(
        &self,
        master_key: &KeyManager,
        payload: &EncryptedRecordPayload,
    ) -> Result<Vec<u8>> {
        if self.is_group_revoked(payload.group_id) {
            return Err(CryptoError::KeyRevoked(format!(
                "Group {} has been revoked/shredded",
                payload.group_id
            )));
        }

        if let Ok(groups_guard) = self.groups.read() {
            if let Some(entry) = groups_guard.get(&payload.group_id) {
                if let Some(rec) = entry.record_deks.get(&payload.record_id) {
                    if rec.revoked {
                        return Err(CryptoError::Crypto(format!(
                            "Record {} in group {} has been revoked/shredded",
                            payload.record_id, payload.group_id
                        )));
                    }
                }
            } else {
                return Err(CryptoError::Crypto(format!(
                    "Group {} missing or revoked in KeyRegistry",
                    payload.group_id
                )));
            }
        }

        let subkey = self.get_or_derive(master_key, payload.group_id)?;
        let kek_cipher = Aes256GcmSiv::new_from_slice(&subkey.0)
            .map_err(|e| CryptoError::Crypto(format!("Aes256GcmSiv KEK init failed: {e}")))?;

        let dek_bytes = kek_cipher
            .decrypt(
                Nonce::from_slice(&payload.dek_nonce),
                payload.wrapped_dek.as_slice(),
            )
            .map_err(|e| CryptoError::Crypto(format!("DEK unwrap failed (key revoked?): {e}")))?;

        let dek_cipher = Aes256GcmSiv::new_from_slice(&dek_bytes)
            .map_err(|e| CryptoError::Crypto(format!("Aes256GcmSiv DEK init failed: {e}")))?;

        let plaintext = dek_cipher
            .decrypt(
                Nonce::from_slice(&payload.nonce),
                payload.ciphertext.as_slice(),
            )
            .map_err(|e| CryptoError::Crypto(format!("Payload decryption failed: {e}")))?;

        Ok(plaintext)
    }

    /// Encrypts plaintext using the sub-key (KEK) for `group_id`.
    pub fn encrypt_with_group(
        &self,
        master_key: &KeyManager,
        group_id: u64,
        plaintext: &[u8],
    ) -> Result<(Vec<u8>, [u8; 12])> {
        if self.is_group_revoked(group_id) {
            return Err(CryptoError::KeyRevoked(format!(
                "Shred group {group_id} has been revoked and cannot be accessed"
            )));
        }
        let subkey = self.get_or_derive(master_key, group_id)?;
        let cipher = Aes256GcmSiv::new_from_slice(&subkey.0)
            .map_err(|e| CryptoError::Crypto(format!("Aes256GcmSiv init failed: {e}")))?;

        let mut nonce_bytes = [0u8; 12];
        rand::rngs::OsRng.fill_bytes(&mut nonce_bytes);
        let nonce = Nonce::from_slice(&nonce_bytes);

        let ciphertext = cipher
            .encrypt(nonce, plaintext)
            .map_err(|e| CryptoError::Crypto(format!("Encryption failed: {e}")))?;

        Ok((ciphertext, nonce_bytes))
    }

    /// Decrypts ciphertext using the sub-key (KEK) for `group_id`.
    /// Returns `Err(CryptoError::Crypto(...))` if key was revoked or decryption fails.
    pub fn decrypt_with_group(
        &self,
        group_id: u64,
        ciphertext: &[u8],
        nonce_bytes: &[u8; 12],
    ) -> Result<Vec<u8>> {
        if self.is_group_revoked(group_id) {
            return Err(CryptoError::KeyRevoked(format!(
                "Sub-key for group {group_id} has been revoked or is missing"
            )));
        }

        let read_guard = self
            .groups
            .read()
            .map_err(|_| CryptoError::Crypto("KeyRegistry read lock poisoned".to_string()))?;

        let entry = read_guard.get(&group_id).ok_or_else(|| {
            CryptoError::Crypto(format!(
                "Sub-key for group {group_id} has been revoked or is missing"
            ))
        })?;

        let cipher = Aes256GcmSiv::new_from_slice(&entry.kek.0)
            .map_err(|e| CryptoError::Crypto(format!("Aes256GcmSiv init failed: {e}")))?;

        let nonce = Nonce::from_slice(nonce_bytes);
        cipher
            .decrypt(nonce, ciphertext)
            .map_err(|e| CryptoError::Crypto(format!("Decryption failed: {e}")))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_envelope_single_record_deletion_64_records() -> Result<()> {
        let km = KeyManager::try_new("test-passphrase-envelope", b"salt1")?;
        let registry = KeyRegistry::new();
        let group_id = 42;

        let mut payloads = Vec::with_capacity(64);
        for record_id in 0..64 {
            let plaintext = format!("Payload for record {record_id}");
            let payload =
                registry.encrypt_record(&km, group_id, record_id, plaintext.as_bytes())?;
            payloads.push(payload);
        }

        // Verify all 64 records decrypt successfully
        for (i, payload) in payloads.iter().enumerate() {
            let decrypted = registry.decrypt_record(&km, payload)?;
            assert_eq!(decrypted, format!("Payload for record {i}").as_bytes());
        }

        // Perform single record deletion (revoke record 10)
        let revoked = registry.revoke_record(group_id, 10);
        assert!(revoked, "Record 10 must be successfully revoked");

        // Record 10 MUST fail decryption
        let res_10 = registry.decrypt_record(&km, &payloads[10]);
        assert!(res_10.is_err(), "Revoked record 10 MUST fail decryption");

        // All remaining 63 neighbor records MUST remain readable
        for (i, payload) in payloads.iter().enumerate() {
            if i == 10 {
                continue;
            }
            let decrypted = registry.decrypt_record(&km, payload)?;
            assert_eq!(
                decrypted,
                format!("Payload for record {i}").as_bytes(),
                "Neighbor record {i} MUST remain decryptable after single record 10 deletion"
            );
        }

        Ok(())
    }

    #[test]
    fn test_envelope_group_deletion_and_attack_simulation() -> Result<()> {
        let km = KeyManager::try_new("test-passphrase-envelope", b"salt1")?;
        let registry = KeyRegistry::new();
        let group_id = 100;

        let payload =
            registry.encrypt_record(&km, group_id, 1, b"Group confidential data block")?;
        assert!(registry.is_group_active(group_id));

        // Revoke entire group (Group Deletion)
        let revoked = registry.revoke_group(group_id).expect("revoke_group");
        assert!(revoked, "Group 100 revocation must succeed");
        assert!(!registry.is_group_active(group_id));

        // Decryption via decrypt_record MUST fail
        let res_decrypt = registry.decrypt_record(&km, &payload);
        assert!(
            res_decrypt.is_err(),
            "Decryption of record in revoked group MUST fail"
        );

        // Attempting to re-derive key for group 100 via get_or_derive MUST fail
        let res_get_derive = registry.get_or_derive(&km, group_id);
        assert!(
            res_get_derive.is_err(),
            "Re-deriving key for revoked group MUST fail and be consistently rejected"
        );

        // Attempting to encrypt_with_group for revoked group MUST fail
        let res_encrypt = registry.encrypt_with_group(&km, group_id, b"New payload");
        assert!(
            res_encrypt.is_err(),
            "encrypt_with_group MUST consistently reject revoked group"
        );

        Ok(())
    }
}
