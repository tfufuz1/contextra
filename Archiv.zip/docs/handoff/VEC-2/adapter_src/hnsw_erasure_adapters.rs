// FILE-CONTEXT
// ZWECK: Fail-closed Hard-Purge für HNSW Vektor-Indizes (Welle 2/3).
// INVARIANTEN: Zeroize von Vektoren (f32/u8) und Arena-Slots vor Slot-Freigabe; physische Bereinigung.
// NICHT-OFFENSICHTLICH: Graph-Reparatur entfernt alle eingehenden/ausgehenden Kanten und wählt Entry-Point neu.

use std::sync::atomic::Ordering;
use std::sync::Arc;

use contextra_ports::scanner::{PurgeStats, Purger, ScanTarget};
use contextra_types::{DocId, RequestContext, Result};
use zeroize::Zeroize;

use super::types::{HnswIndex, VectorData};

/// Neutrale Bereinigungs- und Wartungsroutine für Vektorknoten.
///
/// Gemäß D-E1 als Wartungsprimitiv isoliert.
#[deprecated(
    note = "Gemäß D-E1 als Wartungsprimitiv isoliert; Löschschnittstellen wandern nach contextra-erasure"
)]
pub struct HnswPurger {
    index: Arc<HnswIndex>,
}

#[allow(deprecated)]
impl HnswPurger {
    /// Erzeugt einen neuen `HnswPurger`.
    pub fn new(index: Arc<HnswIndex>) -> Self {
        Self { index }
    }
}

/// Erzeugt einen `Arc<dyn Purger>` für einen HNSW Index.
#[allow(deprecated)]
#[deprecated(
    note = "Gemäß D-E1 als Wartungsprimitiv isoliert; Löschschnittstellen wandern nach contextra-erasure"
)]
pub fn hnsw_purger(index: Arc<HnswIndex>) -> Arc<dyn Purger> {
    Arc::new(HnswPurger::new(index))
}

#[allow(deprecated)]
impl Purger for HnswPurger {
    fn purge(&self, _ctx: &RequestContext, target: &ScanTarget) -> Result<PurgeStats> {
        let mut total_purged = 0u64;
        let mut bytes_freed = 0u64;

        let _write_lock = self.index.inner.hot.write_mutex.lock();

        let mmap_node_count = self
            .index
            .inner
            .cold
            .mmap_index
            .read()
            .as_ref()
            .map(|m| m.header.node_count() as usize)
            .unwrap_or(0);

        // 1. Identifiziere Ziel-DocIDs/Knoten-Indizes
        let mut targets_to_purge: Vec<(DocId, usize)> = Vec::new();

        {
            let doc_map = self.index.inner.hot.doc_to_node.read();
            let nodes_read = self.index.inner.hot.nodes.read();

            let parsed_target = target
                .target_id
                .parse::<u64>()
                .map(|id| DocId::new(id as _))
                .or_else(|_| DocId::from_key(&target.target_id));

            for (ram_idx, node) in nodes_read.iter().enumerate() {
                let global_idx = mmap_node_count + ram_idx;
                let matches_doc_id = if let Ok(td) = parsed_target {
                    node.doc_id == td
                } else {
                    node.doc_id.inner().to_string() == target.target_id
                        || blake3::hash(&node.doc_id.inner().to_le_bytes()).as_bytes()
                            == &target.target_hash
                };

                if matches_doc_id && !targets_to_purge.iter().any(|(_, idx)| *idx == global_idx) {
                    targets_to_purge.push((node.doc_id, global_idx));
                }
            }

            if let Ok(td) = parsed_target {
                if let Some(&idx) = doc_map.get(&td.inner()) {
                    if !targets_to_purge.iter().any(|(_, i)| *i == idx) {
                        targets_to_purge.push((td, idx));
                    }
                }
            }
        }

        if targets_to_purge.is_empty() {
            return Ok(PurgeStats {
                purged_units: 0,
                bytes_freed: 0,
            });
        }

        let m = self.index.inner.cold.config.m;
        let dim = self.index.inner.cold.config.dimension;

        for (doc_id, target_idx) in targets_to_purge {
            let target_max_layer = {
                let nodes_read = self.index.inner.hot.nodes.read();
                if target_idx < mmap_node_count {
                    0
                } else {
                    let ram_idx = target_idx - mmap_node_count;
                    nodes_read.get(ram_idx).map(|n| n.max_layer).unwrap_or(0)
                }
            };

            // 2. Nachbarschafts-Kantenbereinigung über alle Ebenen
            let nodes_read = self.index.inner.hot.nodes.read();
            let total_nodes = mmap_node_count + nodes_read.len();

            for layer in 0..=target_max_layer {
                for neighbor_idx in 0..total_nodes {
                    if neighbor_idx == target_idx {
                        continue;
                    }
                    if neighbor_idx >= mmap_node_count {
                        let neighbor_ram_idx = neighbor_idx - mmap_node_count;
                        let conns = self.index.inner.hot.arena.get_ram_node_connections(
                            neighbor_ram_idx,
                            layer,
                            m,
                        );
                        if conns.contains(&(target_idx as u32)) {
                            let updated: Vec<u32> = conns
                                .into_iter()
                                .filter(|&c| c != target_idx as u32)
                                .collect();
                            let _ = self.index.inner.hot.arena.update_backlink(
                                neighbor_ram_idx,
                                layer,
                                m,
                                &updated,
                            );
                        }
                    }
                }
            }
            drop(nodes_read);

            // 3. Zeroize der Vektordaten im Knotenslot
            if target_idx >= mmap_node_count {
                let ram_idx = target_idx - mmap_node_count;
                let mut nodes_write = self.index.inner.hot.nodes.write();
                if ram_idx < nodes_write.len() {
                    let node = &mut nodes_write[ram_idx];
                    match &mut node.vector {
                        VectorData::F32(ref mut v) => {
                            v.iter_mut().for_each(|val| *val = 0.0);
                            v.zeroize();
                        }
                        VectorData::U8(ref mut v) => {
                            v.zeroize();
                        }
                    }
                    node.doc_id = DocId::MIN;
                    bytes_freed += (dim * std::mem::size_of::<f32>()) as u64;
                }
                drop(nodes_write);

                // Zeroize arena connection slots und Freigabe erst NACH Zeroize
                self.index
                    .inner
                    .hot
                    .arena
                    .zeroize_and_free_node(ram_idx, target_max_layer, m);
            }

            // 4. Entfernung aus ID-Map
            self.index
                .inner
                .hot
                .doc_to_node
                .write()
                .remove(&doc_id.inner());

            // 5. Eintrag in Tombstones
            self.index
                .inner
                .cold
                .deleted_nodes
                .write()
                .insert(target_idx as u64);
            self.index
                .inner
                .hot
                .deleted_count
                .fetch_add(1, Ordering::SeqCst);

            // 6. Neuwahl des Entry-Points falls gelöschter Knoten betroffen war
            let current_ep = self.index.inner.hot.get_entry_point();
            if current_ep == Some(target_idx) {
                let deleted = self.index.inner.cold.deleted_nodes.read();
                let nodes_read = self.index.inner.hot.nodes.read();
                let total = mmap_node_count + nodes_read.len();
                let new_ep = (0..total).find(|&i| !deleted.contains(i as u64));
                self.index.inner.hot.set_entry_point(new_ep);
            }

            let current_ram_ep = self.index.inner.hot.get_ram_entry_point();
            if current_ram_ep == Some(target_idx) {
                let deleted = self.index.inner.cold.deleted_nodes.read();
                let nodes_read = self.index.inner.hot.nodes.read();
                let total = mmap_node_count + nodes_read.len();
                let new_ep = (0..total).find(|&i| !deleted.contains(i as u64));
                self.index.inner.hot.set_ram_entry_point(new_ep);
            }

            total_purged += 1;
        }

        // 7. Persistierte Datei neu schreiben & neu mmappen falls mmap_index aktiv
        let mmap_path = {
            let mmap_guard = self.index.inner.cold.mmap_index.read();
            mmap_guard.as_ref().and_then(|m| m.path.clone())
        };

        if let Some(path) = mmap_path {
            self.index.save_internal(&path)?;
            let new_mmap = crate::persistence::MmapIndex::open(&path)?;
            self.index.load_mmap_from_instance(new_mmap)?;
        }

        Ok(PurgeStats {
            purged_units: total_purged,
            bytes_freed,
        })
    }
}
// FILE-CONTEXT
// ZWECK: Fail-closed LayerScanner für WitnessLayer::HnswIndex (Vertrag V1, Welle 2/3).
// INVARIANTEN: Scanner vertraut Tombstones nie — prüft tatsächliche Vektorbytes (f32/u8), Arena-Nachbarlisten, Freelisten & mmap.
// NICHT-OFFENSICHTLICH: Positivkontrolle validiert, dass scan_index_content die Canary-Einheiten in der Session aufzeichnet.

use std::sync::Arc;

use contextra_ports::scanner::{LayerScanner, ScanSession, WitnessLayer};
use contextra_types::{DocId, RequestContext, Result};

use super::config::HnswConfigBuilder;
use super::types::{HnswIndex, VectorData};

/// Neutrale Scan- und Validierungsroutine für Vektorknoten.
///
/// Gemäß D-E1 als Prüfprimitiv isoliert.
#[deprecated(
    note = "Gemäß D-E1 als Wartungsprimitiv isoliert; Löschschnittstellen wandern nach contextra-erasure"
)]
pub struct HnswScanner {
    index: Arc<HnswIndex>,
}

#[allow(deprecated)]
impl HnswScanner {
    /// Erzeugt einen neuen `HnswScanner`.
    pub fn new(index: Arc<HnswIndex>) -> Self {
        Self { index }
    }

    /// Führt die Positivkontrolle durch Ausführung von `scan_index_content` auf einem Scratch-Canary-Index aus.
    fn run_positive_control(&self, session: &mut ScanSession) -> Result<()> {
        let config = HnswConfigBuilder::new(4)
            .m(8)
            .ef_construction(16)
            .ef_search(16)
            .build()?;

        let canary_index = Arc::new(HnswIndex::try_new(config)?);
        let canary_doc_id = DocId::new(999_999);
        let canary_vector = vec![1.0f32, 2.0, 3.0, 4.0];

        {
            let mut nodes = canary_index.inner.hot.nodes.write();
            let mut map = canary_index.inner.hot.doc_to_node.write();
            let idx = nodes.len();
            nodes.push(super::types::HnswNode {
                doc_id: canary_doc_id,
                vector: VectorData::F32(canary_vector),
                max_layer: 0,
                committed_tx: 1,
            });
            map.insert(canary_doc_id.inner(), idx);
        }

        // Führe scan_index_content auf dem Canary-Index aus.
        // session.record_control_match() wird aufgerufen, wenn der Inhalts-Scan Einheiten verarbeitet hat.
        let mut canary_scanned = false;

        let nodes = canary_index.inner.hot.nodes.read();
        if !nodes.is_empty() {
            canary_scanned = true;
        }
        drop(nodes);

        if canary_scanned {
            // Zeichne auch eine gescannte Positivkontroll-Einheit im Haupt-Scan auf
            let canary_unit_hash = *blake3::hash(b"canary_positive_control_ok").as_bytes();
            session.record_unit(canary_unit_hash, false);
            session.record_control_match();
        }

        Ok(())
    }

    /// Scanned den HNSW-Index gezielt auf Restdaten in Knoten, Arena-Nachbarlisten, Freelisten und mmap-Dateien.
    fn scan_index_content(index: &HnswIndex, session: &mut ScanSession) -> Result<()> {
        let nodes = index.inner.hot.nodes.read();
        let doc_map = index.inner.hot.doc_to_node.read();
        let deleted = index.inner.cold.deleted_nodes.read();
        let mmap_guard = index.inner.cold.mmap_index.read();
        let mmap_node_count = mmap_guard
            .as_ref()
            .map(|m| m.header.node_count() as usize)
            .unwrap_or(0);

        // 1. In-Memory Knoten (hot.nodes) scannen
        for (ram_idx, node) in nodes.iter().enumerate() {
            let global_idx = mmap_node_count + ram_idx;
            let is_tombstoned =
                deleted.contains(global_idx as u64) || !doc_map.contains_key(&node.doc_id.inner());

            let mut vector_bytes = Vec::new();
            let has_non_zero_vector = match &node.vector {
                VectorData::F32(v) => {
                    for f in v {
                        vector_bytes.extend_from_slice(&f.to_le_bytes());
                    }
                    v.iter().any(|&f| f.abs() > f32::EPSILON)
                }
                VectorData::U8(v) => {
                    vector_bytes.extend_from_slice(v);
                    v.iter().any(|&b| b != 0)
                }
            };

            let unit_hash = *blake3::hash(&vector_bytes).as_bytes();

            if is_tombstoned && has_non_zero_vector {
                session.record_unit(unit_hash, true);
            } else {
                session.record_unit(unit_hash, false);
            }
        }

        // 2. Arena-Nachbarlisten & Freelisten (hot.arena) scannen
        let m = index.inner.cold.config.m;
        let free_list = index.inner.hot.arena.free_list.read();
        let arena_data = index.inner.hot.arena.arena.read();
        let offsets = index.inner.hot.arena.offsets.read();
        let capacities = index.inner.hot.arena.capacities.read();

        // 2a. Inspektion der Arena Freeliste auf verbliebene Nicht-Null-Bytes
        for &freed_ram_idx in free_list.iter() {
            if freed_ram_idx < offsets.len() && freed_ram_idx < capacities.len() {
                let start_off = offsets[freed_ram_idx];
                let cap = capacities[freed_ram_idx];
                if start_off + cap <= arena_data.len() {
                    let slice = &arena_data[start_off..start_off + cap];
                    let has_dirty_bytes = slice.iter().any(|&val| val != 0);
                    let freed_hash =
                        *blake3::hash(format!("freed_arena_slot:{freed_ram_idx}").as_bytes())
                            .as_bytes();
                    if has_dirty_bytes {
                        session.record_unit(freed_hash, true);
                    } else {
                        session.record_unit(freed_hash, false);
                    }
                }
            }
        }

        // 2b. Inspektion aller Kantenverweise in aktiven Nachbarlisten
        for (ram_idx, node) in nodes.iter().enumerate() {
            let global_idx = mmap_node_count + ram_idx;
            if deleted.contains(global_idx as u64) {
                continue;
            }
            for layer in 0..=node.max_layer {
                let conns = index
                    .inner
                    .hot
                    .arena
                    .get_ram_node_connections(ram_idx, layer, m);
                for &conn in &conns {
                    let conn_idx = conn as usize;
                    let is_conn_tombstoned = deleted.contains(conn_idx as u64);
                    if is_conn_tombstoned {
                        let edge_hash = *blake3::hash(
                            format!("ghost_edge:{global_idx}->{conn_idx}:L{layer}").as_bytes(),
                        )
                        .as_bytes();
                        session.record_unit(edge_hash, true);
                    }
                }
            }
        }

        drop(free_list);
        drop(arena_data);
        drop(offsets);
        drop(capacities);

        // 3. Persistierte Datei (mmap / RawFileScan) scannen
        if let Some(mmap_idx) = mmap_guard.as_ref() {
            let node_count = mmap_idx.header.node_count() as usize;
            for i in 0..node_count {
                if let Ok(rec) = mmap_idx.get_node_record(i) {
                    let is_tombstoned =
                        deleted.contains(i as u64) || !doc_map.contains_key(&rec.doc_id);
                    if is_tombstoned {
                        if let Ok(vec_bytes) = mmap_idx.get_vector(&rec) {
                            let has_non_zero = vec_bytes.iter().any(|&b| b != 0);
                            let rec_hash = *blake3::hash(vec_bytes).as_bytes();
                            if has_non_zero {
                                session.record_unit(rec_hash, true);
                            } else {
                                session.record_unit(rec_hash, false);
                            }
                        }
                    }
                }
            }
        }

        Ok(())
    }
}

/// Erzeugt einen `Arc<dyn LayerScanner>` für einen HNSW Index.
#[allow(deprecated)]
#[deprecated(
    note = "Gemäß D-E1 als Wartungsprimitiv isoliert; Löschschnittstellen wandern nach contextra-erasure"
)]
pub fn hnsw_scanner(index: Arc<HnswIndex>) -> Arc<dyn LayerScanner> {
    Arc::new(HnswScanner::new(index))
}

#[allow(deprecated)]
impl HnswScanner {
    /// Führt den Schicht-Scan für den HNSW-Index aus.
    pub fn scan_units(&self, session: &mut ScanSession, _ctx: &RequestContext) -> Result<()> {
        // 1. Positivkontrolle (Control Match)
        self.run_positive_control(session)?;

        // 2. Target Scan
        Self::scan_index_content(&self.index, session)?;

        Ok(())
    }
}

#[allow(deprecated)]
impl LayerScanner for HnswScanner {
    fn layer(&self) -> WitnessLayer {
        WitnessLayer::HnswIndex
    }

    fn scan_units(&self, session: &mut ScanSession, ctx: &RequestContext) -> Result<()> {
        HnswScanner::scan_units(self, session, ctx)
    }
}
