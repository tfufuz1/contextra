# Changelog

Alle relevanten Aenderungen im Contextra Baukastensystem werden in dieser Datei dokumentiert.

## [4.1] - 2026-11-08

### Added
- **Normative Baukasten-Gesamtspezifikation v4.1 (`docs/SPEC.md`):** Umfassende normative Ausarbeitung aller 36 Crates im Soll-Zustand, Module, Invarianten, Kernel-Funktionen und Fehlermodelle.
- **Klassifikationsmodell A/B/C/T:**
  - Klasse A: 21 autarke Bausteine nach Kriterien B1–B12 (0 interne `contextra-*`-Abhaengigkeiten, API in Standardtypen, lokale Fehler, Standalone-Export via `tools/export-crate`).
  - Klasse B: Kohaerentes Storage-Bundle (`types`, `ports`, `mvcc`, `checkpoint`, `store`).
  - Klasse C: Kompositions- und Integrationsschicht (`contextra`, `db`, `engine`, `cognition`, `agent`, `mcp`, `py`, `router`).
  - Klasse T: Tooling und Testkit (`testkit`, `contextra-bench`).
- **Loeschkapselung (§6):** Vollstaendige Entkopplung der Multi-Layer-Loeschkette und DSGVO-Logik in `contextra-erasure` mit Adapteranbindung (`contextra-erasure-adapters`).
- **Verifikations-Gates G1–G10:** Maschinelle Pruefung von Klassen, APIs, Standalone-Builds, Feature-Flags, Domaenenreinheit und Zero-Panic.
- **Entscheidungsregister E-01 bis E-12:** Festhaltung der Kernarchitektur-Entscheidungen (vertikale Autarkie vor DRY, keine Hubs in Klasse A).

### Changed
- Dokumentation (`docs/SOURCE_OF_TRUTH.md`, `docs/CONSTITUTION.md`, `docs/ARCHITECTURE.md`, `docs/SECURITY.md`, `docs/CONTRIBUTING.md`, `docs/VETOES.md`, `docs/TYPE_REGISTRY.md`, `PLAN.md`, `AGENTS.md`) an die Baukasten-Spezifikation v4.1 angeglichen.
- **`contextra-store` Spezifikation & Crate-Dokumentation (Paket B8 / M11):** `SPEC.md` nach P01–P10 und SPEC v4.1 mit vollständiger Modulkarte, Invarianten INV-STORE-1 bis 5, Lock-Register und Poison-Matrix verfasst. `README.md` auf Klasse-B Storage-Bundle ausgerichtet; `AGENTS.md`, `PLAN.md` und `lib.rs` konsolidiert; ADR-Index für `contextra-store` erstellt.

## [Paket B31] - 2026-11-07

### Removed
- `contextra-core`: Veraltete Strangler-Fassade (Ring 0, deprecated) vollständig dekommissioniert und gelöscht.
- Alle Verweise und Abhängigkeiten in `Cargo.toml`, `capabilities.toml`, `deny.toml` und `tests/layering.rs` entfernt.

### Changed
- `benchmarks/contextra-bench`: Importe von `contextra_core` vollständig auf `contextra_types` und `contextra_ports` umgestellt.
- `contextra-db/fuzz` und `contextra-store/fuzz`: Ungenutzte Abhängigkeit auf `contextra-core` entfernt.

### Migration Guide
- Ersetze `use contextra_core::{ContextraError, Result, DocId, TxId, DistanceMetric}` durch `use contextra_types::{...}`.
- Ersetze `use contextra_core::traits::{StorageEngine, VectorIndex, ...}` durch `use contextra_ports::{...}`.
- Ersetze `use contextra_core::tx_buffer::{TxBuffer, IndexOp}` und `snapshot::{...}` durch `use contextra_mvcc::{...}`.
- Ersetze `use contextra_core::ipc::{...}` durch `use contextra_wire::{...}`.

## [4.1] - 2026-10-31

### Changed
- Dokumentation auf Ist-Stand Commit `3a0b11699` gebracht. Repo enthält 35 Crate-Verzeichnisse, nicht 14.
- `docs/SPEC.md` auf Fassung 4.1 (Konsolidierung). Scope D-K1 offen, verweist auf ADR 0009.
- `docs/PLAN.md` auf Fassung 4.1 mit Phase K0 (Build herstellen) als Voraussetzung.
- `docs/ARCHITECTURE.md` mit gemessenem Crate-Inventar, Ringmodell, Abhängigkeiten und Befunden D1 bis D6.
- `README.md` mit korrigiertem Status.
- Vorherige Fassungen nach `docs/spec/archiv/` verschoben (SPEC 3.1, 4.0; PLAN 3.1, 4.0).

### Added
- `docs/decisions/0009-scope-entscheidung-kern-oder-vollumfang.md` (Proposed).
- `docs/analysis/BEFUNDE_2026-10-31.md` mit Befehlen zur Reproduktion.

### Known issues
- Build nicht verifiziert. `xtask` im Workspace ohne Verzeichnis.
- Feature `onnx` und `adaptive-candidate-pool-sizing` ohne deklarierte Abhängigkeit.
- `contextra-vector` führt Dateisystem-I/O in Ring 0 aus.
- `contextra-durable-fs` ohne Eintrag in `capabilities.toml`.
- `CLAUDE.md` und `AGENTS.md` nicht überarbeitet, Widersprüche in PLAN K2.2 erfasst.

<!-- doc-stamp: 2026-10-29 10cc17922 -->

# Contextra — Chronologischer Tag- & Review-Bericht

> Automatisch generierter Read-Only Bericht aus allen Inline-Tags im Repo.

## [Reduktion] - 2026-10-30

### Changed
- Repository auf Kern v1 reduziert (Commit `ed402e21a`). Entfernt: `contextra-graph`, `-adapt`, `-agent`, `-cognition`, `-infer-*`, `-ingest`, `-mcp`, `-privacy`, `-wire`, `-checkpoint`, `-audit-export`, `-avv-generator`, `-kvcache`, `-router`, `-sandbox`, `-py`, `-license`, `-core`; `xtask/` (Commit `068261abd`).
- `docs/SPEC.md` auf Fassung 4.0 (Reduktionsfassung), `docs/PLAN.md` auf Fassung 4.0 (Phasen R0 bis R6).
- Ringmodell an Ist-Abhängigkeiten angepasst; `contextra-engine` von Ring 3 nach Ring 2 (Vorschlag D-R3).
- Löschkette aus dem Scope v1 genommen (D-R5). ADR-0001, 0006, 0007, 0008 ausgesetzt.
- Dokumentation (`README.md`, `AGENTS.md`, `CLAUDE.md`, `docs/ARCHITECTURE.md`, `docs/SECURITY.md`, `docs/CONTRIBUTING.md`, `docs/TYPE_REGISTRY.md`, `.github/copilot-instructions.md`, `.github/pull_request_template.md`) an den Ist-Stand angeglichen.

### Known issues
- Workspace-Mitglied `xtask` fehlt; Quelltext referenziert entfernte Crates; Feature-Flags sind teils nicht deklariert. Build ist nicht grün (SPEC §16, B1 bis B4).
- Gate-Runner entfernt; Gates nicht ausführbar (D-R2).
- Restore-Tag `pre-reduction-1.0` existiert nicht; maßgeblich ist `3c1f144fa` (D-R6).

---

## [Unreleased] - 2026-10-29

### Docs
- Meta-Dokumentation (`ARCHITECTURE.md`, `PLAN.md`, `SPEC.md`, `README.md`) an SPEC 3.0 und Baukasten-Architektur angeglichen.
- Soll-Ist-Abweichungen und offene Spezifikationsfragen in `SPEC.md` dokumentiert.

---

| Zeitstempel | Crate/Datei | Typ | ID | Session | Status | Review-Pässe (unabhängig) | Beschreibung |
|---|---|---|---|---|---|---|---|
| `TS:2026-10-04 (Kampagne J-25)` | `crates/contextra-crypto/tests/campaign_j25.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Kampagne J-25: Kryptografische Compliance- & Compliance-Testsuite für contextra-crypto |
| `TS:2026-10-01T00:00:00Z (SESSION: 5a38054a)` | `crates/contextra-agent/src/graph.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Declarative StateGraph definition routing workflow step transitions. |
| `TS:2026-10-01T00:00:00Z (SESSION: 088b4a44)` | `crates/contextra-agent/src/goal_condition.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Strukturierte, deterministische Auswertung von Teilziel-Bedingungen (GoalCondition) für Agentenschritte. |
| `TS:2026-10-01T00:00:00Z` | `crates/contextra-agent/src/clm_scratchpad.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Temporärer, aufgabengebundener Kontext-Scratchpad für sehr lange Agentenschleifen (Context-Language-Model). |
| `TS:2026-10-01T00:00:00Z` | `crates/contextra-kvcache/src/prefix_store.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Mandantenisolierter KV-Prefix-Store mit Byte-Budget & LRU-Eviction (Spec §9.2 / INV-CLM-SCRATCHPAD-1). |
| `TS:2026-10-01T00:00:00Z` | `crates/contextra-kvcache/src/scratchpad_invalidation.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Targeted Invalidation von Agent-Scratchpad-Prefixes im Radix-Baum (Spec §9.2 / INV-CLM-SCRATCHPAD-1). |
| `TS:2026-09-28T00:00:00Z` | `crates/contextra-graph/src/apprh/gate_monitor.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | ApprhGateMonitor zur Serienbewertung von APPRH-Shadow-Vergleichen fuer Produktionsfreigabe (P1.3) |
| `TS:2026-09-28T00:00:00Z` | `crates/contextra-graph/src/apprh/selector.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | ApprhSelector zur Steuerung von Shadow-Mode-Abtastung und expliziter Produktionsschaltung (P1.3) |
| `TS:2026-09-28` | `crates/contextra-engine/tests/tenant_wrapper_coverage.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Lückenlose Abdeckung aller Collection- und Storage-Operationen unter Mandanten-Isolation (TenantScopedStorage N21). |
| `TS:2026-09-27T00:00:00Z` | `crates/contextra-cognition/src/transitivity_veto.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Transitivity Veto Inspection & Orchestration for Near-Duplicate Memory Consolidation. |
| `TS:2026-09-27T00:00:00Z` | `crates/contextra-cognition/tests/transitivity_veto_tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Tests für Transitivity Veto Inspektion, Orchestrierung & Budget-Steuerung. |
| `TS:2026-09-27T00:00:00Z` | `crates/contextra-crypto/tests/deletion_proof_hash_collision.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Tests verifying collision prevention via length-prefixed hashing for DeletionProof. |
| `TS:2026-09-26T00:00:00Z` | `crates/contextra-adapt/tests/sketched_projection_config_validation.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Konfigurations- und Validierungstests für SketchedProjection (§13.2). |
| `TS:2026-09-26T00:00:00Z` | `crates/contextra-adapt/tests/sketched_projection_determinism.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Determinismus-Tests für SketchedProjection (§13.2 / P28). |
| `TS:2026-09-26T00:00:00Z` | `crates/contextra-adapt/tests/sketched_projection_vs_sherman_morrison.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Differential-Test SketchedProjection vs. ShermanMorrison baseline (§13.2). |
| `TS:2026-09-26T00:00:00Z` | `crates/contextra-crypto/tests/legacy_hmac_collision_property.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Property-Test for legacy v2 HMAC length-prefixed deletion keys hashing function against collisions. |
| `TS:2026-09-26T00:00:00Z` | `crates/contextra-store/tests/wal_recovery_runtime_stall.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Runtime stall test for WAL recovery replay to detect non-linear (O(n²)) complexity regressions. |
| `TS:2026-09-25T15:10:00Z` | `crates/contextra-crypto/benches/deletion_proof_latency_bench.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Criterion benchmark for cryptographic deletion proof issuance and verification latency. |
| `TS:2026-09-17T19:00:00Z (SESSION: jules-agent-budget)` | `crates/contextra-agent/src/budget.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Token budget RAII reservation abstraction for agent workflow steps. |
| `TS:2026-09-17T00:00:00Z` | `crates/contextra-crypto/tests/deletion_proof_prefix_collision_proptest.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | AK-21 Collision test for length-prefixed key hash function hash_deleted_keys_length_prefixed. |
| `TS:2026-09-17T00:00:00Z` | `crates/contextra-engine/src/chunker.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Markdown-basierte semantische Textzerlegung (WP-7.1 / Teil 6.12 Spezifikation) und UTF-8-sicheres Chunken. |
| `TS:2026-09-15T00:00:00Z` | `crates/contextra-kvcache/src/eviction_worker.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Eviction-Worker (nicht-blockierender Hot-Path LRU / Attention) und emergency_wipe (synchroner Notfall). |
| `TS:2026-09-15T00:00:00Z` | `crates/contextra-kvcache/src/radix.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Prefix-Radix-Baum über Token-Sequenzen, RAII-Guards & KvReusePolicy (§9.2). |
| `TS:2026-09-15T00:00:00Z` | `crates/contextra-kvcache/src/segment.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | KvSegment mit Zeroize-Garantie, Tier-2 AEAD-Verschlüsselung & Crypto-Shredding. |
| `TS:2026-09-15T00:00:00Z` | `crates/contextra-kvcache/src/store.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Tenant-isolierter KV-Segment-Store (INV-TENANT Isolation) mit Prefix-Radix & Guard-Schutz. |
| `TS:2026-09-15T00:00:00Z` | `crates/contextra-kvcache/tests/cancellation.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Cancellation- & RAII-Guard-Tests für den KV-Cache (Task KV-06). |
| `TS:2026-09-15T00:00:00Z` | `crates/contextra-kvcache/tests/golden_greedy_decode.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Golden-Test für identische Greedy-Tokenfolgen mit/ohne Prefix-Reuse (Spec §9.2 / Task 4-04). |
| `TS:2026-09-15T00:00:00Z` | `crates/contextra-kvcache/tests/prefix_store_port.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Port- und Isolationstests für TenantPrefixKvStore (§9.2). |
| `TS:2026-09-15T00:00:00Z` | `crates/contextra-kvcache/tests/tenant_isolation.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Tenant-Isolations-Tests für den KV-Cache (Task KV-05 / INV-TENANT). |
| `TS:2026-09-15T00:00:00Z` | `crates/contextra-vector/src/candidate_stream.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Liefert Vector-Kandidaten in Batches à 16 (oder konfigurierbar) via geometrisches Nachladen. |
| `TS:2026-09-14T00:00:00Z` | `crates/contextra-text/src/stream.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Liefert BM25-Kandidaten in Batches à 16 (oder konfigurierbar) via geometrisches Nachladen. |
| `TS:2026-09-13T01:36:52Z (SESSION: c1c85419)` | `crates/contextra-agent/tests/proptest_workflow_tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Property-based testing for contextra-agent structural invariants (StateGraph, AgentContext, BackgroundEvent). |
| `TS:2026-09-13T00:00:00Z (SESSION: pid-regler-impl)` | `crates/contextra-adapt/src/pid_latency_controller.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | PID Latency Controller & Latency Budget Guard für Multi-Step Retrieval. |
| `TS:2026-09-13T00:00:00Z` | `crates/contextra-cognition/src/consolidation_locks.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Guard-Konstrukt fuer typsicheres Locking und geordnete Kaskaden-Invalidierung in der Sleep-Cycle-Konsolidierung. |
| `TS:2026-09-13T00:00:00Z` | `crates/contextra-crypto/src/kv_segment/store.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Tenant-isolierter KV-Segment-Store (INV-TENANT Isolation). |
| `TS:2026-09-12T00:00:00Z` | `crates/contextra-db/src/multistep.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Multi-Step Iterative Retrieval Engine für komplexe Agenten-Abfragen (o-series Pattern). |
| `TS:2026-09-12T00:00:00Z` | `crates/contextra-db/tests/consolidation_double_trigger_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrierter Test zur Verifizierung des Double-Trigger-Schutzes zwischen ConsolidationEngine und MaintenanceScheduler. |
| `TS:2026-09-12` | `crates/contextra-engine/src/export.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Export-Funktionalität für Memory-Export-Format v1 (Schema Version "1.0"). |
| `TS:2026-09-12` | `crates/contextra-engine/src/import.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Import-Funktionalität & Zusammenfassung für Memory-Export-Format v1 (Schema Version "1.0"). |
| `TS:2026-09-11T14:41:11Z (SESSION: b979ee5a)` | `crates/contextra-agent/src/audit.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Append-only immutable audit trail logging for agent state transitions. |
| `TS:2026-09-11T00:00:00Z` | `crates/contextra-adapt/src/homeostat.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | P95 retrieval latency feedback-regulated PID controller and hard deadline management (Feature F-08 & P11 requirement). |
| `TS:2026-09-10T19:30:00Z (SESSION: a9d67eae)` | `crates/contextra-vector/src/diskann/build.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | DiskANN-Graphindex für Out-of-Core Approximate Nearest Neighbor Search (WP-4.3). |
| `TS:2026-09-10T19:30:00Z (SESSION: a9d67eae)` | `crates/contextra-vector/src/diskann/config.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | DiskANN-Graphindex für Out-of-Core Approximate Nearest Neighbor Search (WP-4.3). |
| `TS:2026-09-10T19:30:00Z (SESSION: a9d67eae)` | `crates/contextra-vector/src/diskann/format.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | DiskANN-Graphindex für Out-of-Core Approximate Nearest Neighbor Search (WP-4.3). |
| `TS:2026-09-10T19:30:00Z (SESSION: a9d67eae)` | `crates/contextra-vector/src/diskann/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | DiskANN-Graphindex für Out-of-Core Approximate Nearest Neighbor Search (WP-4.3). |
| `TS:2026-09-10T19:30:00Z (SESSION: a9d67eae)` | `crates/contextra-vector/src/diskann/persistence.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | DiskANN-Graphindex für Out-of-Core Approximate Nearest Neighbor Search (WP-4.3). |
| `TS:2026-09-10T19:30:00Z (SESSION: a9d67eae)` | `crates/contextra-vector/src/diskann/search.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | DiskANN-Graphindex für Out-of-Core Approximate Nearest Neighbor Search (WP-4.3). |
| `TS:2026-09-10T19:30:00Z (SESSION: a9d67eae)` | `crates/contextra-vector/src/diskann/tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | DiskANN-Graphindex für Out-of-Core Approximate Nearest Neighbor Search (WP-4.3). |
| `TS:2026-09-10T19:30:00Z (SESSION: a9d67eae)` | `crates/contextra-vector/src/diskann/types.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | DiskANN-Graphindex für Out-of-Core Approximate Nearest Neighbor Search (WP-4.3). |
| `TS:2026-09-10T19:30:00Z (SESSION: a9d67eae)` | `crates/contextra-vector/src/diskann/vector_index_impl.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | DiskANN-Graphindex für Out-of-Core Approximate Nearest Neighbor Search (WP-4.3). |
| `TS:2026-09-10T19:25:46Z (SESSION: c844907e)` | `crates/contextra-text/src/inverted.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Speichert Postings-Listen, Dokumentlängen und BM25-Statistiken transaktional im StorageEngine. |
| `TS:2026-09-10T19:25:46Z (SESSION: c844907e)` | `crates/contextra-text/src/tokenizer.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Zerschneidet Eingabetexte in normalisierte Wort-Tokens mit optionaler deutscher Morphologie. |
| `TS:2026-09-10T19:21:35Z (SESSION: 4dd1c98c)` | `crates/contextra-text/src/morphology.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Umlaut-Normalisierung (ä->ae, ö->oe, ü->ue, ß->ss) und Zerlegung deutscher Zusammensetzungen. |
| `TS:2026-09-09T16:15:00Z (SESSION: dafac391)` | `crates/contextra-crypto/tests/kv_segment_concurrency.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Concurrency Stress Test für TenantIsolatedKvStore und EvictionWorker unter hoher Parallellast. |
| `TS:2026-09-09T16:10:00Z (SESSION: dafac391)` | `crates/contextra-crypto/src/kv_segment/eviction_worker.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Eviction-Worker (nicht-blockierender Hot-Path LRU) und emergency_wipe (synchroner Notfall). |
| `TS:2026-09-09T15:52:00Z (SESSION: 8fae2834)` | `crates/contextra-vector/src/partial_rebuild.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Lokaler Partial-Rebuild-Trigger für HNSW-Hot-Path-Regionen (F-02). |
| `TS:2026-09-09T13:22:45Z (SESSION: dc71d70)` | `crates/contextra-text/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Exportiert Bm25Scorer, InvertedIndex, Morphologie-Tools und BM25-Modelle für DB-Hybrid-Suche. |
| `TS:2026-09-09T13:17:00Z (SESSION: a413a598)` | `crates/contextra-crypto/tests/kv_segment_proptests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Property-based Tests für KvSegment, TenantIsolatedKvStore und LRU-Eviction. |
| `TS:2026-09-08T00:00:00Z (SESSION: a413a598)` | `crates/contextra-crypto/src/kv_segment/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | KV-Cache-Bridge Sicherheitsschicht (KvSegment, Tenant-Isolation, Eviction-Worker, Segment-Verschlüsselung). |
| `TS:2026-09-08T00:00:00Z (SESSION: a413a598)` | `crates/contextra-crypto/src/kv_segment/segment.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | KvSegment mit Zeroize-Garantie (ZeroizeOnDrop, nie unverschlüsselt auf Disk). |
| `TS:2026-09-08T00:00:00Z` | `crates/contextra-crypto/src/kv_cipher.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Dedicated AEAD encryption and key isolation for KV-cache segments (contextra-crypto). |
| `TS:2026-09-08T00:00:00Z` | `crates/contextra-crypto/tests/kv_segment_integration.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrationstest für KvSegment-Verschlüsselung, Zeroize und Prozess-Speicherabbild-Prüfung (P9). |
| `TS:2026-09-07T12:00:00Z` | `crates/contextra-engine/src/temporal_filter.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Bi-temporaler Validity-Filter für Post-RRF Fusion-Ergebnisse in Retrieval-Pipelines. |
| `TS:2026-09-07T08:30:00Z` | `crates/contextra-cognition/src/consolidation_executor.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Verbindet Structural Consolidation Pass-Ergebnisse mit der Collection-Mutation-API. |
| `TS:2026-09-07T00:00:00Z` | `crates/contextra-crypto/src/deletion_proof.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Cryptographic deletion proof for GDPR Article 17 compliance verification across storage layers. |
| `TS:2026-09-07T00:00:00Z` | `crates/contextra-vector/benches/flush_threshold_amplification.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Quantifizierung von Schreibvolumen und Latenz-Trade-offs für PENDING_FLUSH_THRESHOLD (50 / 200 / 1.000) |
| `TS:2026-09-06T11:18:35Z (SESSION: 820afd9c)` | `crates/contextra-agent/src/dlq.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Persistent dead-letter queue storage abstraction for failed agent steps. |
| `TS:2026-09-05T00:00:00Z (SESSION: 0dcb9f3b)` | `crates/contextra-db/tests/no_blanket_allow_deprecated.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Automated regression guard ensuring no blanket crate-level `#![allow(deprecated)]` attribute is reintroduced. |
| `TS:2026-09-04T11:41:54Z (SESSION: 9c384478)` | `crates/contextra-vector/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Layer-1 Vektor-Such- & Index-Engine mit HNSW, DiskANN, Quantisierung und SIMD. |
| `TS:2026-09-02T23:19:10Z (SESSION: 088b4a44)` | `crates/contextra-agent/src/step.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Step result structures and AgentTool trait definitions for orchestration. |
| `TS:2026-09-01T23:11:04Z (SESSION: 5a38054a)` | `crates/contextra-agent/src/context.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Workflow execution state context carrying task ID, budget, and memory. |
| `TS:2026-09-01T23:11:04Z (SESSION: 5a38054a)` | `crates/contextra-agent/src/engine.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Deterministic graph-walker orchestrator engine for autonomous agent workflows. |
| `TS:2026-09-01T23:11:04Z (SESSION: 5a38054a)` | `crates/contextra-agent/src/event_source.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Continuous event stream abstractions delivering telemetry/trigger events to agents. |
| `TS:2026-08-31T23:10:00Z (SESSION: 0dcb9f3b)` | `crates/contextra-db/tests/cross_signal_isolation_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Prüft Cross-Signal Snapshot-Isolation in contextra-db während paralleler Writes/Updates. |
| `TS:2026-08-31T22:30:00Z (SESSION: 0dcb9f3b)` | `crates/contextra-db/tests/fault_injection_2pc.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Prüft atomare 2PC-Transaktions-Kompensation und Crash-Recovery (repair_on_open) über alle 4 Sub-Engines. |
| `TS:2026-08-31T21:13:05Z (SESSION: 8427f167)` | `crates/contextra-crypto/src/anti_tamper.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Cold-boot protection and explicit Zeroize discipline for volatile encryption keys. |
| `TS:2026-08-31T21:13:05Z (SESSION: 8427f167)` | `crates/contextra-crypto/src/crypto.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Key Management and AES-256-GCM-SIV authenticated encryption for Contextra data structures. |
| `TS:2026-08-31T21:13:05Z (SESSION: 8427f167)` | `crates/contextra-crypto/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Contextra cryptographic kernel - Layer 1 crate for AEAD block encryption, HKDF key derivation, and WAL integrity. |
| `TS:2026-08-31T21:13:05Z (SESSION: 8427f167)` | `crates/contextra-crypto/src/wal_crypto.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Transparent encrypted WAL chunk provider and constant-time HMAC-SHA256 integrity verifier. |
| `TS:2026-08-31T21:13:05Z (SESSION: 8427f167)` | `crates/contextra-crypto/tests/key_separation_and_edge_cases.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Key separation and cryptographic edge cases test suite for contextra-crypto. |
| `TS:2026-08-31T21:13:05Z (SESSION: 8427f167)` | `crates/contextra-crypto/tests/namespace_isolation.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Namespace isolation test suite for contextra-crypto (SD-09-CRYPTO-002). |
| `TS:2026-08-31T21:13:05Z (SESSION: 8427f167)` | `crates/contextra-crypto/tests/nonce_reuse.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Nonce reuse demonstration and mitigation verification suite. |
| `TS:2026-08-31T21:13:05Z (SESSION: 8427f167)` | `crates/contextra-crypto/tests/proptests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Property-based testing suite for contextra-crypto using proptest. |
| `TS:2026-08-31T00:00:00Z (SESSION: 8a7c2f1e)` | `crates/contextra-agent/tests/budget_race_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Test token budget concurrency and RMW race condition in contextra-agent workflow steps. |
| `TS:2026-08-31T00:00:00Z` | `crates/contextra-cognition/src/maintenance_config.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Konfiguration des MaintenanceSchedulers für Background-Maintenance-Layer. |
| `TS:2026-08-31T00:00:00Z` | `crates/contextra-vector/benches/audit_benchmarks.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Audit Benchmark Suite zur Ermittlung von Durchsatz, Speedup, Latenz-Perzentilen, Pareto-Front und RAM-Footprint |
| `TS:2026-08-31T00:00:00Z` | `crates/contextra-vector/tests/quantize_persistence_audit.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Audit-Testsuite für SQ8 Kendall-Tau Rangkorrelation, Persistence Roundtrips und Mmap Fault-Tolerance |
| `TS:2026-08-31T00:00:00Z` | `crates/contextra-vector/tests/recall_audit.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Audit-Testsuite für HNSW & DiskANN Graph-Korrektheit & Brute-Force Recall |
| `TS:2026-08-31T00:00:00Z` | `crates/contextra-vector/tests/simd_numerical_audit.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Audit-Testsuite für numerische Korrektheit (SIMD vs Skalar vs f64-Referenz) |
| `TS:2026-08-30T22:30:00Z (SESSION: 37b1d991)` | `crates/contextra-vector/tests/mmap_toctou_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Empirische TOCTOU-Testreihen für Mmap Truncation & Unlink/Deletion Szenarien in DiskANN & HNSW. |
| `TS:2026-08-30T22:01:55Z (SESSION: cf1f75c6)` | `crates/contextra-text/src/bm25.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Berechnet mathematisch BM25 Term-Scores und validiert Hyperparameter (k1, b). |
| `TS:2026-08-30T21:55:29Z (SESSION: 10569099)` | `crates/contextra-vector/src/quantize/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | 8-Bit Skalare Quantisierung (SQ8) mit pro-Dimension Min/Max Skalierung. |
| `TS:2026-08-30T21:15:00Z (SESSION: 0dcb9f3b)` | `crates/contextra-engine/src/collection/search/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Suchoperationen (Vector-, Text-, Graph- & Hybrid-Retrieval) für Collection modularisiert nach Familien. |
| `TS:2026-08-30T21:00:00Z (SESSION: 0dcb9f3b)` | `crates/contextra-engine/src/collection/query_builder/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Fluent HybridQueryBuilder Fassade für Konsolidierung aller Search-Signaturen. |
| `TS:2026-08-30T19:50:00Z (SESSION: 20260830)` | `crates/contextra-crypto/benches/crypto_benchmarks.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Criterion benchmark suite for contextra-crypto throughput and latency measurement. |
| `TS:2026-08-30T19:45:00Z (SESSION: 20260830)` | `crates/contextra-crypto/tests/anti_tamper_matrix.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Systematic WAL anti-tamper matrix, single bit-flip analysis, replay attack protection, and constant-time check. |
| `TS:2026-08-30T19:35:00Z (SESSION: 20260830)` | `crates/contextra-crypto/tests/nonce_stress.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Multi-threaded nonce uniqueness stress testing & empirical vs theoretical collision probability verification. |
| `TS:2026-08-30T19:25:00Z (SESSION: 20260830)` | `crates/contextra-crypto/tests/rfc_vectors.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Verification of cryptographic primitives against official RFC and reference test vectors. |
| `TS:2026-08-30T19:00:00Z` | `crates/contextra-graph/src/cascade.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Cascading-Invalidation (Supersedes-Chunk -> Graph-Kanten-Tombstone) |
| `TS:2026-08-30T18:53:53Z (SESSION: 37b1d991)` | `crates/contextra-vector/src/persistence/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Persistenz-Schicht für HNSW-Dateiserialisierung (`.hnsw`) und mmap-basiertes Lesen. |
| `TS:2026-08-29T18:00:00Z` | `crates/contextra-cognition/src/memory_consolidation.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Structural Consolidation Pass & Generative Synthesis Pass Architecture — Memory Consolidation (Near-Duplicate-Detection & Segmentation). |
| `TS:2026-08-29T17:22:29Z (SESSION: 0dcb9f3b)` | `crates/contextra-cognition/src/context.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Kontextfenster-Verwaltung und Token-Budgetierung für RAG-Prompts. |
| `TS:2026-08-29T17:22:29Z (SESSION: 0dcb9f3b)` | `crates/contextra-cognition/src/context_compaction/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Kontextkompaktierung und Zusammenfassung langer Gesprächs- und Dokumentverläufe. |
| `TS:2026-08-29T17:22:29Z (SESSION: 0dcb9f3b)` | `crates/contextra-engine/src/background_workers/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Hintergrund-Worker-Tasks zur TTL-Löschung, Entropie-Pruning und Bereinigung verwaister Transaktionen (Orphan Cleanup). |
| `TS:2026-08-29T17:22:29Z (SESSION: 0dcb9f3b)` | `crates/contextra-engine/src/collection/crud/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | CRUD-Operationen (Insert, Upsert, Update, Delete, Get) für Collection. |
| `TS:2026-08-29T17:22:29Z (SESSION: 0dcb9f3b)` | `crates/contextra-engine/src/collection/maintenance.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Wartungs-, Reparatur- und Bereinigungsoperationen (Index repair, Expiry cleanup, Community detection). |
| `TS:2026-08-29T17:22:29Z (SESSION: 0dcb9f3b)` | `crates/contextra-engine/src/collection/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Sammlung/Collection-Namespace Verwaltung und gemeinsame Hilfsfunktionen. |
| `TS:2026-08-29T17:22:29Z (SESSION: 0dcb9f3b)` | `crates/contextra-engine/src/collection/tests/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Unit-Tests für Collection-CRUD, Indizierung, Repair und Grenzwerte. |
| `TS:2026-08-29T17:22:29Z (SESSION: 0dcb9f3b)` | `crates/contextra-engine/src/filter.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Metadaten-Filterung und Extraktion von Kognitiven MemoryTypes (Episodic, Semantic, Working). |
| `TS:2026-08-29T17:22:29Z (SESSION: 0dcb9f3b)` | `crates/contextra-engine/src/transaction/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Orchestrierung atomarer 4-Index 2-Phase-Commits und kompensierender Transaktionen. |
| `2026-10-01T00:00:00Z` | `crates/contextra-sandbox/src/merge.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Pure, deterministic WASM merge function executor (§4.18) |
| `2026-10-01` | `crates/contextra-engine/src/extraction/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Moduldefinition für Entitätsextraktion (OpenIE & Rule-Based) (Layer 3 - Engine). |
| `2026-10-01` | `crates/contextra-engine/src/extraction/rule_based.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Regelbasierte Entitäts- und Relationsextraktion (Layer 3 - Engine). |
| `2026-10-01` | `crates/contextra-mcp/src/proof_key_env.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Einziger Resolver für DeletionProof-Schlüssel (CONTEXTRA_DELETION_PROOF_KEY / CONTEXTRA_PROOF_KEY) |
| `2026-09-30T00:00:00Z` | `crates/contextra-store/tests/crash_kill_durability.rs` | `ANCHOR` | `TEST:STO-004` | `-` | `DONE` | `0` | // ANCHOR[TEST:STO-004] STATUS:DONE (TS:2026-09-30T00:00:00Z) |
| `2026-09-30` | `crates/contextra-mcp/src/proof_key.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Lösen und Validieren des DeletionProof Schlüssel-Materials aus Umgebungsvariablen. |
| `2026-09-29 (S-01 / T-04)` | `crates/contextra-store/src/manifest/core.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Kernimplementierung des Manifests zum Lesen, Schreiben, Rollover und Reconstruct aktiver SSTables. |
| `2026-09-29 (S-01 / T-04)` | `crates/contextra-store/src/manifest/entry.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Datenstruktur und (De-)Serialisierungslogik für SSTable-Manifest-Einträge (ManifestEntry). |
| `2026-09-28T00:00:00Z (SESSION: e459bd5f)` | `crates/contextra-mvcc/src/tx_buffer.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Shard-basierter Transaktionsbuffer für das Staging von 2-Phase-Commit Index-Operationen, ReadSet-Limits & Watermark-Tracking. |
| `2026-09-28T00:00:00Z` | `crates/contextra-checkpoint/src/hardlink_cloner.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Hardlink-Cloner für Agent-Forking und SSTable CoW-Klone. |
| `2026-09-28T00:00:00Z` | `crates/contextra-mvcc/src/ssi.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | In-memory SSI Read-Set Tracking, Write-Skew-Konfliktvalidierung, Fail-Closed Pruning und atomare Commit-Registrierung. |
| `2026-09-28T00:00:00Z` | `crates/contextra-store/src/tenant_codec.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Multi-Tenant Key Isolation & Encoding für LSM Storage Engine |
| `2026-09-28T00:00:00Z` | `crates/contextra-store/tests/memtable_shard_distribution.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrationstests für MemTable Systempräfix-Hash-Sharding und Scans. |
| `2026-09-28` | `crates/contextra-graph/src/path_rag/snapshot.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Multi-Version Concurrency Control (MVCC) snapshot-isolated PathGraph for PathRAG. |
| `2026-09-28` | `crates/contextra-store/tests/crash_prefix_enumeration.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` |  |
| `2026-09-28` | `crates/contextra-store/tests/model_based_mvcc_flush.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` |  |
| `2026-09-28` | `crates/contextra-store/tests/test_wp02_flush_mvcc_bug.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` |  |
| `2026-09-28` | `crates/contextra-testkit/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Deterministic test utilities, ManualClock, InMemoryStorageEngine, FaultVfs, and ReferenceModel. |
| `2026-09-28` | `crates/contextra-testkit/src/reference_model.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` |  |
| `2026-09-27T22:49:25Z (SESSION: 72f4c80d)` | `crates/contextra-wire/src/adapter.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Zero-copy byte buffer slice wrapper (WireBuffer) for FlatBuffers IPC messages. |
| `2026-09-27T22:49:25Z (SESSION: 72f4c80d)` | `crates/contextra-wire/src/jsonrpc.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Generic JSON-RPC 2.0 protocol request/response structures for Contextra IPC. |
| `2026-09-27T22:49:25Z (SESSION: 72f4c80d)` | `crates/contextra-wire/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Ring 0 Unsafe Island: Auto-generated FlatBuffers IPC bindings and zero-copy adapters. |
| `2026-09-27T22:45:00Z (SESSION: 786dca08)` | `crates/contextra-sys/src/acl_win32.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Win32 ACL restriction and file ownership verification wrappers (Ring 0) |
| `2026-09-27T22:45:00Z (SESSION: 786dca08)` | `crates/contextra-sys/src/vault.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | RAII manager for RAM memory-locked sensitive buffer regions (Ring 0) |
| `2026-09-27T22:42:00Z (SESSION: 7c14554a)` | `crates/contextra-sandbox/src/wasi.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | WASI preview1 host function implementations (fd_read, fd_write, proc_exit, clock_time_get, random_get) |
| `2026-09-27T19:30:00Z` | `crates/contextra-rank/tests/conformal_tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integration and invariant verification test suite for Adaptive Conformal Prediction (conformal.rs). |
| `2026-09-27T00:00:00Z` | `crates/contextra-adapt/tests/pid_anti_windup_tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrationstests für conditional Back-Calculation Anti-Windup im PID-Regler. |
| `2026-09-27T00:00:00Z` | `crates/contextra-crypto/src/ed25519_proof.rs` | `AI-TAG` | `-` | `welle4-p17` | `RESOLVED` | `-` | /// AI-TAG[TODO][RESOLVED] (TS: 2026-09-27T00:00:00Z) (SESSION: welle4-p17): In `deletion_proof.rs` das `pub signature_version: u8` Feld |
| `2026-09-27T00:00:00Z` | `crates/contextra-store/src/compaction/adaptive.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Workload-adaptive Compaction-Strategie (EcoTune / ArceKV inspiriert) |
| `2026-09-26T02:30:00Z` | `crates/contextra-store/tests/wal_lifecycle_crash_point_matrix.rs` | `ANCHOR` | `TEST:STO-WAL-LIFECYCLE-MATRIX` | `chaos-matrix` | `DONE` | `0` | // ANCHOR[TEST:STO-WAL-LIFECYCLE-MATRIX] STATUS:DONE (TS:2026-09-26T02:30:00Z) (SESSION: chaos-matrix) |
| `2026-09-26T00:00:00Z (SESSION: KV-BRIDGE-ZERO-COPY-IMPL)` | `crates/contextra-infer-candle/src/kv_bridge.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | KvBridgeAdapter verbindet Retrieval-Chunks mit mandantenisoliertem KV-Cache-Store (RAM Tier 1 + LSM Tier 2 Spill via KvBridgeStorage Port). |
| `2026-09-26T00:00:00Z` | `crates/contextra-ports/src/kv_bridge_port.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | KvBridgeStorage Port-Trait (Ring 0) zur Abstraktion von Tier-2 KV-Cache Persistence für Ring-2 Adaptern. |
| `2026-09-25T00:00:00Z` | `crates/contextra-checkpoint/tests/checkpoint_systematic_crash.rs` | `ANCHOR` | `TEST:CHK-005` | `-` | `DONE` | `0` | // ANCHOR[TEST:CHK-005] STATUS:DONE (TS:2026-09-25T00:00:00Z) |
| `2026-09-25T00:00:00Z` | `crates/contextra-sandbox/src/approval.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Human Approval Data Model & Pure State Machine for WASM Guest Execution (§4.18) |
| `2026-09-24` | `crates/contextra-graph/src/ppr/snapshot.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Multi-Version Concurrency Control (MVCC) snapshot-isolated PPR computation. |
| `2026-09-22T00:00:00Z` | `crates/contextra-infer-candle/src/inference/prefix_reuse.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Prefix reuse helper structs, context, and key/seed builders for KV cache stage B (Spec §9.2). |
| `2026-09-22T00:00:00Z` | `crates/contextra-infer-candle/src/kv_state.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | KvState implementation for native Candle Llama model KV cache management (Spec §9.2 Stufe B). |
| `2026-09-22T00:00:00Z` | `crates/contextra-infer-candle/src/model/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Forked Llama model module with direct KvState access (Spec §9.2 Stufe B). |
| `2026-09-22T00:00:00Z` | `crates/contextra-infer-candle/src/model/quantized_llama.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Forked Candle Quantized Llama model with explicit KvState management (Spec §9.2 Stufe B). |
| `2026-09-22T00:00:00Z` | `crates/contextra-infer-candle/tests/kv_prefix_reuse_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integration test suite for KV cache stage B prefix reuse, counters, and tenant isolation (Spec §9.2). |
| `2026-09-22T00:00:00Z` | `crates/contextra-infer-candle/tests/kv_stage_b_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Unit and integration tests for Stage B KvState and forked Llama KV cache integration. |
| `2026-09-19T20:12:00Z (SESSION: 01c5be8b)` | `crates/contextra-testkit/src/fault_vfs.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Deterministic I/O error injector and Virtual File System test utility. |
| `2026-09-19T20:12:00Z (SESSION: 01c5be8b)` | `crates/contextra-testkit/src/in_memory_store.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | In-Memory StorageEngine implementation for fast, lightweight testing. |
| `2026-09-19T20:12:00Z (SESSION: 01c5be8b)` | `crates/contextra-testkit/src/manual_clock.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Deterministic Clock Mock for unit and integration testing without real sleep. |
| `2026-09-18T12:00:00Z` | `crates/contextra-graph/src/csr/graph_read.rs` | `AI-TAG` | `-` | `e095d708` | `RESOLVED` | `-` | // AI-TAG[RESOLVED][IP-08-BUDGET-COUPLING](TS:2026-09-18T12:00:00Z)(SESSION:e095d708): Connected to global ResourceTracker when cross-crate tracker handle is configured. |
| `2026-09-18T00:00:00Z` | `crates/contextra-store/tests/chaos_power_cut.rs` | `ANCHOR` | `TEST:STO-003` | `a4f61283` | `DONE` | `0` | // ANCHOR[TEST:STO-003] STATUS:DONE (TS:2026-09-18T00:00:00Z) (SESSION: a4f61283) |
| `2026-09-18T00:00:00Z` | `crates/contextra-store/tests/crash_recovery.rs` | `ANCHOR` | `TEST:STO-001` | `a4f61283` | `DONE` | `0` | // ANCHOR[TEST:STO-001] STATUS:DONE (TS:2026-09-18T00:00:00Z) (SESSION: a4f61283) |
| `2026-09-18T00:00:00Z` | `crates/contextra-store/tests/fault_injection_recovery.rs` | `ANCHOR` | `TEST:STO-002` | `a4f61283` | `DONE` | `0` | // ANCHOR[TEST:STO-002] STATUS:DONE (TS:2026-09-18T00:00:00Z) (SESSION: a4f61283) |
| `2026-09-18T00:00:00Z` | `crates/contextra-store/tests/manifest_crash_no_resurrection.rs` | `ANCHOR` | `TEST:STO-005` | `a4f61283` | `DONE` | `0` | // ANCHOR[TEST:STO-005] STATUS:DONE (TS:2026-09-18T00:00:00Z) (SESSION: a4f61283) |
| `2026-09-18T00:00:00Z` | `crates/contextra-store/tests/wal_systematic_crash.rs` | `ANCHOR` | `TEST:STO-004` | `a4f61283` | `DONE` | `0` | // ANCHOR[TEST:STO-004] STATUS:DONE (TS:2026-09-18T00:00:00Z) (SESSION: a4f61283) |
| `2026-09-16T21:00:00Z (SESSION: IP-07)` | `crates/contextra-types/src/tombstone.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Trait und Referenzimplementierung für Tombstone-Semantik (IP-07 / ADR-041). |
| `2026-09-16T16:47:30Z` | `crates/contextra-py/src/lib.rs` | `REVIEW-PASS` | `-` | `29edb6a4` | `-` | `-` | // REVIEW-PASS[1/2] Systematischer Review der contextra-py PyO3 FFI Bindings (PRÜFER-KONTEXT: FRESH) (TS: 2026-09-16T16:47:30Z) (SESSION: 29edb6a4) |
| `2026-09-16T16:24:19Z` | `crates/contextra-infer-ollama/src/lib.rs` | `REVIEW-PASS` | `-` | `4b816c9a` | `PASS` | `-` | // REVIEW-PASS[2/2] STATUS:PASS (TS: 2026-09-16T16:24:19Z) (SESSION: 4b816c9a) PRÜFER-KONTEXT: FRESH - Independent diff review verified: prompt injection XML-escaping, retry & backoff error classification, forbid(unsafe_code) invariant, and 91 tests green. |
| `2026-09-16T16:24:18Z` | `crates/contextra-infer-onnx/src/lib.rs` | `REVIEW-PASS` | `-` | `d3856baa` | `PASS` | `-` | // REVIEW-PASS[3/3] STATUS:PASS (TS: 2026-09-16T16:24:18Z) (SESSION: d3856baa) PRÜFER-KONTEXT: FRESH - Independent review verified feature gate isolation, zero unsafe in production, spawn_blocking non-starvation model, and domain scoring invariants (APM-22, APM-23, APM-24). |
| `2026-09-16T16:23:23Z` | `crates/contextra-checkpoint/src/lib.rs` | `REVIEW-PASS` | `-` | `8d62c439` | `-` | `-` | // REVIEW-PASS[2/2] (TS: 2026-09-16T16:23:23Z) (SESSION: 8d62c439) PRÜFER-KONTEXT: FRESH |
| `2026-09-16T16:17:21Z` | `crates/contextra-router/src/lib.rs` | `REVIEW-PASS` | `-` | `cec8b8e9` | `-` | `-` | // REVIEW-PASS[1/2] (TS: 2026-09-16T16:17:21Z) (SESSION: cec8b8e9) (PRÜFER-KONTEXT: FRESH) |
| `2026-09-16T16:13:00Z (SESSION: afafdd44)` | `crates/contextra-infer-candle/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Crate root for contextra-infer-candle native GGUF inference backend. |
| `2026-09-16T16:13:00Z` | `crates/contextra-infer-candle/src/lib.rs` | `REVIEW-PASS` | `AGT-CANDLE-d495a019` | `afafdd44` | `-` | `0` | // REVIEW-PASS[1/2] (ID: AGT-CANDLE-d495a019) (TS: 2026-09-16T16:13:00Z) (SESSION: afafdd44) PRÜFER-KONTEXT: FRESH |
| `2026-09-16T00:00:00Z` | `crates/contextra-wire/tests/ipc_tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrationstests, Fault-Injection und Nebenläufigkeitstests für FlatBuffers IPC (contextra-wire) |
| `2026-09-15T16:46:26Z` | `crates/contextra-agent/src/lib.rs` | `REVIEW-PASS` | `AGT-AGENT-692d9982` | `692d9982` | `PASS` | `0` | // REVIEW-PASS[1/2] STATUS:PASS (ID: AGT-AGENT-692d9982) (TS: 2026-09-15T16:46:26Z) (SESSION: 692d9982) (PRÜFER-KONTEXT: FRESH) |
| `2026-09-15T16:10:40Z (SESSION: ec33599e)` | `crates/contextra-infer-onnx/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | In-process ONNX Embedding Engine (Layer 3 im 5-Schichten-DAG). |
| `2026-09-15T16:10:40Z (SESSION: ec33599e)` | `crates/contextra-infer-onnx/src/reranker/config.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Cross-Encoder Reranking Konfiguration und Ergebnisse. |
| `2026-09-15T16:10:40Z (SESSION: ec33599e)` | `crates/contextra-infer-onnx/src/reranker/cross_encoder.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Haupt-Reranker-API (`CrossEncoderReranker`) und Backend-Abstraktion. |
| `2026-09-15T16:10:40Z (SESSION: ec33599e)` | `crates/contextra-infer-onnx/src/reranker/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Cross-Encoder Reranking für Post-RRF Präzisionsverbesserung. |
| `2026-09-15T16:10:40Z (SESSION: ec33599e)` | `crates/contextra-infer-onnx/src/reranker/onnx.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Real ONNX Runtime Cross-Encoder Inferenz-Backend. |
| `2026-09-15T16:10:40Z (SESSION: ec33599e)` | `crates/contextra-infer-onnx/src/reranker/tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Unit-Tests für Cross-Encoder Reranker. |
| `2026-09-15T16:07:56Z (SESSION: 5d958ef0)` | `crates/contextra-graph/src/edge_reinforcement_buffer.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Akkumuliert Co-Occurrence- und Traversal-Update-Signale für asynchronen Flush in CSR-Graph (F-03) |
| `2026-09-15T16:00:00Z (SESSION: acf8fe72)` | `crates/contextra-sandbox/src/capabilities.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Capability Whitelist & Configuration for WASM Execution Boundary |
| `2026-09-15T16:00:00Z (SESSION: acf8fe72)` | `crates/contextra-sandbox/src/executor.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | WASM execution engine with WASI and fuel enforcement |
| `2026-09-15T15:09:43Z (SESSION: 2e382e86)` | `crates/contextra-checkpoint/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | RAII CheckpointGuard + persistente Snapshot-Verwaltung (Re-Exports) |
| `2026-09-15T15:09:43Z` | `crates/contextra-checkpoint/src/lib.rs` | `REVIEW-PASS` | `-` | `2e382e86` | `-` | `-` | // REVIEW-PASS[1/2] (TS: 2026-09-15T15:09:43Z) (SESSION: 2e382e86) PRÜFER-KONTEXT: FRESH |
| `2026-09-15T14:48:58Z` | `crates/contextra-infer-ollama/src/lib.rs` | `REVIEW-PASS` | `-` | `1d6e3667` | `PASS` | `-` | // REVIEW-PASS[1/2] STATUS:PASS (TS: 2026-09-15T14:48:58Z) (SESSION: 1d6e3667) PRÜFER-KONTEXT: FRESH - Tier 3 deep audit verified: zero unsafe, proptests green, 10x 8-thread concurrency stress test green, prompt injection evasion matrix passed. |
| `2026-09-15T14:45:00Z (SESSION: 527bbb50)` | `crates/contextra-rank/tests/calibration_stress_and_fault_tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Stress, fault-injection, and multi-threading concurrency tests for contextra-rank calibration. |
| `2026-09-15T00:00:00Z` | `crates/contextra-adapt/tests/pid_stability.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Stabilitätstest des PID-Reglers mit Bekannter Sprungantwort (Settling Time, Overshoot, Steady-State Error). |
| `2026-09-15T00:00:00Z` | `crates/contextra-ports/src/graph_index.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | GraphIndex Trait & GraphIndexStats für CSR-basierte Entity-Relation-Graph-Operationen. |
| `2026-09-15T00:00:00Z` | `crates/contextra-ports/src/lifecycle.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | GroundingValidator, ResponseGroundingValidator & ContextPreparer Trait-Definitionen. |
| `2026-09-15T00:00:00Z` | `crates/contextra-ports/src/observability.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Observability-Modul für Grounding-Validierung. |
| `2026-09-15T00:00:00Z` | `crates/contextra-ports/src/text_index.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | TextIndex & SegmentSynthesizer Trait-Definitionen für BM25/Inverted Index. |
| `2026-09-15T00:00:00Z` | `crates/contextra-ports/src/vector_index.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | VectorIndex Trait & VectorIndexStats für HNSW/Vektor-Indizes. |
| `2026-09-15` | `crates/contextra-db/tests/proptest_search_invariants.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Property-based Tests für Retrieval- & Search-Invarianten in contextra-db (RRF, BM25, End-to-End). |
| `2026-09-13T14:29:07Z` | `crates/contextra-mcp/src/io.rs` | `AI-TAG` | `AGT-MCP-782aa62e` | `23626761` | `RESOLVED` | `0` | // AI-TAG[SMELL][RESOLVED] Missing inactivity timeout on stdio read_line_bounded (ID: AGT-MCP-782aa62e) (TS: 2026-09-13T14:29:07Z) (SESSION: 23626761) |
| `2026-09-13T01:45:00Z` | `crates/contextra-infer-ollama/src/lib.rs` | `REVIEW-PASS` | `-` | `6e371f4e` | `PASS` | `-` | // REVIEW-PASS[3/3] STATUS:PASS (TS: 2026-09-13T01:45:00Z) (SESSION: 6e371f4e) PRÜFER-KONTEXT: FRESH - Tier 3 deep audit complete: verified prompt injection structural isolation, proptest evasion matrix, concurrency stress tests, and ML calibration provenance. |
| `2026-09-13T01:42:00Z (SESSION: 50c8c755)` | `crates/contextra-infer-candle/tests/kv_bridge_and_stress_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integration tests for KV-Bridge fail-open behavior, fingerprint mismatches, GASP grounding, and backpressure saturation. |
| `2026-09-13T01:35:00Z` | `crates/contextra-crypto/src/crypto.rs` | `REVIEW-PASS` | `AGT-CRYPTO-81653b64` | `dd990e1d` | `PASS` | `0` | // REVIEW-PASS[8/3] STATUS:PASS (ID: AGT-CRYPTO-81653b64) (TS: 2026-09-13T01:35:00Z) (SESSION: dd990e1d) (PRÜFER-KONTEXT: FRESH) |
| `2026-09-13T01:33:57Z` | `crates/contextra-store/src/lib.rs` | `REVIEW-PASS` | `-` | `60ca322c` | `-` | `-` | // REVIEW-PASS[1/2] Systematischer Tiefen-Audit von contextra-store (PRÜFER-KONTEXT: FRESH) (TS: 2026-09-13T01:33:57Z) (SESSION: 60ca322c) |
| `2026-09-13T01:25:00Z` | `crates/contextra-text/src/lib.rs` | `REVIEW-PASS` | `-` | `89a61398` | `-` | `-` | // REVIEW-PASS[2/2] Tier-2 audit verified: gate-stack green, 0 unsafe, APM-14/16/22/23/24/36 validated, 3x concurrency runs clean. (TS: 2026-09-13T01:25:00Z) (SESSION: 89a61398) (PRÜFER-KONTEXT: FRESH) |
| `2026-09-12T18:43:13Z` | `crates/contextra-engine/src/collection/maintenance.rs` | `AI-TAG` | `AGT-DB-f18d79a2` | `-` | `RESOLVED` | `0` | // AI-TAG[SMELL][MAJOR] RESOLVED: AGT-DB-f18d79a2 — reap_expired_documents uses cursor-based batch pagination to avoid 10k silent truncation limit (TS: 2026-09-12T18:43:13Z) |
| `2026-09-12T00:00:00Z (SESSION: BACKPRESSURE-CONTRACT-D1)` | `crates/contextra-infer-candle/src/embedding.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Native Candle ML vector embedding client implementation. |
| `2026-09-12T00:00:00Z (SESSION: BACKPRESSURE-CONTRACT-D1)` | `crates/contextra-infer-candle/src/inference.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Candle LLM text generator client implementing LlmTextGenerator. |
| `2026-09-12T00:00:00Z (SESSION: BACKPRESSURE-CONTRACT-D1)` | `crates/contextra-infer-candle/src/inference/core.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Candle LLM text generator client implementing LlmTextGenerator. |
| `2026-09-12T00:00:00Z` | `crates/contextra-types/src/model_fingerprint.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Canonical ModelFingerprint type definition shared across workspace crates. |
| `2026-09-11T19:01:58Z` | `crates/contextra-infer-ollama/src/lib.rs` | `REVIEW-PASS` | `AGT-OLLAMA-4d606464` | `089dd3c0` | `PASS` | `0` | // REVIEW-PASS[2/2] STATUS:PASS (ID: AGT-OLLAMA-4d606464) (TS: 2026-09-11T19:01:58Z) (SESSION: 089dd3c0) PRÜFER-KONTEXT: FRESH - Clarified historical "zero unsafe" status observation vs compile-time enforced invariant via forbid(unsafe_code). |
| `2026-09-11T16:00:00Z` | `crates/contextra-infer-candle/tests/embedding_normalization_proptest.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Property-based tests for numerical normalization, finite outputs, and empty/whitespace input edge cases. |
| `2026-09-11T16:00:00Z` | `crates/contextra-infer-candle/tests/gguf_corruption_and_batch_boundary_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Error path and boundary tests for GGUF loading, quantization mismatch, batch boundaries, and concurrent hot-swap. |
| `2026-09-11T14:45:00Z` | `crates/contextra-infer-ollama/src/lib.rs` | `REVIEW-PASS` | `-` | `089dd3c0` | `PASS` | `-` | // REVIEW-PASS[1/2] STATUS:PASS (TS: 2026-09-11T14:45:00Z) (SESSION: 089dd3c0) PRÜFER-KONTEXT: FRESH - Verified prompt injection safety (xml_escape, build_rag_prompt), HTTP retry policy, zero unsafe, and test suite green. |
| `2026-09-11T14:30:00Z` | `crates/contextra-agent/src/dlq.rs` | `AI-TAG` | `AGT-AGENT-49bfd02e` | `-` | `RESOLVED` | `0` | // AI-TAG[SMELL][MINOR] RESOLVED: AGT-AGENT-49bfd02e — Replaced non-atomic last_tx_id + 1 read with OnceCell initialized AtomicU64 fetch_add. (TS: 2026-09-11T14:30:00Z) |
| `2026-09-11T12:00:00Z` | `crates/contextra-adapt/src/lyapunov.rs` | `AI-TAG` | `AGT-ROUTER-00808347` | `21a8d3e8` | `RESOLVED` | `0` | // AI-TAG[RESOLVED][MINOR] Added per-bin contribution clipping (`MAX_BIN_KL_CONTRIBUTION = 10.0`) to prevent numerical instability during KL divergence calculations under extreme distribution shift. (ID: AGT-ROUTER-00808347) (TS: 2026-09-11T12:00:00Z) (SESSION: 21a8d3e8) |
| `2026-09-11T10:21:34Z (SESSION: 31ada253)` | `crates/contextra-store/src/compaction/config.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Size-Tiered Compaction Strategy (STCS) für SSTables |
| `2026-09-11T00:00:00Z (SESSION: JULES-20260911-MUTATION-HARDENING)` | `crates/contextra-rank/tests/isotonic_mutation_hardening_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Mutation hardening test suite for IsotonicCalibrator (PAVA/ECE). |
| `2026-09-11T00:00:00Z` | `crates/contextra-adapt/src/pid.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Adaptive Reranking candidate pool-size regulation via PID latency control (F-08 & P11). |
| `2026-09-11` | `crates/contextra-infer-candle/tests/real_inference_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integration tests for Candle real forward-pass GGUF LLM and Bert embedding inference. |
| `2026-09-11` | `crates/contextra-store/src/manifest/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Append-Only Manifest-Protokolldatei zur Verfolgung gültiger SSTables für Crash-Safety. |
| `2026-09-10T23:48:00Z` | `crates/contextra-text/src/lib.rs` | `REVIEW-PASS` | `-` | `f3f5ff38` | `-` | `-` | // REVIEW-PASS[1/2] Re-verified gate-stack, zero unsafe, APM-7 slicing safety, and chaos engineering scenarios. (TS: 2026-09-10T23:48:00Z) (SESSION: f3f5ff38) (PRÜFER-KONTEXT: FRESH) |
| `2026-09-10T19:35:00Z` | `crates/contextra-crypto/src/crypto.rs` | `REVIEW-PASS` | `TEST:CRY-001` | `b434cc40` | `PASS` | `6` | // REVIEW-PASS[7/3] STATUS:PASS (ID: TEST:CRY-001) (TS: 2026-09-10T19:35:00Z) (SESSION: b434cc40) |
| `2026-09-10T19:25:24Z (SESSION: ae8c2fb9)` | `crates/contextra-mcp/src/bin/contextra-mcp-server.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Binary Entry Point for Contextra MCP Stdio JSON-RPC Server |
| `2026-09-10T19:25:24Z (SESSION: ae8c2fb9)` | `crates/contextra-mcp/src/config.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Dynamic Provider Construction for Embedding & LLM backends (Ollama, ONNX, Candle, Mock) |
| `2026-09-10T19:25:24Z (SESSION: ae8c2fb9)` | `crates/contextra-mcp/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | stdio JSON-RPC 2.0 MCP-Server (kein HTTP! ADR-010) |
| `2026-09-10T19:25:24Z (SESSION: ae8c2fb9)` | `crates/contextra-mcp/src/prompt_injection.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Prompt-Injection-Erkennung & Quarantäne-System für MCP-Server |
| `2026-09-10T19:25:24Z (SESSION: ae8c2fb9)` | `crates/contextra-mcp/src/protocol.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | MCP JSON-RPC 2.0 Protokoll-Typen & DTO-Abbildung für Contextra |
| `2026-09-10T19:25:24Z (SESSION: ae8c2fb9)` | `crates/contextra-mcp/src/sandbox.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | MCP Sandbox & Zero-Trust Tool Isolation Layer |
| `2026-09-10T19:23:40Z` | `crates/contextra-graph/src/lib.rs` | `REVIEW-PASS` | `-` | `bd6ff800` | `PASS` | `-` | // REVIEW-PASS[1/2] STATUS:PASS (TS: 2026-09-10T19:23:40Z) (SESSION: bd6ff800) |
| `2026-09-10T19:22:55Z (SESSION: 0b2ff57d)` | `crates/contextra-py/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | PyO3 FFI bindings bridging Contextra embedded vector DB functionality to Python. |
| `2026-09-10T19:21:35Z` | `crates/contextra-text/src/morphology/tests.rs` | `REVIEW-PASS` | `TEST:TXT-001` | `4dd1c98c` | `PASS` | `8` | // REVIEW-PASS[2/2] STATUS:PASS (ID: TEST:TXT-001) (TS: 2026-09-10T19:21:35Z) (SESSION: 4dd1c98c) |
| `2026-09-10T19:16:25Z (SESSION: 3f3e4637)` | `crates/contextra-router/src/dispatch.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Client-seitiger MCP-Dispatch-Mechanismus über Stdio JSON-RPC 2.0 (ADR-010). |
| `2026-09-10T19:16:25Z (SESSION: 3f3e4637)` | `crates/contextra-router/src/outcome.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Outcome-Typen und DecisionId-Identifier für konformale Router-Kalibrierung. |
| `2026-09-10T19:16:25Z (SESSION: 3f3e4637)` | `crates/contextra-router/src/profile.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | SLM-Profildefinitionen und konformale Quantil-Kalibrierung (Gibbs & Candès). |
| `2026-09-10T19:16:25Z (SESSION: 3f3e4637)` | `crates/contextra-router/src/router/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Haupt-Routing-Engine für Hybrid-Search-Kontext auf SLM-Profile. |
| `2026-09-10T19:16:25Z (SESSION: 3f3e4637)` | `crates/contextra-router/src/serde_helpers.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Serde-Hilfsfunktionen für deterministische JSON-Serialisierung. |
| `2026-09-10T00:00:00Z (SESSION: 61b93a6f)` | `crates/contextra-graph/src/provenance.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Herkunftsnachweis für Graph-Kanten (DocEdgeIndex & EdgeProvenance) |
| `2026-09-09T22:00:00Z` | `crates/contextra-db/tests/split_brain_vector_orphan_test.rs` | `ANCHOR` | `TEST:SPLIT_BRAIN_CONSISTENCY` | `504d02fc` | `IN_PROGRESS` | `0` | // ANCHOR[TEST:SPLIT_BRAIN_CONSISTENCY] STATUS:IN_PROGRESS (TS:2026-09-09T22:00:00Z) (SESSION: 504d02fc) |
| `2026-09-09T15:49:44Z (SESSION: 5b65397f)` | `crates/contextra-adapt/src/lyapunov.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Proaktiver Distributional-Drift-Wächter via Lyapunov-Exponenten über KL-Divergenzen. |
| `2026-09-09T15:45:22Z (SESSION: 6cae458a)` | `crates/contextra-infer-candle/src/embedding_provider.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Trait-based EmbeddingProvider implementation for CandleEmbedClient. |
| `2026-09-09T15:45:22Z (SESSION: 6cae458a)` | `crates/contextra-infer-candle/src/gasp.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | GASP Grounding-Aware Sensitivity by Perturbation post-hoc hallucination validator. |
| `2026-09-09T15:45:22Z (SESSION: 6cae458a)` | `crates/contextra-infer-candle/src/gguf_loader.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | GGUF model container header and metadata parser for Candle models. |
| `2026-09-09T15:45:22Z (SESSION: 6cae458a)` | `crates/contextra-infer-candle/src/model_registry.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Model fingerprinting and CandleQuantization definitions. |
| `2026-09-09T14:43:31Z (SESSION: a69d21e4)` | `crates/contextra-types/src/types/domain/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Kanonische Domain-Typen (DocId, EntityId, TxId, TenantId, Embedding, DistanceMetric, Edge, Entity). |
| `2026-09-09T13:22:45Z` | `crates/contextra-text/src/morphology/tests.rs` | `REVIEW-PASS` | `TEST:TXT-001` | `dc71d70` | `PASS` | `8` | // REVIEW-PASS[2/2] STATUS:PASS (ID: TEST:TXT-001) (TS: 2026-09-09T13:22:45Z) (SESSION: dc71d70) |
| `2026-09-09T13:17:00Z` | `crates/contextra-crypto/src/kv_segment/eviction_worker.rs` | `AI-TAG` | `AGT-CRYPTO-edaee52e` | `a413a598` | `RESOLVED` | `0` | // AI-TAG[CONCURRENCY][MAJOR][RESOLVED] EvictionWorker is Sync via Mutex protection of sender and handle (ID: AGT-CRYPTO-edaee52e) (TS: 2026-09-09T13:17:00Z) (SESSION: a413a598) |
| `2026-09-09T13:17:00Z` | `crates/contextra-crypto/src/kv_segment/segment.rs` | `AI-TAG` | `AGT-CRYPTO-fae9dd56` | `a413a598` | `RESOLVED` | `0` | // AI-TAG[CRYPTO][MAJOR][RESOLVED] Fail fast on missing encrypted payload/nonce instead of dummy zero nonce (ID: AGT-CRYPTO-fae9dd56) (TS: 2026-09-09T13:17:00Z) (SESSION: a413a598) |
| `2026-09-09T12:44:49Z (SESSION: c74a1828)` | `crates/contextra-infer-candle/tests/gasp_mutant_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Additional unit tests targeting mutants in GaspValidator and GaspConfig. |
| `2026-09-09T12:44:49Z (SESSION: c74a1828)` | `crates/contextra-infer-candle/tests/gguf_loader_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Unit tests for GGUF metadata parsing error paths. |
| `2026-09-09T12:44:49Z (SESSION: c74a1828)` | `crates/contextra-infer-candle/tests/proptest_candle.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Property-based tests for contextra-infer-candle components (fingerprinting, GaspValidator, and clients). |
| `2026-09-09T12:39:30Z` | `crates/contextra-text/src/morphology/tests.rs` | `REVIEW-PASS` | `TEST:TXT-001` | `6ccc1466` | `PASS` | `8` | // REVIEW-PASS[2/2] STATUS:PASS (ID: TEST:TXT-001) (TS: 2026-09-09T12:39:30Z) (SESSION: 6ccc1466) |
| `2026-09-09T12:37:35Z (SESSION: 20c1aaf4)` | `crates/contextra-rank/tests/calibration_deep_tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Deep integration, proptest, and adversarial test suite for contextra-rank calibration. |
| `2026-09-09T12:36:33Z` | `crates/contextra-agent/src/lib.rs` | `REVIEW-PASS` | `AGT-AGENT-266186df` | `3db4fa31` | `PASS` | `1` | // REVIEW-PASS[2/2] STATUS:PASS (ID: AGT-AGENT-266186df) (TS: 2026-09-09T12:36:33Z) (SESSION: 3db4fa31) |
| `2026-09-09T00:00:00Z (SESSION: CANDLE-EMBEDDING-PROVIDER)` | `crates/contextra-infer-candle/tests/embedding_provider_conformance.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Conformance integration tests for CandleEmbedClient as EmbeddingProvider. |
| `2026-09-08T00:00:00Z` | `crates/contextra-crypto/src/anti_tamper.rs` | `AI-TAG` | `AGT-CRYPTO-7519b7cd` | `a413a598` | `RESOLVED` | `0` | // AI-TAG[CORRECTNESS][MAJOR][RESOLVED] Refactored zeroize test to use safe Accessor API (ID: AGT-CRYPTO-7519b7cd) (TS: 2026-09-08T00:00:00Z) (SESSION: a413a598) |
| `2026-09-07T06:15:00Z` | `crates/contextra-vector/src/diskann/build.rs` | `AI-TAG` | `-` | `f04imm01` | `RESOLVED` | `-` | /// AI-TAG[RESOLVED] Echte inkrementelle Streaming-DiskANN Implementierung mit Beam-Search, RNG-Pruning und Rückwärts-Kanten-Kompression. (TS:2026-09-07T06:15:00Z) (SESSION: f04imm01) |
| `2026-09-07T06:00:00Z` | `crates/contextra-infer-ollama/src/importance.rs` | `AI-TAG` | `AGT-OLLAMA-14c0c140` | `jules` | `RESOLVED` | `0` | // AI-TAG[ML-SCORING][MAJOR] RESOLVED: Score importance enriches output with model_id provenance and optional calibrated_confidence via IsotonicCalibrator. Post-hoc outcome feedback interface record_importance_outcome added (ID: AGT-OLLAMA-14c0c140) (TS: 2026-09-07T06:00:00Z) (SESSION: jules) |
| `2026-09-07` | `crates/contextra-engine/src/extraction/open_ie.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | LLM-basierte OpenIE-Entitätsextraktion aus Texten. |
| `2026-09-07` | `crates/contextra-engine/src/extraction/tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Unit-Tests für OpenIE Entitätsextraktion. |
| `2026-09-07` | `crates/contextra-engine/src/extraction/types.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Datentypen für OpenIE Entitätsextraktion. |
| `2026-09-06T12:00:00Z` | `crates/contextra-infer-ollama/src/context_prefixer.rs` | `AI-TAG` | `AGT-OLLAMA-47e6619b` | `e4f906ee` | `RESOLVED` | `0` | // AI-TAG[TESTING][MINOR] RESOLVED: AGT-OLLAMA-47e6619b — compute_max_prefix_chars extrahiert & Unit/Prompt-Boundary-Tests ergänzt (TS: 2026-09-06T12:00:00Z) (SESSION: e4f906ee) |
| `2026-09-06T12:00:00Z` | `crates/contextra-infer-onnx/src/reranker/onnx.rs` | `AI-TAG` | `AGT-EMBED-62093e61` | `-` | `RESOLVED` | `0` | // AI-TAG[CALIBRATION][MINOR] AGT-EMBED-62093e61 [RESOLVED] (TS: 2026-09-06T12:00:00Z) |
| `2026-09-06T11:19:00Z` | `crates/contextra-infer-onnx/src/reranker/mod.rs` | `REVIEW-PASS` | `-` | `8efa6210` | `PASS` | `-` | // REVIEW-PASS[2/2] STATUS:PASS (TS: 2026-09-06T11:19:00Z) (SESSION: 8efa6210) PRÜFER-KONTEXT: FRESH - Verified ML domain APM alignment (APM-22, APM-23, APM-24), zero-unsafe in production, and hermetic feature isolation. |
| `2026-09-06T11:18:35Z` | `crates/contextra-agent/src/dlq.rs` | `AI-TAG` | `AGT-AGENT-0399362d` | `820afd9c` | `RESOLVED` | `0` | // AI-TAG[INVENTORY-DRIFT][MINOR] RESOLVED: AGT-AGENT-0399362d — Documented dlq.rs inventory drift in audit report. (TS: 2026-09-06T11:18:35Z) (SESSION: 820afd9c) |
| `2026-09-06T11:17:31Z` | `crates/contextra-crypto/src/crypto.rs` | `REVIEW-PASS` | `TEST:CRY-001` | `8157a40e` | `PASS` | `6` | // REVIEW-PASS[6/3] STATUS:PASS (ID: TEST:CRY-001) (TS: 2026-09-06T11:17:31Z) (SESSION: 8157a40e) |
| `2026-09-06T11:17:24Z` | `crates/contextra-text/src/morphology/tests.rs` | `REVIEW-PASS` | `TEST:TXT-001` | `9fd3f17f` | `PASS` | `8` | // REVIEW-PASS[2/2] STATUS:PASS (ID: TEST:TXT-001) (TS: 2026-09-06T11:17:24Z) (SESSION: 9fd3f17f) |
| `2026-09-04T11:42:28Z` | `crates/contextra-infer-onnx/src/reranker/mod.rs` | `REVIEW-PASS` | `-` | `3e5150c8` | `PASS` | `-` | // REVIEW-PASS[1/2] STATUS:PASS (TS: 2026-09-04T11:42:28Z) (SESSION: 3e5150c8) PRÜFER-KONTEXT: FRESH - Verified CrossEncoderReranker passthrough fallback, candidate limit bounds, and zero-unsafe invariants. |
| `2026-09-03T19:40:00Z` | `crates/contextra-infer-onnx/src/lib.rs` | `REVIEW-PASS` | `-` | `6da6a1c8` | `PASS` | `-` | // REVIEW-PASS[2/2] STATUS:PASS (TS: 2026-09-03T19:40:00Z) (SESSION: 6da6a1c8) PRÜFER-KONTEXT: FRESH - Verified Chaos Engineering fault tolerance, hermetic feature gate, and zero-unsafe invariants. |
| `2026-09-03T19:36:00Z` | `crates/contextra-text/src/morphology/tests.rs` | `REVIEW-PASS` | `TEST:TXT-001` | `87124619` | `PASS` | `8` | // REVIEW-PASS[2/2] STATUS:PASS (ID: TEST:TXT-001) (TS: 2026-09-03T19:36:00Z) (SESSION: 87124619) |
| `2026-09-03T19:31:53Z` | `crates/contextra-crypto/src/anti_tamper.rs` | `AI-TAG` | `AGT-CRYPTO-dd984bc2` | `a413a598` | `RESOLVED` | `0` | // AI-TAG[SECURITY][MINOR][RESOLVED] ConstantTimeEq used in PartialEq equality (ID: AGT-CRYPTO-dd984bc2) (TS: 2026-09-03T19:31:53Z) (SESSION: a413a598) |
| `2026-09-02T23:25:00Z` | `crates/contextra-mcp/tests/mcp_test.rs` | `REVIEW-PASS` | `TEST:MCP-002` | `4e4bb530` | `PASS` | `1` | // REVIEW-PASS[2/2] STATUS:PASS (ID: TEST:MCP-002) (TS:2026-09-02T23:25:00Z) (SESSION: 4e4bb530) PRÜFER-KONTEXT: FRESH — Independent review pass confirming complete JSON-RPC 2.0 error path coverage across test_malformed_request_returns_error, test_unknown_tool_returns_error, test_search_missing_collection_returns_error, test_insert_empty_text_returns_error, test_jsonrpc_null_id_preserved_in_error_response, test_tools_call_without_name_field_returns_error, test_insert_missing_collection_field_returns_error, and unit tests in tests.rs. |
| `2026-09-02T23:18:12Z` | `crates/contextra-checkpoint/tests/cache_concurrency_pinning.rs` | `ANCHOR` | `TEST:CKPT-001` | `358e3b0a` | `DONE` | `2` | // ANCHOR[TEST:CKPT-001] STATUS:DONE (TS:2026-09-02T23:18:12Z) (SESSION: 358e3b0a) |
| `2026-09-02T23:18:12Z` | `crates/contextra-checkpoint/tests/cache_concurrency_pinning.rs` | `REVIEW-PASS` | `TEST:CKPT-001` | `2155aaa2` | `PASS` | `1` | // REVIEW-PASS[2/2] STATUS:PASS (ID: TEST:CKPT-001) (TS:2026-09-02T23:18:12Z) (SESSION: 2155aaa2) PRÜFER-KONTEXT: FRESH - Confirmed concurrent stress test, cache hit/miss reloading, and unpinning lifecycle. |
| `2026-09-02T23:17:17Z` | `crates/contextra-text/src/morphology/tests.rs` | `REVIEW-PASS` | `TEST:TXT-001` | `adced73f` | `PASS` | `8` | // REVIEW-PASS[2/2] STATUS:PASS (ID: TEST:TXT-001) (TS: 2026-09-02T23:17:17Z) (SESSION: adced73f) |
| `2026-09-02T08:30:00Z` | `crates/contextra-text/src/morphology/tests.rs` | `REVIEW-PASS` | `TEST:TXT-001` | `98e60e97` | `PASS` | `8` | // REVIEW-PASS[2/2] STATUS:PASS (ID: TEST:TXT-001) (TS: 2026-09-02T08:30:00Z) (SESSION: 98e60e97) |
| `2026-09-02T08:19:33Z` | `crates/contextra-mcp/tests/mcp_test.rs` | `REVIEW-PASS` | `TEST:MCP-002` | `e2c39779` | `PASS` | `1` | // REVIEW-PASS[1/2] STATUS:PASS (ID: TEST:MCP-002) (TS:2026-09-02T08:19:33Z) (SESSION: e2c39779) PRÜFER-KONTEXT: FRESH — Error-Path Coverage verified in test_malformed_request_returns_error and unit tests. |
| `2026-09-02T08:18:07Z` | `crates/contextra-text/src/morphology/tests.rs` | `REVIEW-PASS` | `TEST:TXT-001` | `b952fab8` | `PASS` | `8` | // REVIEW-PASS[2/2] STATUS:PASS (ID: TEST:TXT-001) (TS: 2026-09-02T08:18:07Z) (SESSION: b952fab8) |
| `2026-09-02T08:17:15Z` | `crates/contextra-infer-onnx/src/lib.rs` | `REVIEW-PASS` | `-` | `f260cbf2` | `PASS` | `-` | // REVIEW-PASS[1/2] STATUS:PASS (TS: 2026-09-02T08:17:15Z) (SESSION: f260cbf2) PRÜFER-KONTEXT: FRESH - Verified feature gate isolation, zero unsafe in production, and execution non-starvation model. |
| `2026-09-02T08:16:22Z` | `crates/contextra-crypto/src/crypto.rs` | `REVIEW-PASS` | `TEST:CRY-001` | `881ec05e` | `PASS` | `6` | // REVIEW-PASS[5/3] STATUS:PASS (ID: TEST:CRY-001) (TS: 2026-09-02T08:16:22Z) (SESSION: 881ec05e) |
| `2026-09-01T23:15:00Z` | `crates/contextra-crypto/src/crypto.rs` | `REVIEW-PASS` | `TEST:CRY-001` | `88a840fb` | `PASS` | `6` | // REVIEW-PASS[4/3] STATUS:PASS (ID: TEST:CRY-001) (TS: 2026-09-01T23:15:00Z) (SESSION: 88a840fb) |
| `2026-09-01T23:15:00Z` | `crates/contextra-text/src/morphology/tests.rs` | `REVIEW-PASS` | `TEST:TXT-001` | `de8fd9f5` | `PASS` | `8` | // REVIEW-PASS[1/2] STATUS:PASS (ID: TEST:TXT-001) (TS: 2026-09-01T23:15:00Z) (SESSION: de8fd9f5) |
| `2026-09-01T23:09:00Z` | `crates/contextra-checkpoint/tests/cache_concurrency_pinning.rs` | `REVIEW-PASS` | `TEST:CKPT-001` | `fdf7a62e` | `PASS` | `1` | // REVIEW-PASS[1/2] STATUS:PASS (ID: TEST:CKPT-001) (TS:2026-09-01T23:09:00Z) (SESSION: fdf7a62e) PRÜFER-KONTEXT: FRESH - Test covers concurrent pinning, GC safety, and cache behavior. |
| `2026-09-01T23:02:47Z` | `crates/contextra-agent/src/lib.rs` | `REVIEW-PASS` | `AGT-AGENT-266186df` | `49022c36` | `PASS` | `1` | // REVIEW-PASS[1/2] STATUS:PASS (ID: AGT-AGENT-266186df) (TS: 2026-09-01T23:02:47Z) (SESSION: 49022c36) |
| `2026-08-31T21:20:00Z` | `crates/contextra-types/src/types/domain/tests/misc_tests.rs` | `REVIEW-PASS` | `TEST:CORE-001` | `c9f5e2b3` | `PASS` | `1` | // REVIEW-PASS[2/2] STATUS:PASS (ID: TEST:CORE-001) (TS: 2026-08-31T21:20:00Z) (SESSION: c9f5e2b3) |
| `2026-08-31T21:15:00Z` | `crates/contextra-types/src/types/domain/tests/misc_tests.rs` | `REVIEW-PASS` | `TEST:CORE-001` | `b8e4f1a2` | `PASS` | `1` | // REVIEW-PASS[1/2] STATUS:PASS (ID: TEST:CORE-001) (TS: 2026-08-31T21:15:00Z) (SESSION: b8e4f1a2) |
| `2026-08-31T21:13:44Z` | `crates/contextra-types/src/types/domain/tests/misc_tests.rs` | `ANCHOR` | `TEST:CORE-001` | `e459bd5f` | `DONE` | `2` | // ANCHOR[TEST:CORE-001] STATUS:DONE (TS:2026-08-31T21:13:44Z) (SESSION: e459bd5f) |
| `2026-08-31T21:13:05Z` | `crates/contextra-crypto/src/crypto.rs` | `ANCHOR` | `TEST:CRY-001` | `8427f167` | `DONE` | `6` | // ANCHOR[TEST:CRY-001] STATUS:DONE (TS:2026-08-31T21:13:05Z) (SESSION:8427f167) — Nonce-Uniqueness verification bei paralleler Verschlüsselung |
| `2026-08-31T21:13:05Z` | `crates/contextra-crypto/src/crypto.rs` | `REVIEW-PASS` | `TEST:CRY-001` | `8427f167` | `PASS` | `6` | // REVIEW-PASS[3/3] STATUS:PASS (ID: TEST:CRY-001) (TS: 2026-08-31T21:13:05Z) (SESSION: 8427f167) |
| `2026-08-31T21:12:53Z` | `crates/contextra-mcp/tests/mcp_test.rs` | `ANCHOR` | `TEST:MCP-002` | `2c814094` | `DONE` | `2` | // ANCHOR[TEST:MCP-002] STATUS:DONE (ID: TEST:MCP-002) (TS:2026-08-31T21:12:53Z) (SESSION: 2c814094) — Error-Path Coverage |
| `2026-08-31` | `crates/contextra-infer-onnx/tests/reranker_adversarial_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Quantitativer Test- & Benchmark-Suite für Cross-Encoder Reranker Adversarial Attacks. |
| `2026-08-30T22:01:55Z` | `crates/contextra-text/src/morphology/tests.rs` | `ANCHOR` | `TEST:TXT-001` | `cf1f75c6` | `DONE` | `9` | // ANCHOR[TEST:TXT-001] STATUS:DONE — Recall-Evaluation für deutsche Zusammensetzungen (TS:2026-08-30T22:01:55Z) (SESSION:cf1f75c6) |
| `2026-08-30T21:51:46Z (SESSION: a43b7682)` | `crates/contextra-types/src/error.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Kanonische unified ContextraError Enum für den gesamten Workspace. |
| `2026-08-30T21:51:46Z (SESSION: a43b7682)` | `crates/contextra-types/src/error_dto.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Serialisierbares Error-DTO für IPC/FFI-Schichten ohne Typverlust (ADR-028). |
| `2026-08-30T21:49:55Z (SESSION: 283abf0f)` | `crates/contextra-store/src/compaction/config.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | STCS-Compaction-Engine (Size-Tiered Compaction Strategy) |
| `2026-08-30T21:49:55Z (SESSION: 283abf0f)` | `crates/contextra-store/src/lsm/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | LSM-Tree-Implementierung (MemTable + SSTable + Compaction) |
| `2026-08-30T19:30:00Z (SESSION: b1234567)` | `crates/contextra-graph/src/community.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Community-Erkennung via Leiden-Algorithmus für GraphRAG |
| `2026-08-30T19:05:00Z` | `crates/contextra-crypto/src/crypto.rs` | `REVIEW-PASS` | `TEST:CRY-001` | `c9f5e2b3` | `PASS` | `6` | // REVIEW-PASS[2/3] STATUS:PASS (ID: TEST:CRY-001) (TS: 2026-08-30T19:05:00Z) (SESSION: c9f5e2b3) |
| `2026-08-30T19:05:00Z` | `crates/contextra-infer-ollama/src/client/tests.rs` | `REVIEW-PASS` | `TEST:OLL-001` | `c9f5e2b3` | `PASS` | `1` | // REVIEW-PASS[2/2] STATUS:PASS (ID: TEST:OLL-001) (TS: 2026-08-30T19:05:00Z) (SESSION: c9f5e2b3) |
| `2026-08-30T19:00:00Z` | `crates/contextra-crypto/src/crypto.rs` | `REVIEW-PASS` | `TEST:CRY-001` | `b8e4f1a2` | `PASS` | `6` | // REVIEW-PASS[1/3] STATUS:PASS (ID: TEST:CRY-001) (TS: 2026-08-30T19:00:00Z) (SESSION: b8e4f1a2) |
| `2026-08-30T19:00:00Z` | `crates/contextra-infer-ollama/src/client/tests.rs` | `REVIEW-PASS` | `TEST:OLL-001` | `b8e4f1a2` | `PASS` | `1` | // REVIEW-PASS[1/2] STATUS:PASS (ID: TEST:OLL-001) (TS: 2026-08-30T19:00:00Z) (SESSION: b8e4f1a2) |
| `2026-08-30T19:00:00Z` | `crates/contextra-infer-ollama/src/query_rewriter.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | LLM-gestütztes Multi-Signal Query-Rewriting für Ollama (Text, Semantik, Graph-Anker) |
| `2026-08-30T18:54:39Z (SESSION: ed7b7b38)` | `crates/contextra-infer-ollama/src/client.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | HTTP-Client für lokale Ollama LLM/Embedding API mit Retry/Timeout/Streaming-Semantik |
| `2026-08-30T18:54:39Z (SESSION: ed7b7b38)` | `crates/contextra-infer-ollama/src/context_prefixer.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Contextra Contextual Chunk Prefixing — LLM-basierte Präfix-Generierung für Chunks |
| `2026-08-30T18:54:39Z (SESSION: ed7b7b38)` | `crates/contextra-infer-ollama/src/embedding.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | `TextEmbeddingEngine`-Implementierung für Ollama Embedding API |
| `2026-08-30T18:54:39Z (SESSION: ed7b7b38)` | `crates/contextra-infer-ollama/src/importance.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | LLM-basierte Wichtigkeits-Bewertung (ImportanceScore 0.0-1.0) für Memory Chunks |
| `2026-08-30T18:54:39Z (SESSION: ed7b7b38)` | `crates/contextra-infer-ollama/src/model_info.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Modell-Inspektion (/api/show) und Statisches Mapping bekannter Embedding-Dimensionen |
| `2026-08-30T18:54:39Z` | `crates/contextra-infer-ollama/src/client/tests.rs` | `ANCHOR` | `TEST:OLL-001` | `ed7b7b38` | `DONE` | `2` | // ANCHOR[TEST:OLL-001] STATUS:DONE (TS:2026-08-30T18:54:39Z) (SESSION:ed7b7b38) |
| `2026-08-30T18:53:58Z (SESSION: b1234567)` | `crates/contextra-graph/src/ppr.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Personalized PageRank Power Iteration über CSR Graph |
| `2026-08-30T18:53:58Z (SESSION: b1234567)` | `crates/contextra-graph/src/session_dag.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Session-DAG für persistente, azyklische Agent-State-Verzweigung (Contextra Session-DAG Pattern) |
| `2026-08-30T18:51:56Z (SESSION: e459bd5f)` | `crates/contextra-mvcc/src/seq_log.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Shared Versioned Sequence Log für Snapshot-isolierte Index-Suchen (_at Familie). |
| `2026-08-30T18:51:56Z (SESSION: e459bd5f)` | `crates/contextra-mvcc/src/snapshot.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | SnapshotRegistry für MVCC-sichere Reads und minimal aktive Sequenznummern. |
| `2026-08-30T18:51:56Z (SESSION: e459bd5f)` | `crates/contextra-types/src/types/budget.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Token- und Resource-Budget-Management mit atomarem Tracking & Memory Backpressure. |
| `2026-08-30T18:51:56Z (SESSION: e459bd5f)` | `crates/contextra-types/src/types/filter.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Kanonische Metadata Filter DSL (FilterExpr) und Evaluierungs-Engine. |
| `2026-08-30T18:51:56Z (SESSION: e459bd5f)` | `crates/contextra-types/src/types/importance.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Memory Importance Scoring und Recency-Decay Berechnungen (ADR-025). |
| `2026-08-30T18:51:56Z (SESSION: e459bd5f)` | `crates/contextra-types/src/types/saos.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Multi-Signal HybridQuery, FusionWeights, ContextWindow und ContextChunk Repräsentation. |
| `2026-08-30T15:00:19Z (SESSION: 283abf0f)` | `crates/contextra-store/src/memtable.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | In-Memory BTreeMap MemTable-Sharding mit MVCC Snapshot-Isolation. |
| `2026-08-30T15:00:19Z` | `crates/contextra-agent/src/context.rs` | `AI-TAG` | `-` | `283abf0f` | `RESOLVED` | `-` | // AI-TAG[HARDENING][CRITICAL] RESOLVED: Validates non-empty input parameters for agent workflow context initialization. (TS:2026-08-30T15:00:19Z) (SESSION: 283abf0f) |
| `2026-08-30T15:00:19Z` | `crates/contextra-agent/src/event_source.rs` | `AI-TAG` | `-` | `283abf0f` | `RESOLVED` | `-` | // AI-TAG[HARDENING][CRITICAL] RESOLVED: Validates non-empty event source to prevent silent telemetry attribution loss. (TS:2026-08-30T15:00:19Z) (SESSION: 283abf0f) |
| `2026-08-30T15:00:19Z` | `crates/contextra-agent/src/event_source.rs` | `AI-TAG` | `-` | `283abf0f` | `RESOLVED` | `-` | // AI-TAG[HARDENING][CRITICAL] RESOLVED: Enforces bounded event queue capacity to guard against unbounded memory growth. (TS:2026-08-30T15:00:19Z) (SESSION: 283abf0f) |
| `2026-08-30T15:00:19Z` | `crates/contextra-agent/src/graph.rs` | `AI-TAG` | `-` | `283abf0f` | `RESOLVED` | `-` | // AI-TAG[HARDENING][CRITICAL] RESOLVED: Validates non-empty Node ID and description for graph nodes. (TS:2026-08-30T15:00:19Z) (SESSION: 283abf0f) |
| `2026-08-30T15:00:19Z` | `crates/contextra-agent/src/graph.rs` | `AI-TAG` | `-` | `283abf0f` | `RESOLVED` | `-` | // AI-TAG[HARDENING][CRITICAL] RESOLVED: Validates non-empty from/to endpoints for workflow edges. (TS:2026-08-30T15:00:19Z) (SESSION: 283abf0f) |
| `2026-08-29T18:30:00Z` | `crates/contextra-db/tests/fusion_edge_cases_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Standalone Randfall- & Mutation-Testsuite für Reciprocal Rank Fusion (fusion.rs). |
| `2026-08-29T12:00:00Z` | `crates/contextra-mvcc/src/tx_buffer.rs` | `AI-TAG` | `AGT-CORE-001` | `a3f29c1d` | `RESOLVED` | `0` | // AI-TAG[SMELL][MINOR] RESOLVED: AGT-CORE-001 — Bounded staging capacity enforced (TS:2026-08-29T12:00:00Z) (SESSION: a3f29c1d) |
| `2026-08-29T11:00:00Z` | `crates/contextra-db/tests/semantic_recall.rs` | `REVIEW-PASS` | `PERF:EVAL-001` | `c9f5e2b3` | `PASS` | `1` | // REVIEW-PASS[2/2] STATUS:PASS (ID: PERF:EVAL-001) (TS: 2026-08-29T11:00:00Z) (SESSION: c9f5e2b3) |
| `2026-08-29T10:00:00Z` | `crates/contextra-db/tests/semantic_recall.rs` | `REVIEW-PASS` | `PERF:EVAL-001` | `b8e4f1a2` | `PASS` | `1` | // REVIEW-PASS[1/2] STATUS:PASS (ID: PERF:EVAL-001) (TS: 2026-08-29T10:00:00Z) (SESSION: b8e4f1a2) |
| `2026-08-29T08:06:29Z` | `crates/contextra-checkpoint/src/manifest.rs` | `AI-TAG` | `AGT-CKPT-f3a1b2c4` | `14348074` | `RESOLVED` | `0` | /// AI-TAG\[PANIC-SAFETY\]\[CRITICAL\] RESOLVED: AGT-CKPT-f3a1b2c4 (TS:2026-08-29T08:06:29Z) (SESSION:14348074) |
| `2026-08-29T00:00:00Z` | `crates/contextra-db/tests/semantic_recall.rs` | `ANCHOR` | `PERF:EVAL-001` | `a3f29c1d` | `DONE` | `2` | // ANCHOR[PERF:EVAL-001] STATUS:DONE (TS:2026-08-29T00:00:00Z) (SESSION: a3f29c1d) — Semantic Retrieval Evaluation Framework |
| `2026-08-28T00:00:00Z` | `crates/contextra-cognition/src/context_compaction/compactor.rs` | `AI-TAG` | `AGT-DB-004` | `-` | `RESOLVED` | `0` | // AI-TAG[SMELL][MINOR][RESOLVED] Async LLM-Summarization for context compaction (ID: AGT-DB-004) (TS:2026-08-28T00:00:00Z) |
| `2026-08-28T00:00:00Z` | `crates/contextra-engine/src/collection/relate.rs` | `AI-TAG` | `AGT-DB-005` | `-` | `RESOLVED` | `0` | // AI-TAG[CONCURRENCY][CRITICAL] RESOLVED: AGT-DB-005 — relate() rollback race behoben, siehe ADR-023 (TS:2026-08-28T00:00:00Z) |
| `2026-08-27T00:00:00Z` | `crates/contextra-agent/src/lib.rs` | `AI-TAG` | `AGT-AGENT-001` | `-` | `RESOLVED` | `0` | // AI-TAG[DOC-DRIFT][MINOR] RESOLVED: AGT-AGENT-001 — Re-extracted workflow engine crate requires integration verification. (TS:2026-08-27T00:00:00Z) |
| `2026-08-25T00:00:00Z` | `crates/contextra-engine/src/collection/crud/read.rs` | `AI-TAG` | `AGT-DB-001` | `-` | `RESOLVED` | `0` | // AI-TAG[CONVENTION-DRIFT][MAJOR] RESOLVED: AGT-DB-001 — snapshot_seq() now propagates storage errors (TS:2026-08-25T00:00:00Z) |
| `2026-08-25T00:00:00Z` | `crates/contextra-engine/src/collection/mod.rs` | `AI-TAG` | `AGT-DB-002` | `-` | `RESOLVED` | `0` | // AI-TAG[CONVENTION-DRIFT][MAJOR] RESOLVED: AGT-DB-002 — load_index now scans user_keys (key_type=0) (TS:2026-08-25T00:00:00Z) |
| `2026-08-25T00:00:00Z` | `crates/contextra-text/src/inverted/index_struct.rs` | `AI-TAG` | `AGT-TXT-001` | `-` | `RESOLVED` | `0` | // AI-TAG[SPEC-DRIFT][MAJOR] RESOLVED: AGT-TXT-001 — replaced unwrap_or_default() with map_err (TS:2026-08-25T00:00:00Z) |
| `2026-08-24T00:00:00Z` | `crates/contextra-store/src/lib.rs` | `ANCHOR` | `INTEGRATION:STO-001` | `-` | `RESOLVED` | `0` | // ANCHOR[INTEGRATION:STO-001] STATUS:RESOLVED (TS:2026-08-24T00:00:00Z) |
| `2026-06-20T00:00:00Z` | `crates/contextra-db/tests/checkpoint_stress.rs` | `ANCHOR` | `INTEGRATION:CHECKPOINT-STRESS` | `-` | `DONE` | `0` | // ANCHOR[INTEGRATION:CHECKPOINT-STRESS] STATUS:DONE (TS:2026-06-20T00:00:00Z) |
| `2026-06-01T00:00:00Z` | `crates/contextra-cognition/src/context.rs` | `ANCHOR` | `INTEGRATION:WP-7.1-CHUNKER` | `-` | `DONE` | `0` | // ANCHOR[INTEGRATION:WP-7.1-CHUNKER] STATUS:DONE (TS:2026-06-01T00:00:00Z) — Wire MarkdownChunker to ContextManager |
| `2026-06-01T00:00:00Z` | `crates/contextra-vector/src/lib.rs` | `ANCHOR` | `REFACTOR:WP-0.0-STABLESIMD` | `-` | `DONE` | `0` | // ANCHOR[REFACTOR:WP-0.0-STABLESIMD] STATUS:DONE (TS:2026-06-01T00:00:00Z) — Remove nightly portable_simd |
| `2026-05-18T00:00:00Z` | `crates/contextra-db/tests/concurrent_collection_stress.rs` | `ANCHOR` | `INTEGRATION:STRESS-001` | `-` | `DONE` | `0` | // ANCHOR[INTEGRATION:STRESS-001] STATUS:DONE (TS:2026-05-18T00:00:00Z) |
| `2026-05-18T00:00:00Z` | `crates/contextra-db/tests/full_stack_e2e.rs` | `ANCHOR` | `INTEGRATION:E2E-001` | `-` | `DONE` | `0` | // ANCHOR[INTEGRATION:E2E-001] STATUS:DONE (TS:2026-05-18T00:00:00Z) |
| `` | `crates/contextra-agent/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Crate entry point exposing audit, context, engine, event_source, graph, and step submodules. |
| `` | `crates/contextra-agent/tests/clm_goal_condition_edges.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Tests für alle GoalCondition-Varianten, Randfälle und Determinismus. |
| `` | `crates/contextra-agent/tests/clm_scratchpad_reset_flow.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Tests für CLM Scratchpad Reset-Flow, RAM-Zeroization, Audit-/Invalidierungscounter und PinnedRegion. |
| `` | `crates/contextra-agent/tests/workflow_edge_serde_compat.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Serde-Kompatibilitätstests für WorkflowEdge (Lesen alter JSONs ohne goal, Roundtrip neuer JSONs mit goal). |
| `` | `crates/contextra-cognition/src/leanrag_input.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Extraktion von LeanRAG-Eingabedaten (AggregationNode/AggregationEdge) aus einer Collection (Spec §21.4). |
| `` | `crates/contextra-cognition/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Contextra Cognition Engine (Layer 3 - Cognition). |
| `` | `crates/contextra-cognition/src/maintenance_scheduler.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Zentraler MaintenanceScheduler für koordiniertes, sequenzielles Ausführen aller Background-Maintenance-Prozesse (ADR-079). |
| `` | `crates/contextra-cognition/src/memory_consolidation.rs` | `AI-TAG` | `AGT-DB-660fbb5f` | `-` | `RESOLVED` | `0` | /// AI-TAG[SLEEP][MINOR] RESOLVED: AGT-DB-660fbb5f — Position im turns-Slice wird anstelle des |
| `` | `crates/contextra-cognition/src/semantic_aggregation_facade.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Öffentliche Facade-Schnittstelle für LeanRAG Stage-3-Hyperkantenaggregatierung (Spec §5.3, §12.4). |
| `` | `crates/contextra-crypto/src/audit_chain.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Cryptographic Blake3 audit hash chain with periodic Ed25519 signatures and encrypted commitments. |
| `` | `crates/contextra-crypto/src/deletion_proof.rs` | `AI-TAG` | `-` | `-` | `RESOLVED` | `-` | // AI-TAG[SMELL][RESOLVED] audit-R3-1: DeletionProof signature_version 2 erweitert Signatur-Payload um covered_layers & excluded_scopes zur Vermeidung von Cross-Context-Fälschungen. |
| `` | `crates/contextra-crypto/src/ed25519_proof.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Standalone Ed25519 asymmetric signature creation and external verification for deletion proofs (version 3). |
| `` | `crates/contextra-crypto/src/kdf.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Versionierter Key Derivation Function (KDF) Header und Argon2id Schlüsselableitung für Passphrasen. |
| `` | `crates/contextra-crypto/src/kv_shredding.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Envelope Encryption und Key-Registry für KV-Crypto-Shredding (AP-P0-06, Spec v17 §16.1). |
| `` | `crates/contextra-crypto/src/revocation_log.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Persistierter, Ed25519-signierter, manipulationssicherer Append-Only Widerrufslog (v17 Teil 16.1). |
| `` | `crates/contextra-crypto/src/wal_completeness.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Verification of WAL log tail completeness against checkpoint manifest high-water-mark to detect truncation attacks. |
| `` | `crates/contextra-crypto/tests/audit_chain_tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Tests for Blake3 Audit Hash Chain, Ed25519 head signature verification, crypto-shredded record commitments, and DeletionProof linkage. |
| `` | `crates/contextra-crypto/tests/campaign_cov_deletion_proof.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Campaign coverage test for DeletionProof verify_external and export_for_audit. |
| `` | `crates/contextra-crypto/tests/campaign_cov_revocation_log.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Campaign coverage test for RevocationLog verify_integrity and chain verification. |
| `` | `crates/contextra-crypto/tests/campaign_j26_hypotheses.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Campaign J-26 hypothesis test suite for crypto compliance, revocation logs, audit chains, commitments, and deletion proofs. |
| `` | `crates/contextra-crypto/tests/campaign_mut_j17.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Targeted killer test suite for contextra-crypto mutants (shard 1/4 campaign J-17). |
| `` | `crates/contextra-crypto/tests/crypto_crossimpl_python.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Cross-Implementation Validierung zwischen Contextra Rust Primitive-Funktionen und Python (cryptography, argon2-cffi, blake3). |
| `` | `crates/contextra-crypto/tests/crypto_vectors_extended.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Kryptografische Validierung gegen offizielle RFC-/NIST-Vektoren und herstellerunabhängige Standardwerte. |
| `` | `crates/contextra-crypto/tests/ed25519_proof_external_verify.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integration tests for external verification of Ed25519 deletion proofs (version 3). |
| `` | `crates/contextra-crypto/tests/guarantee_audit_chain_tamper.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Independent guarantee test suite for AuditChain anti-tampering, head signature verification, and encrypted commitments. |
| `` | `crates/contextra-crypto/tests/guarantee_deletion_irrecoverable.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Unabhängiger Funktionsnachweis für Garantie 2b: Löschung ist nicht rückholbar und der Nachweis ist extern prüfbar. |
| `` | `crates/contextra-crypto/tests/kdf_argon2id.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Tests für Argon2id KDF Header, Parameter-Validierung, Parser-Robustheit und KeyManager Integration. |
| `` | `crates/contextra-crypto/tests/wal_completeness_tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Unit & proptest verification for WAL chain completeness checks. |
| `` | `crates/contextra-crypto/tests/wal_integrity_audit.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrationstests und Audit-Regressionstests für WAL-Integrität, Sequence-Number-Zustandsmaschine, Nonce-Politik und V2/V3-Protokolle. |
| `` | `crates/contextra-db/src/homeostat.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Homeostat Wrapper in contextra-db für Rerank PID Candidate Pool Regulation und Deadline Management. |
| `` | `crates/contextra-db/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Contextra Database Strangler Shell / Re-export Facade (Layer 3). |
| `` | `crates/contextra-db/tests/cross_domain_chaos_matrix_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` |  |
| `` | `crates/contextra-db/tests/diskann_collection_fallback.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Collection Integration Fallback Test (Pflichttest 3). |
| `` | `crates/contextra-db/tests/embedding_dimension_switch.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` |  |
| `` | `crates/contextra-db/tests/hnsw_delete_and_backfill.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Verifiziert, dass ein Fehler beim HNSW-Delete nicht verschluckt wird und Vektorsuchen bei Tombstones durch Backfill k valide Ergebnisse liefern. |
| `` | `crates/contextra-db/tests/multistep_query_rewriter_modalities.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Testet Multi-Modal Sub-Queries (Text, Vektor, Graph) im Multi-Step Retrieval mit Mock-Rewriter und Mock-Embedder. |
| `` | `crates/contextra-db/tests/pid_pool_production_caller.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Prüft die PID-regulatorische Einbindung in den Multi-Step Candidate Pool und Grenzwerte [50, 200]. |
| `` | `crates/contextra-engine/src/background_workers/config.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Konfiguration und Trait für Orphan-Cleanup-Backoff und HNSW-Index-Rebuild. |
| `` | `crates/contextra-engine/src/background_workers/expiry_workers.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Worker-Tasks zur TTL-Löschung abgelaufener Dokumente und Entropie-Pruning/Decay-Eviction. |
| `` | `crates/contextra-engine/src/background_workers/hyperedge_worker.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Worker-Task und FIFO-Queue zur verzögerten Kaskaden-Tombstoning-Verarbeitung von Hyperedges. |
| `` | `crates/contextra-engine/src/background_workers/orphan_workers.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Worker-Tasks zur Bereinigung verwaister Transaktionen (Orphan Cleanup) und HNSW-Index-Rebuilds. |
| `` | `crates/contextra-engine/src/background_workers/tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Unit-Tests für background_workers Submodule. |
| `` | `crates/contextra-engine/src/collection/crud/auto_extraction.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Ingestion-Hook fuer LLM- und regelbasierte Entitaetsextraktion (OpenIE / Rule-Based). |
| `` | `crates/contextra-engine/src/collection/query_builder/scope.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Scoping-Typen und Query-Builder Ergänzung für ACORN-Hard-Boundary (Spec §5.3, §8.5, §10.4). |
| `` | `crates/contextra-engine/src/collection/search/basic.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Einfache Suchvarianten (search, search_with_filter, search_with_filter_expr, search_text) für Collection. |
| `` | `crates/contextra-engine/src/collection/search/checkpoint.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | RAII CheckpointPinGuard und higher-order helper functions für Snapshot-Pinning während Suchoperationen. |
| `` | `crates/contextra-engine/src/collection/search/filtered.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Filter-Familie (Selectivity, Match-DocIDs, search_filtered) für Collection. |
| `` | `crates/contextra-engine/src/collection/search/filtered.rs` | `AI-TAG` | `-` | `-` | `RESOLVED` | `-` | // AI-TAG[SMELL][RESOLVED] audit-5.1: Vector-Suche clampt k stets auf k.min(contextra_types::MAX_SEARCH_K) über alle Einstiegspunkte hinweg. |
| `` | `crates/contextra-engine/src/collection/search/filtered.rs` | `AI-TAG` | `-` | `-` | `RESOLVED` | `-` | // AI-TAG[SMELL][RESOLVED] audit-M-7: CheckpointPinGuard handles unpinning safely across all error return paths. |
| `` | `crates/contextra-engine/src/collection/search/hybrid/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Hybrid-Familie (hybrid_search, hybrid_search_reranked, hybrid_search_with_weights, hybrid_search_with_strategy, traverse_links, filter_by_importance) für Collection. |
| `` | `crates/contextra-engine/src/collection/search/hybrid/mod.rs` | `AI-TAG` | `AGT-DB-6d724b1a` | `-` | `RESOLVED` | `0` | // AI-TAG[RESOLVED][MINOR] graph_search snapshot isolation via multi_traverse_at for Hops; PARTIAL with warning for PPR/PathRag. (ID: AGT-DB-6d724b1a) |
| `` | `crates/contextra-engine/src/collection/search/hybrid/query.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Hybrid-Familie Submodule für Query-basierte Suche. |
| `` | `crates/contextra-engine/src/collection/search/hydrate.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Hydrierungs-Familie (hydrate_from_scored_at, hydrate_from_tuples_at) für Collection. |
| `` | `crates/contextra-engine/src/decay_controller.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Re-Export des Adaptive Decay Controllers aus contextra-adapt (Ring 0/Adapt). |
| `` | `crates/contextra-engine/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Contextra Core Engine Orchestrator & Facade (Layer 3 - Engine). |
| `` | `crates/contextra-engine/src/merge_operator_adapter.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Synchronous bridge from contextra-store MergeOperator to async WasmMergeFunction |
| `` | `crates/contextra-engine/tests/auto_extraction_default_enabled.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Testet den kompilierte Default-Wert fuer AutoExtractionConfig (enabled: true vs. opt-out). |
| `` | `crates/contextra-engine/tests/auto_extraction_runtime_mode.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrationstests fuer AutoExtractionMode Laufzeit-Verhalten und Profil-Wechsel. |
| `` | `crates/contextra-engine/tests/auto_extraction_wiring.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrationstests fuer die Verdrahtung von AutoExtraction in Collection::insert_text_only. |
| `` | `crates/contextra-engine/tests/commit_crash_consistency.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Targeted crash simulation tests for multi-index 2-Phase Commit consistency. |
| `` | `crates/contextra-engine/tests/engine_recovery_crash_windows.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrationstests für Crash-Fenster-Recovery und commit-uncertain Transaktionen (F-20 / T-06). |
| `` | `crates/contextra-engine/tests/openie_determinism_and_provenance.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Determinismus- & Provenienztests fuer OpenIE Tripel-Extraktion und edge.source_doc_id-Kaskade. |
| `` | `crates/contextra-engine/tests/rule_based_extraction_determinism.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Determinismus- & Provenienztests fuer RuleBasedExtractor (v17 §6.3, §10.5, P28). |
| `` | `crates/contextra-graph/src/entity_extraction.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Regelbasierte Entitäts- und Relations-Extraktion aus Freitext mit Graph-Ingestion-Anbindung. |
| `` | `crates/contextra-graph/tests/entity_extraction_tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrations- und Evaluationstests für die regelbasierte Entitäts- und Relations-Extraktion in contextra-graph. |
| `` | `crates/contextra-kvcache/tests/clm_pinned_base_preserved.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrationstest für INV-CLM-SCRATCHPAD-1 (Gepinnter Basiskontext bleibt bei Scratchpad-Reset unberührt). |
| `` | `crates/contextra-kvcache/tests/scratchpad_invalidation_isolation.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrationstest für Mandantenisolation bei der Invalidation von Scratchpad-Cache-Scopes. |
| `` | `crates/contextra-mcp/src/bulk_exfiltration_detector.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Layer-4 Bulk-Exfiltration-Detektor (Re-export from contextra-privacy) |
| `` | `crates/contextra-mcp/src/egress_gateway.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Egress Security Gateway & Classifier Enforcement for Cloud MCP Queries (Re-export from contextra-privacy) |
| `` | `crates/contextra-mcp/src/egress_guard.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Layer-4 EgressGuard (Re-export from contextra-privacy) |
| `` | `crates/contextra-mcp/src/server_dispatch.rs` | `AI-TAG` | `-` | `-` | `RESOLVED` | `-` | // AI-TAG[SMELL][RESOLVED] audit-APM-38-mcp: Replay-Schutz für stdio-JSON-RPC |
| `` | `crates/contextra-mvcc/tests/campaign_cov_ssi_coarsening.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Campaign coverage test for SequenceLogSsiValidator coarsening and pruning blocker diagnostics. |
| `` | `crates/contextra-mvcc/tests/campaign_cov_tx_buffer_reap.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Campaign coverage test for TxBuffer reap_orphans_bounded and deterministic time injection. |
| `` | `crates/contextra-ports/src/graph_index.rs` | `AI-TAG` | `-` | `-` | `RESOLVED` | `-` | // AI-TAG[ARCH][MINOR][RESOLVED] (virtuell verschoben von contextra-router/ports_local.rs per TODO(welle-3), siehe docs/refactor/router-db-edge-audit.md) |
| `` | `crates/contextra-ports/src/lifecycle.rs` | `AI-TAG` | `-` | `-` | `RESOLVED` | `-` | // AI-TAG[ARCH][MINOR][RESOLVED] (virtuell verschoben von contextra-router/ports_local.rs per TODO(welle-3), siehe docs/refactor/router-db-edge-audit.md) |
| `` | `crates/contextra-ports/src/vector_index.rs` | `AI-TAG` | `-` | `-` | `RESOLVED` | `-` | // AI-TAG[ARCH][MINOR][RESOLVED] (virtuell verschoben von contextra-router/ports_local.rs per TODO(welle-3), siehe docs/refactor/router-db-edge-audit.md) |
| `` | `crates/contextra-privacy/src/audit_trace.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Deterministische Audit-Trace-Generierung für Egress-Klassifikationsentscheidungen (INV-EGRESS-AUDIT-1 / P28). |
| `` | `crates/contextra-privacy/src/bulk_exfiltration_detector.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Layer-4 Bulk-Exfiltration-Detektor (Volumen/Zeitfenster pro Session) |
| `` | `crates/contextra-privacy/src/context_edit_audit.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Audit-Protokollierung von Änderungen am temporären Agenten-Kontext (CLM-Scratchpad). |
| `` | `crates/contextra-privacy/src/egress_gateway.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Egress Security Gateway & Classifier Enforcement for Cloud Queries |
| `` | `crates/contextra-privacy/src/egress_vault.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Cloud-Egress-Vault mit Layer-1-Regex-Klassifikation und Fail-Closed-Semantik. |
| `` | `crates/contextra-privacy/tests/campaign_cov_privacy_egress.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Campaign coverage test for CloudResponseRehydrator and BulkExfiltrationDetector fail-closed policy evaluation. |
| `` | `crates/contextra-privacy/tests/context_edit_audit_chain.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrationstest für ContextEditAuditRecord-Verkettung, Hash-Integrität, Clock-Port-Injektion und Manipulationserkennung. |
| `` | `crates/contextra-privacy/tests/pii_vault_forces_crypto_shred.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Test PII vault forces CryptoShred under DeploymentTier::EdgeMinimal (INV-COLLECTION-PROFILE-3) |
| `` | `crates/contextra-router/src/router/dispatch_core.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Kern-Routing-Dispatch und Kaskaden-/Bandit-Profilauswahl für RouterEngine. |
| `` | `crates/contextra-router/src/router/lifecycle.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Konstruktions- und Profilverwaltungs-Methoden (Hot-Reload) für RouterEngine. |
| `` | `crates/contextra-router/src/router/outcomes.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Outcome-Recording, Kalibrierungs- und Drift-Statistiken für RouterEngine. |
| `` | `crates/contextra-router/src/router/tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Unit-Tests für RouterEngine. |
| `` | `crates/contextra-simd/src/dispatch.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Runtime Hardware Feature Detection & Dispatcher. |
| `` | `crates/contextra-simd/src/kernels/avx2.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | AVX2 SIMD-Intrinsics für f32, f32_bytes und u8 Distanzberechnungen. |
| `` | `crates/contextra-simd/src/kernels/avx512.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | AVX-512 SIMD-Intrinsics für f32, f32_bytes und u8 VNNI Distanzberechnungen. |
| `` | `crates/contextra-simd/src/kernels/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Kernel-Modul-Deklarationen für SIMD-Distanzfunktionen. |
| `` | `crates/contextra-simd/src/kernels/neon.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | ARM NEON SIMD-Intrinsics für f32 Distanzberechnungen. |
| `` | `crates/contextra-simd/src/kernels/scalar.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Skalare Fallback-Implementierung der Distanzmetriken (f32, f32_bytes, u8, f32_u8). |
| `` | `crates/contextra-simd/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Layer-0 Ring-0 Unsafe-Insel für SIMD-Distanzkernel und Laufzeit-Dispatch. |
| `` | `crates/contextra-store/examples/chaos_writer.rs` | `FILE-CONTEXT` | `-` | `chaos_power_cut` | `-` | `-` |  |
| `` | `crates/contextra-store/src/compaction/engine.rs` | `AI-TAG` | `-` | `-` | `RESOLVED` | `-` | // AI-TAG[SMELL][RESOLVED] audit-H-3: LsmStorage hält eine persistente CompactionEngine-Instanz (LsmStorage.compaction_engine), wodurch Compaction-State & Zähler erhalten bleiben. |
| `` | `crates/contextra-store/src/kv/delete_mode.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Definition von KvDeleteMode (TombstoneOnly vs CryptoShred). |
| `` | `crates/contextra-store/src/kv/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Key-Value Segment-Verwaltung und Löschmodi (TombstoneOnly, CryptoShred). |
| `` | `crates/contextra-store/src/kv/segment.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Verdrahtung von KvDeleteMode und contextra_crypto::kv_shredding für KV-Segment-Verschlüsselung und Crypto-Shredding (AP-P0-06 / Spec B.1.8). |
| `` | `crates/contextra-store/src/util.rs` | `FILE-CONTEXT` | `-` | `8f882f1f` | `-` | `-` |  |
| `` | `crates/contextra-store/tests/campaign_stress_store.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` |  |
| `` | `crates/contextra-store/tests/chaos_dropped_write.rs` | `FILE-CONTEXT` | `-` | `283abf0f` | `-` | `-` |  |
| `` | `crates/contextra-store/tests/chaos_matrix.rs` | `FILE-CONTEXT` | `-` | `283abf0f` | `-` | `-` |  |
| `` | `crates/contextra-store/tests/chaos_power_cut.rs` | `FILE-CONTEXT` | `-` | `chaos_power_cut` | `-` | `-` |  |
| `` | `crates/contextra-store/tests/chaos_task_massacre.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` |  |
| `` | `crates/contextra-store/tests/commit_cancel_chain_consistency.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Testet die HMAC-Kettenkonsistenz und Recovery, wenn ein Commit-Future nach prepare_batch abgebrochen (gedroppt) wird. |
| `` | `crates/contextra-store/tests/commit_rollback_batch_scoped.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Testet Batch-scoped Rollback und Integrität von Immutable MemTables / alten WALs nach WAL-Append-Fehlern. |
| `` | `crates/contextra-store/tests/disk_full_during_write.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` |  |
| `` | `crates/contextra-store/tests/fsync_timeout_rollback.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` |  |
| `` | `crates/contextra-store/tests/group_commit_follower_timeout_chain.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Testet, dass ein Follower, der per Timeout aus der Group-Commit-Queue ausscheidet, keine HMAC-Kette korrumpiert. |
| `` | `crates/contextra-store/tests/group_commit_leader_cancel_chain.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Testet, dass der Abbruch (Cancellation) der Leader-Future das Queue-Integritäts-Verhalten nicht korrumpiert und wartende Follower geordnet fehlschlagen. |
| `` | `crates/contextra-store/tests/group_commit_overlapping_batch_rollback.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Testet, dass ein Fehlschlag eines nachfolgenden Batches B (Tx 3) nicht die bereits dauerhaften WAL-Einträge von Batch A (Tx 2) abschneidet. |
| `` | `crates/contextra-store/tests/kv_delete_mode_wiring_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Tests for KV Delete Mode & Crypto-Shredding wiring in contextra-store. |
| `` | `crates/contextra-store/tests/wal_hmac_chain_ordering.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Regressionstest — WAL HMAC-Kette enthält keine Gabelungen nach Group-Commit. |
| `` | `crates/contextra-store/tests/wal_hmac_rollback_race.rs` | `FILE-CONTEXT` | `-` | `b448084` | `-` | `-` |  |
| `` | `crates/contextra-store/tests/wal_truncate_ordering.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Audit-Test B-7 — Proof WAL-Truncate-Ordering & Size-Counter-Integrität. |
| `` | `crates/contextra-text/src/domain/legal_de.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Definiert Komposita-Staemme und geschuetzte Begriffe fuer domaenenspezifische Sprachanforderungen. |
| `` | `crates/contextra-text/src/domain/medical_de.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Definiert Komposita-Staemme und geschuetzte Begriffe fuer domaenenspezifische Sprachanforderungen. |
| `` | `crates/contextra-text/src/posting_list.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Stellt kompakte, resident gehaltene Postinglisten pro Term bereit. |
| `` | `crates/contextra-text/src/wand.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Multi-Term Query-Traversierung mit Block-Maximalwert-Pruning und dynamic thresholding. |
| `` | `crates/contextra-text/tests/bm25_edge_cases.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Testet score_term_with_params und score_term mit degenerierten/Grenzfall-Eingaben. |
| `` | `crates/contextra-text/tests/bm25_reference_values.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Verifiziert BM25 score_term_with_params und score_term_bm25f gegen unabhängig berechnete Referenzwerte der publizierten Formeln. |
| `` | `crates/contextra-text/tests/bm25f_field_weighting.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Prüft Formel-Korrektheit, Degeneration zu einfeldigem BM25 und Zero-Panic Invarianten. |
| `` | `crates/contextra-text/tests/domain_compound_integration.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Verifiziert, dass der GermanCompoundSplitter mit den ausgebauten Vokabularen mindestens 20 reprasentative Komposita je Domaene (Recht & Medizin) korrekt zerlegt und geschuetzte Begriffe unangetastet laesst. |
| `` | `crates/contextra-text/tests/domain_vocab_quality.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Verifiziert Invarianten (keine Duplikate, Kleinschreibung, Disjunktheit, Mindestgroessen, exakte Sortierung) und Zerlegungsverhalten. |
| `` | `crates/contextra-text/tests/wand_tie_break_threshold.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Verifiziert, dass WAND bei Score-Gleichstand an der k-ten Abbruchschwelle deterministisch nach aufsteigender DocId sortiert, exakt mit dem Brute-Force-Referenzergebnis uebereinstimmt und keine Dokumente durch accum_max_score > threshold faelschlich verwirft. |
| `` | `crates/contextra-vector/benches/acorn_vs_post_filter.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Criterion Benchmark für ACORN Naive-Reference Search vs. Post-Filtering Baseline. |
| `` | `crates/contextra-vector/benches/filtered_search_selectivity_bench.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Criterion-Benchmark zur Messung des Recall-Abfalls und der Latenz von search_filtered_internal |
| `` | `crates/contextra-vector/benches/hnsw_bench.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` |  |
| `` | `crates/contextra-vector/benches/partial_rebuild_recall_bench.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` |  |
| `` | `crates/contextra-vector/src/acorn/gamma_augmentation.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Algorithmische Kantenbudget-Berechnung (γ-Augmentierung) für ACORN (Patel et al. 2024). |
| `` | `crates/contextra-vector/src/acorn/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Prädikatsagnostischer Suchpfad (ACORN-Muster, Patel et al. 2024). |
| `` | `crates/contextra-vector/src/acorn/naive_reference.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Naive O(n) Referenzimplementierung für ACORN Recall-Baseline-Vergleiche. |
| `` | `crates/contextra-vector/src/compute_pool.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Begrenzter ComputePool für CPU-intensive Tasks (z. B. HNSW-Index-Rebuild). |
| `` | `crates/contextra-vector/src/diskann/filtered.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | DiskANN-gefilterte Vektorsuche via adaptivem Oversampling mit Post-Filter (Spec §7.3 / ADR-013). |
| `` | `crates/contextra-vector/src/diskann/predicate_augmented.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Additiver, rein lesender Prototyp für prädikatsbewusste Graph-Traversierung (ACORN-γ-Prinzip). |
| `` | `crates/contextra-vector/src/distance.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Distanzberechnungen und Vektor-Dequantisierung via contextra-simd. |
| `` | `crates/contextra-vector/src/hnsw/acorn_filtered.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | ACORN Prädikats-gefilterte Graph-Suche (Patel et al. 2024) für HnswIndex. |
| `` | `crates/contextra-vector/src/hnsw/adaptive_ef.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Adaptives ef_search (Ada-ef) Richtlinien & Zustandsautomat für HNSW-Suche. |
| `` | `crates/contextra-vector/src/hnsw/arena.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Arena-Allocator (HnswArena) für HNSW-Nachbarlisten mit 64-Byte-Alignment, Slot-Freilisten und CAS-Relinking. |
| `` | `crates/contextra-vector/src/hnsw/deletion.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Synchronous ghost-free node deletion with budgeted neighborhood repair for HNSW graph. |
| `` | `crates/contextra-vector/src/hnsw/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | HNSW Vector Index mit Layer Descent, Soft-Deletes und transaktionalem Staging (TxBuffer). |
| `` | `crates/contextra-vector/src/hnsw/sq8_bias.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Quantisierungs-Bias-Kalibrierung (Sq8Bias) für SQ8-Quantisierung im HNSW Index Header. |
| `` | `crates/contextra-vector/src/persistence/header.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Persistenz-Schicht für HNSW-Dateiserialisierung (`.hnsw`) - Header-Format. |
| `` | `crates/contextra-vector/src/persistence/mmap.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | mmap-basiertes Lesen für HNSW Vektor-Indizes. |
| `` | `crates/contextra-vector/src/persistence/node.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Persistenz-Schicht für HNSW-Dateiserialisierung (`.hnsw`) - NodeRecord-Format. |
| `` | `crates/contextra-vector/src/persistence/tests.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Unit-Tests für HNSW Persistenz-Schicht. |
| `` | `crates/contextra-vector/src/quantize_rabitq.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | RaBitQ-Quantisierer (Binär-Quantisierung mit orthogonaler Rotation und Fehlerkorrektur). |
| `` | `crates/contextra-vector/tests/acorn_hnsw_differential.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Differential-Testing & Recall-Regressionstests für HnswIndex::search_knn_acorn (Spec §8.5, §22.4). |
| `` | `crates/contextra-vector/tests/adaptive_ef_recall.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrationstests für adaptives ef_search (Ada-ef) Recall, Determinismus, Performance- und Lösch-Invarianten. |
| `` | `crates/contextra-vector/tests/diskann_corruption_fallback_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Corruption detection and DiskAnnFallbackPolicy test (Pflichttest 2). |
| `` | `crates/contextra-vector/tests/diskann_fault_injection_test.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Fault-Injection Test for DiskANN rebuild failures (Pflichttest 1). |
| `` | `crates/contextra-vector/tests/hnsw_rebuild_search_consistency.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` |  |
| `` | `crates/contextra-vector/tests/k02_snapshot_rebuild_determinism.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` |  |
| `` | `crates/contextra/src/agent_memory.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Agent Memory Facade (Ring 4) — Provides a clean remember/recall/forget/relate API for AI Agents. |
| `` | `crates/contextra/src/builder.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Contextra Composition Root Builder (Ring 4). |
| `` | `crates/contextra/src/collection_profile.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | CollectionProfile & DeploymentTier Presets for Contextra (Spec B.1.8, AP-P0-05) |
| `` | `crates/contextra/src/lib.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Contextra Primary Facade & Composition Root (Ring 4). |
| `` | `crates/contextra/src/performance_profile.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | PerformanceProfile Presets for Contextra (Spec B.1.6, AP-P0-05) |
| `` | `crates/contextra/src/query_rewriter.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | LLM-gestützter QueryRewriter für MultiStep-Retrieval in der Facade (Ring 4). |
| `` | `crates/contextra/tests/collection_profile_matrix.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Test matrix of PerformanceProfile x KvDeleteMode combinations (Spec B.1.8) |
| `` | `crates/contextra/tests/common/mod.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Shared integration test helper functions for the `contextra` primary facade test suite. |
| `` | `crates/contextra/tests/deployment_tier_presets_valid.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Test deployment tier presets validation (Spec B.1.8 / INV-COLLECTION-PROFILE-2) |
| `` | `crates/contextra/tests/llm_query_rewriter.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Integrationstests für LLM-gestützten QueryRewriter in contextra. |
| `` | `crates/contextra/tests/regulated_auto_extraction_default.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Verify DeploymentTier presets auto_extraction defaults (Spec D.6 / J.16/B-08) |
| `` | `crates/contextra/tests/vertical_path_ssi_under_write_load.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | Vertikaler Pfad-Test 3 (Teil 14.3 v17), Bezug B-16: Schreiblast parallel zu einem langen offenen Snapshot darf SSI nicht beeinträchtigen oder ausfallen lassen. |
| `` | `crates/contextra/tests/wiring_matrix.rs` | `FILE-CONTEXT` | `-` | `-` | `-` | `-` | End-to-End Facade Wiring Matrix Integration Tests (§20.2 / Regel R1). |
