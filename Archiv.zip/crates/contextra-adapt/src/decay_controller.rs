//! Adaptive Decay Controller (Cache-Eviction mit Time-Weighted Decay) (F-01).
//!
//! FEATURE-FLAG: `background-maintenance` (default-off in P1-safe Config).
//! KEINE neuen Infrastruktur-Abhängigkeiten — alle Inputs sind bereits vorhanden:
//! - tombstone_ratio: HnswIndex::tombstone_ratio()
//! - query_load_inverse: AtomicU64-Zähler in LsmStorage
//!
//! FORMEL:
//! T(t) = w1 * tombstone_ratio + w2 * query_load_inverse  ∈ `[0, 1]`
//! half_life_eff = half_life_base * (1 + κ * (1 − T(t)))
//! effective_score = base_score * exp(−(ln2 / half_life_eff) * elapsed_tx)
//!
//! SEMANTIK:
//! Hohe T (voller Speicher) → kurze Half-Life → aggressives Vergessen.
//! Niedrige T (freier Speicher) → lange Half-Life → längeres Behalten.
//! ADR-016: TxId-Differenz statt SystemTime (deterministisch, replay-safe).

/// Inputs for Adaptive Decay Controller (Cache-Eviction mit Time-Weighted Decay) aus bestehenden System-Metriken.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct DecaySignalInputs {
    /// HNSW-Tombstone-Ratio ∈ `[0, 1]`. Quelle: HnswIndex::tombstone_ratio().
    pub tombstone_ratio: f32,
    /// Normalisierte inverse Query-Rate ∈ `[0, 1]`.
    /// Berechnung: 1 - (queries_in_window / max_queries_per_window).
    /// Hoher Wert = wenig Queries = System idle = konservativer Verfall.
    pub query_load_inverse: f32,
    /// Gewichtung für Tombstone-Ratio im Verfallssignal.
    pub w_tombstone: f32,
    /// Gewichtung für Inverse-Query-Load im Verfallssignal.
    pub w_query: f32,
}

impl Default for DecaySignalInputs {
    fn default() -> Self {
        Self {
            tombstone_ratio: 0.0,
            query_load_inverse: 0.5,
            w_tombstone: 0.6,
            w_query: 0.4,
        }
    }
}

/// Konfiguration für Adaptive Decay Controller (Cache-Eviction mit Time-Weighted Decay) (via MaintenanceConfig).
#[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
pub struct DecayControllerConfig {
    /// Verstärkungsfaktor κ. Default: 2.0.
    pub kappa: f32,
    /// Basis-Half-Life in TxId-Einheiten. Default: 10_000.
    pub base_half_life_tx: u64,
    /// Eviction-Schwelle: Scores darunter werden evicted. Default: 0.01.
    pub eviction_threshold: f32,
}

impl Default for DecayControllerConfig {
    fn default() -> Self {
        Self {
            kappa: 2.0,
            base_half_life_tx: 10_000,
            eviction_threshold: 0.01,
        }
    }
}

/// Adaptive Decay Controller für time-weighted Cache-Eviction.
#[derive(Debug, Clone, PartialEq)]
pub struct AdaptiveDecayController {
    config: DecayControllerConfig,
}

impl AdaptiveDecayController {
    /// Erstellt einen neuen `AdaptiveDecayController` mit der angegebenen Konfiguration.
    pub fn new(config: DecayControllerConfig) -> Self {
        Self { config }
    }

    /// Erstellt einen neuen `AdaptiveDecayController` mit Standardwerten.
    pub fn with_defaults() -> Self {
        Self::new(DecayControllerConfig::default())
    }

    /// Liefer eine Referenz auf die Konfiguration zurück.
    pub fn config(&self) -> &DecayControllerConfig {
        &self.config
    }

    /// Berechnet aktuelle Systemtemperatur T(t) ∈ `[0, 1]`.
    #[inline]
    pub fn system_temperature(&self, inputs: &DecaySignalInputs) -> f32 {
        (inputs.w_tombstone * inputs.tombstone_ratio + inputs.w_query * inputs.query_load_inverse)
            .clamp(0.0, 1.0)
    }

    /// Effektive Half-Life unter aktueller Temperatur.
    #[inline]
    pub fn effective_half_life(&self, temperature: f32) -> f32 {
        self.config.base_half_life_tx as f32 * (1.0 + self.config.kappa * (1.0 - temperature))
    }

    /// Temperatur-adjustierter Score für einen Chunk.
    ///
    /// `elapsed_tx`: TxId(now) - TxId(chunk_created). ADR-016: kein SystemTime.
    pub fn effective_score(
        &self,
        base_score: f32,
        elapsed_tx: u64,
        inputs: &DecaySignalInputs,
    ) -> f32 {
        let temperature = self.system_temperature(inputs);
        let half_life = self.effective_half_life(temperature);
        let decay_exponent = -(std::f32::consts::LN_2 / half_life) * elapsed_tx as f32;
        // Verhindert NaN bei sehr großem elapsed_tx
        base_score * decay_exponent.exp().max(0.0)
    }

    /// Gibt true wenn Chunk unter Eviction-Schwelle.
    /// Wird von Background Workers (background_workers.rs) für Sweep verwendet.
    #[inline]
    pub fn should_evict(
        &self,
        base_score: f32,
        elapsed_tx: u64,
        inputs: &DecaySignalInputs,
    ) -> bool {
        self.effective_score(base_score, elapsed_tx, inputs) < self.config.eviction_threshold
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_temperature_clamp() {
        let t = AdaptiveDecayController::with_defaults();
        let inputs = DecaySignalInputs {
            tombstone_ratio: 1.0,
            query_load_inverse: 1.0,
            ..Default::default()
        };
        let temp = t.system_temperature(&inputs);
        assert!(
            (0.0..=1.0).contains(&temp),
            "Temperatur muss in [0,1] sein: {temp}"
        );
    }

    #[test]
    fn test_high_temperature_shorter_half_life() {
        let t = AdaptiveDecayController::with_defaults();
        let hot = DecaySignalInputs {
            tombstone_ratio: 1.0,
            query_load_inverse: 1.0,
            ..Default::default()
        };
        let cold = DecaySignalInputs {
            tombstone_ratio: 0.0,
            query_load_inverse: 0.0,
            ..Default::default()
        };

        let temp_hot = t.system_temperature(&hot);
        let temp_cold = t.system_temperature(&cold);

        assert!(
            t.effective_half_life(temp_hot) < t.effective_half_life(temp_cold),
            "Hohe Temperatur → kürzere Half-Life"
        );
    }

    #[test]
    fn test_effective_score_decays_over_time() {
        let t = AdaptiveDecayController::with_defaults();
        let inputs = DecaySignalInputs::default();
        let early = t.effective_score(1.0, 100, &inputs);
        let late = t.effective_score(1.0, 10_000, &inputs);
        assert!(
            early > late,
            "Score soll über Zeit fallen: {early} > {late}"
        );
    }

    #[test]
    fn test_effective_score_non_negative() {
        let t = AdaptiveDecayController::with_defaults();
        let inputs = DecaySignalInputs {
            tombstone_ratio: 1.0,
            ..Default::default()
        };
        // Sehr langer Zeitraum — kein negativer Score
        let score = t.effective_score(1.0, u64::MAX / 2, &inputs);
        assert!(score >= 0.0, "Score darf nie negativ sein: {score}");
    }

    #[test]
    fn test_should_evict_low_score_high_temp() {
        let t = AdaptiveDecayController::with_defaults();
        let hot = DecaySignalInputs {
            tombstone_ratio: 1.0,
            query_load_inverse: 1.0,
            ..Default::default()
        };
        // Nach sehr langer Zeit bei hoher Temperatur → eviction
        assert!(t.should_evict(1.0, 1_000_000, &hot));
    }

    #[test]
    fn test_should_not_evict_fresh_chunk() {
        let t = AdaptiveDecayController::with_defaults();
        let inputs = DecaySignalInputs::default();
        // Frischer Chunk (elapsed_tx=0) → kein Evict
        assert!(!t.should_evict(1.0, 0, &inputs));
    }

    #[test]
    fn test_engine_equivalence_and_accessors() {
        let config = DecayControllerConfig {
            kappa: 2.0,
            base_half_life_tx: 10_000,
            eviction_threshold: 0.01,
        };
        let controller = AdaptiveDecayController::new(config.clone());
        assert_eq!(controller.config(), &config);

        let inputs_default = DecaySignalInputs::default();
        let temp = controller.system_temperature(&inputs_default);
        // temp = 0.6 * 0.0 + 0.4 * 0.5 = 0.2
        assert!((temp - 0.2).abs() < 1e-6);

        let half_life = controller.effective_half_life(temp);
        // half_life = 10_000 * (1 + 2 * (1 - 0.2)) = 10_000 * (1 + 1.6) = 26_000
        assert!((half_life - 26_000.0).abs() < 1e-3);

        let score_fresh = controller.effective_score(1.0, 0, &inputs_default);
        assert!((score_fresh - 1.0).abs() < 1e-6);

        let score_at_half_life = controller.effective_score(1.0, 26_000, &inputs_default);
        assert!((score_at_half_life - 0.5).abs() < 1e-3);

        let hot_inputs = DecaySignalInputs {
            tombstone_ratio: 1.0,
            query_load_inverse: 1.0,
            ..Default::default()
        };
        let temp_hot = controller.system_temperature(&hot_inputs);
        assert!((temp_hot - 1.0).abs() < 1e-6);

        let half_life_hot = controller.effective_half_life(temp_hot);
        assert!((half_life_hot - 10_000.0).abs() < 1e-3);

        let score_hot_decayed = controller.effective_score(1.0, 100_000, &hot_inputs);
        assert!(score_hot_decayed < config.eviction_threshold);
        assert!(controller.should_evict(1.0, 100_000, &hot_inputs));
    }
}
