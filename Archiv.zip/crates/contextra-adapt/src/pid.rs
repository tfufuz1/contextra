// FILE-CONTEXT
// STAND: 2026-09-11T00:00:00Z
// ZWECK: Adaptive Reranking candidate pool-size regulation via PID latency control (F-08 & P11).
// INVARIANTEN: Pool size bounded by [min_pool_size, max_pool_size], min_pool_size >= 50 hard floor, non-finite latency measurements ignored.
// NICHT-OFFENSICHTLICH: Anti-windup integral clamping prevents overshoot under sustained latency spikes.
// SIEHE AUCH: crates/contextra-calibration/src/lib.rs, crates/contextra-db/src/homeostat.rs

//! F-08: PID-Regler für Reranking-Kandidatenpool-Größe.
//!
//! Hält Reranking-Latenz auf `target_latency_ms` durch adaptive Pool-Größe.
//! ANTI-WINDUP: Integrations-Stop im Sättigungsfall (Output Clamp Range).
//!
//! # Scientific Foundation
//! arXiv:2604.01733 (T2-RAGBench) demonstrate the non-linear relationship between candidate pool size (`k_pool`) and retrieval Recall@5:
//! - `k_pool = 20` → Recall@5 = 0.458
//! - `k_pool = 50` → Recall@5 = 0.826 (Quality Knee / Knee Point)
//! - `k_pool = 100` → Recall@5 = 0.888
//!
//! While Recall@5 reaches 0.888 at pool >= 100, `PID_MIN_POOL_SIZE_DEFAULT = 50` is enforced as the strict hard floor (`min_pool_size >= 50`).
//! Under extreme latency spikes, pool size may contract down to 50 (accepting a bounded recall drop to 0.826 at the Quality Knee),
//! but will NEVER drop to 20 or below where Recall collapses catastrophically (0.458).

use std::time::Duration;

/// Minimale Kandidaten-Pool-Größe (Hard Floor = 50, Quality Knee per arXiv:2604.01733).
pub const PID_MIN_POOL_SIZE_DEFAULT: usize = 50;

/// Maximale Kandidaten-Pool-Größe.
pub const PID_MAX_POOL_SIZE_DEFAULT: usize = 200;

/// Erweitert PID-Regler um konditionelles Anti-Windup bei Aktuatorsättigung.
///
/// Unterschied zu einfachem Integral-Clamping: Der Integrator akkumuliert
/// NUR, wenn die Stellgröße nicht gesättigt ist — verhindert träges Abklingen
/// nach I/O-Spitzen (Back-Calculation Anti-Windup Pattern).
///
/// # P28-Konformität
/// `dt` MUSS aus einem injizierten Clock-Port abgeleitet werden, nicht aus
/// `SystemTime::now()` direkt.
pub trait AntiWindupController: Send + Sync {
    /// Aktualisiert den Regler mit konditionellem Integrator-Update.
    ///
    /// `dt`: Zeitdelta seit letztem Update (aus injiziertem Clock-Port).
    /// `measured_latency_ms`: gemessene Latenz in Millisekunden.
    /// `is_actuator_saturated`: true, wenn die Stellgröße am konfigurierten
    ///   Limit liegt (Pool-Größe = max oder = min).
    ///
    /// Gibt die neue Pool-Größe zurück.
    fn update_with_anti_windup(
        &mut self,
        dt: Duration,
        measured_latency_ms: f32,
        is_actuator_saturated: bool,
    ) -> usize;
}

/// PID-Regler zur dynamischen Steuerung der Reranking-Kandidatenpool-Größe basierend auf Latenzmessungen.
///
/// # Anti-Windup Strategien
/// - Standard-Methode [`update`](Self::update): Nutzt einfaches Integrations-Clamping auf `[-max_integral, max_integral]`.
/// - Erweiterte Methode [`update_with_anti_windup`](AntiWindupController::update_with_anti_windup): Stoppt die
///   Integrationsakkumulation vollständig, sobald `is_actuator_saturated = true` signalisiert wird (Back-Calculation Pattern).
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct PidController {
    /// Proportionaler Gewichtsbeiwert $K_p$.
    pub kp: f32,
    /// Integraler Gewichtsbeiwert $K_i$.
    pub ki: f32,
    /// Differentieller Gewichtsbeiwert $K_d$.
    pub kd: f32,
    /// Ziel-Reranking-Latenz in Millisekunden.
    pub target_latency_ms: f32,
    /// Minimale zulässige Pool-Größe (stets >= 50).
    pub min_pool_size: usize,
    /// Maximale zulässige Pool-Größe.
    pub max_pool_size: usize,
    /// Aktuell empfohlene Pool-Größe.
    pub current_pool_size: Option<usize>,
    integral: f32,
    prev_error: f32,
    max_integral: f32, // Anti-windup
}

impl Default for PidController {
    fn default() -> Self {
        Self::new(
            150.0,
            PID_MIN_POOL_SIZE_DEFAULT,
            PID_MAX_POOL_SIZE_DEFAULT,
            None,
        )
    }
}

impl PidController {
    /// Erstellt einen neuen `PidController` mit expliziten Parametern.
    ///
    /// `min_pool_size` wird strikt auf mindestens 50 erzwungen (`min_pool_size.max(50)`).
    pub fn new(
        target_latency_ms: f32,
        min_pool_size: usize,
        max_pool_size: usize,
        initial_pool: Option<usize>,
    ) -> Self {
        let min_pool_size = min_pool_size.max(PID_MIN_POOL_SIZE_DEFAULT);
        let max_pool_size = max_pool_size.max(min_pool_size);
        let current_pool_size = initial_pool.map(|p| p.clamp(min_pool_size, max_pool_size));
        Self {
            kp: 0.5,
            ki: 0.05,
            kd: 0.1,
            target_latency_ms,
            min_pool_size,
            max_pool_size,
            current_pool_size,
            integral: 0.0,
            prev_error: 0.0,
            max_integral: 100.0,
        }
    }

    /// Verarbeitet eine neue Latenz-Messung und gibt die neue Pool-Größe zurück.
    ///
    /// ANTI-WINDUP: Führt Integral-Update nur durch, wenn Stellwert nicht gesättigt ist.
    pub fn update(&mut self, dt: Duration, measured_latency_ms: f32) -> usize {
        let current_pool = self.current_pool_size.unwrap_or(self.min_pool_size);
        if !measured_latency_ms.is_finite() || dt.is_zero() {
            return current_pool;
        }

        let dt_s = dt.as_secs_f32().clamp(0.001, 10.0);
        let error = self.target_latency_ms - measured_latency_ms;
        let candidate_integral =
            (self.integral + error * dt_s).clamp(-self.max_integral, self.max_integral);
        let derivative = (error - self.prev_error) / dt_s;

        let u = self.kp * error + self.ki * candidate_integral + self.kd * derivative;
        self.prev_error = error;

        let new_size = (current_pool as f32 + u).round() as isize;
        let min_s = self.min_pool_size as isize;
        let max_s = self.max_pool_size as isize;

        if new_size >= min_s && new_size <= max_s {
            self.integral = candidate_integral;
        }

        let clamped = new_size.clamp(min_s, max_s) as usize;
        self.current_pool_size = Some(clamped);
        clamped
    }

    /// Gibt die aktuell empfohlene Pool-Größe zurück.
    pub fn current_pool_size(&self) -> Option<usize> {
        self.current_pool_size
    }

    /// Setzt Integral und Derivative auf 0 zurück (z.B. bei Konfigurationsänderung).
    pub fn reset(&mut self) {
        self.integral = 0.0;
        self.prev_error = 0.0;
        self.current_pool_size = None;
    }
}

impl AntiWindupController for PidController {
    fn update_with_anti_windup(
        &mut self,
        dt: Duration,
        measured_latency_ms: f32,
        is_actuator_saturated: bool,
    ) -> usize {
        let current_pool = self.current_pool_size.unwrap_or(self.min_pool_size);
        if !measured_latency_ms.is_finite() || dt.is_zero() {
            return current_pool;
        }

        let dt_s = dt.as_secs_f32().clamp(0.001, 10.0);
        let error = self.target_latency_ms - measured_latency_ms;

        if !is_actuator_saturated {
            self.integral =
                (self.integral + error * dt_s).clamp(-self.max_integral, self.max_integral);
        }

        let derivative = (error - self.prev_error) / dt_s;
        let u = self.kp * error + self.ki * self.integral + self.kd * derivative;
        self.prev_error = error;

        let new_size = (current_pool as f32 + u).round() as isize;
        let min_s = self.min_pool_size as isize;
        let max_s = self.max_pool_size as isize;

        let clamped = new_size.clamp(min_s, max_s) as usize;
        self.current_pool_size = Some(clamped);
        clamped
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_pid_stable_at_target() {
        let mut pid = PidController::new(150.0, 50, 200, Some(100));
        let dt = Duration::from_millis(100);
        let initial_pool = 100;
        let new_pool = pid.update(dt, 150.0); // measured_latency = target_latency_ms
        assert_eq!(new_pool, initial_pool);
        assert_eq!(pid.current_pool_size, Some(initial_pool));
    }

    #[test]
    fn test_pid_latency_too_high_reduces_pool() {
        let mut pid = PidController::new(150.0, 50, 200, Some(100));
        let dt = Duration::from_millis(100);
        let initial_pool = 100;
        let new_pool = pid.update(dt, 300.0); // measured_latency (300) > target (150)
        assert!(new_pool < initial_pool);
        assert_eq!(pid.current_pool_size, Some(new_pool));
    }

    #[test]
    fn test_pid_latency_too_low_increases_pool() {
        let mut pid = PidController::new(150.0, 50, 200, Some(100));
        let dt = Duration::from_millis(100);
        let initial_pool = 100;
        let new_pool = pid.update(dt, 50.0); // measured_latency (50) < target (150)
        assert!(new_pool > initial_pool);
        assert_eq!(pid.current_pool_size, Some(new_pool));
    }

    #[test]
    fn test_pid_non_finite_latency_ignored() {
        let mut pid = PidController::new(150.0, 50, 200, Some(100));
        let dt = Duration::from_millis(100);
        let _ = pid.update(dt, 150.0);
        let integral_before = pid.integral;
        let prev_error_before = pid.prev_error;

        // Test NAN
        let size_nan = pid.update(dt, f32::NAN);
        assert_eq!(size_nan, 100);
        assert_eq!(pid.integral, integral_before);
        assert_eq!(pid.prev_error, prev_error_before);

        // Test INFINITY
        let size_inf = pid.update(dt, f32::INFINITY);
        assert_eq!(size_inf, 100);
        assert_eq!(pid.integral, integral_before);
        assert_eq!(pid.prev_error, prev_error_before);
    }

    #[test]
    fn test_pid_anti_windup_halts_integral_accumulation() {
        let mut pid = PidController::new(150.0, 50, 200, Some(100));
        let dt = Duration::from_millis(100);

        // Perform 100 updates with extreme high latency to hit min floor (50)
        for _ in 0..100 {
            pid.update(dt, 1000.0);
        }

        let saturated_integral = pid.integral;

        // Further updates while saturated must not keep accumulating integral downwards
        pid.update(dt, 1000.0);
        assert_eq!(
            pid.integral, saturated_integral,
            "Anti-windup must halt integral accumulation when output is saturated"
        );
    }

    #[test]
    fn test_pid_clamps_to_min_max() {
        let mut pid = PidController::new(150.0, 50, 150, Some(100));
        let dt = Duration::from_millis(100);

        // Force drastic reduction below min
        let res_min = pid.update(dt, 10000.0);
        assert_eq!(res_min, 50);
        assert_eq!(pid.current_pool_size, Some(50));

        // Force drastic increase above max
        let res_max = pid.update(dt, 0.0);
        assert_eq!(res_max, 150);
        assert_eq!(pid.current_pool_size, Some(150));
    }

    #[test]
    fn test_high_latency_causes_monotonic_decrease_bounded_by_k_min() {
        let mut pid = PidController::new(150.0, 50, 200, Some(100));
        let dt = Duration::from_millis(100);
        if let Some(mut prev_pool) = pid.current_pool_size {
            for _ in 0..10 {
                let new_pool = pid.update(dt, 300.0);
                assert!(
                    new_pool <= prev_pool,
                    "Pool size must monotonically decrease under high latency: prev={prev_pool}, new={new_pool}"
                );
                assert!(
                    new_pool >= 50,
                    "Pool size must never fall below hard floor k_min=50: got {new_pool}"
                );
                prev_pool = new_pool;
            }

            assert_eq!(
                pid.current_pool_size,
                Some(50),
                "Pool size should settle at hard minimum k_min=50"
            );
        } else {
            panic!("Expected current_pool_size to be set");
        }
    }

    #[test]
    fn test_low_latency_causes_increase_bounded_by_k_max() {
        let mut pid = PidController::new(150.0, 50, 200, Some(100));
        let dt = Duration::from_millis(100);
        if let Some(mut prev_pool) = pid.current_pool_size {
            for _ in 0..10 {
                let new_pool = pid.update(dt, 50.0);
                assert!(
                    new_pool >= prev_pool,
                    "Pool size must increase under low latency: prev={prev_pool}, new={new_pool}"
                );
                assert!(
                    new_pool <= 200,
                    "Pool size must never exceed k_max=200: got {new_pool}"
                );
                prev_pool = new_pool;
            }

            assert_eq!(
                pid.current_pool_size,
                Some(200),
                "Pool size should settle at maximum k_max=200"
            );
        } else {
            panic!("Expected current_pool_size to be set");
        }
    }

    #[test]
    fn test_oscillating_latency_anti_windup_clamp() {
        let mut pid = PidController::new(150.0, 50, 200, Some(100));
        let dt = Duration::from_millis(100);

        for i in 0..20 {
            let observed = if i % 2 == 0 { 1000.0 } else { 1.0 };
            pid.update(dt, observed);
            assert!(
                pid.integral.is_finite(),
                "Integral must remain finite under extreme latency oscillations"
            );
        }
    }

    #[test]
    fn test_hard_k_min_floor_never_below_50() {
        let mut pid = PidController::new(150.0, 10, 200, Some(100));
        let dt = Duration::from_millis(100);
        assert_eq!(
            pid.min_pool_size, 50,
            "Constructor must enforce hard floor min_pool_size >= 50"
        );

        for _ in 0..50 {
            let pool = pid.update(dt, 10_000.0);
            assert!(
                pool >= 50,
                "pool must NEVER drop below 50 regardless of control input"
            );
        }
    }

    #[test]
    fn test_pid_nan_latency_preserves_state_and_returns_current_pool() {
        let mut pid = PidController::default();
        let dt = Duration::from_millis(100);
        pid.update(dt, 250.0);

        let ref_integral = pid.integral;
        let ref_prev_error = pid.prev_error;
        let ref_current_pool_size = pid.current_pool_size;
        if let Some(expected_pool) = ref_current_pool_size {
            let result = pid.update(dt, f32::NAN);

            assert_eq!(result, expected_pool);
            assert_eq!(pid.integral, ref_integral);
            assert_eq!(pid.prev_error, ref_prev_error);
            assert_eq!(pid.current_pool_size, ref_current_pool_size);
        } else {
            panic!("Expected current_pool_size to be set");
        }
    }

    macro_rules! assert_f32_near {
        ($left:expr, $right:expr, $tol:expr) => {
            let diff = ($left - $right).abs();
            assert!(
                diff <= $tol,
                "Assertion failed: {} ~ {} (diff: {}, tol: {})",
                $left,
                $right,
                diff,
                $tol
            );
        };
    }

    #[test]
    fn test_pid_dt_rate_independence() {
        // Compare 1 update with dt=1.0s vs 10 updates with dt=0.1s under steady error
        let mut pid1 = PidController::new(150.0, 50, 10000, Some(200));
        pid1.kd = 0.0;
        let mut pid2 = PidController::new(150.0, 50, 10000, Some(200));
        pid2.kd = 0.0;

        // 1 step of 1.0s
        pid1.update(Duration::from_secs(1), 100.0);

        // 10 steps of 0.1s
        for _ in 0..10 {
            pid2.update(Duration::from_millis(100), 100.0);
        }

        // Integral accumulation over total time of 1 second should be equal
        assert_f32_near!(pid1.integral, pid2.integral, 1e-4);
    }

    #[test]
    fn test_pid_nan_on_fresh_controller_returns_min_pool_size() {
        let mut pid = PidController::default();
        let dt = Duration::from_millis(100);
        assert_eq!(pid.current_pool_size, None);

        let result = pid.update(dt, f32::NAN);

        assert_eq!(result, pid.min_pool_size);
        assert_eq!(pid.integral, 0.0);
        assert_eq!(pid.prev_error, 0.0);
        assert_eq!(pid.current_pool_size, None);
    }

    #[test]
    fn test_pid_recovers_correctly_after_nan_then_valid_input() {
        let dt = Duration::from_millis(100);
        let mut pid_with_nan = PidController::default();
        let _ = pid_with_nan.update(dt, 250.0);
        pid_with_nan.update(dt, f32::NAN);
        let pool_nan_3 = pid_with_nan.update(dt, 180.0);

        let mut pid_without_nan = PidController::default();
        let _ = pid_without_nan.update(dt, 250.0);
        let pool_no_nan_2 = pid_without_nan.update(dt, 180.0);

        assert_eq!(pool_nan_3, pool_no_nan_2);
        assert_eq!(pid_with_nan.integral, pid_without_nan.integral);
        assert_eq!(pid_with_nan.prev_error, pid_without_nan.prev_error);
    }
}
