//! Query-Abstraktionen (wie `HybridQuery` und `HybridQueryBuilder`) sowie Signal-Fusionstypen.
//!
//! # Architektur-Rolle: Ring 0 (Hybride Multi-Signal-Suche)
//!
//! Contextra synthetisiert Antworten über vier Suchkanäle (Dense Vector, Sparse Text, Graph und Recency).
//!
//! Dieses Modul stellt bereit:
//! - `HybridQuery`: Zentrale Abfragestruktur mit Text, Embedding, Startknoten und Filtern.
//! - `HybridQueryBuilder`: Ergonomischer Value-Builder zur Konstruktion unveränderlicher Abfragen.
//! - `FusionWeights`: Auf 1.0 normalisierte Gewichte für Vektor-, Text- und Graph-Signale.
//! - `FusionStrategy`: Fusionsalgorithmen (RRF = Reciprocal Rank Fusion, Score-Normalisierung).
//! - `ContextChunk` & `ContextWindow`: Für LLMs aufbereitete Textsegmente inklusive Tokenzählung und Zettelkasten-Links.

// FILE-CONTEXT
// STAND: 2026-08-30T18:51:56Z (SESSION: e459bd5f)
// ZWECK: Multi-Signal HybridQuery, FusionWeights, ContextWindow und ContextChunk Repräsentation.
// INVARIANTEN: FusionWeights::new normalisiert die Summe auf ~1.0 (Summe in [0.999, 1.001]).
// HOTSPOTS: 30-320
// NICHT-OFFENSICHTLICH: metadata signal weight ist in FusionWeights reserviert und liefert via pub fn metadata() 0.0 zurück.
// SIEHE AUCH: rules/tag_taxonomy.md, DECISIONS.md (ADR-021)

use super::domain::{DocId, EntityId, MemoryType, PprConfig};
use super::filter::FilterExpr;
use crate::error::{ContextraError, Result};
use serde::{Deserialize, Serialize};

/// Strategy used for search result signal fusion.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default, Serialize, Deserialize)]
// ANCHOR[contextra-types:SAOS-FUSIONSTRAT]
pub enum FusionStrategy {
    /// Reciprocal Rank Fusion (default strategy per ADR-003).
    /// Robust against score scale mismatch and partial signal degradation.
    #[default]
    Rrf,
    /// Score-normalized fusion (CombSUM / Z-Score).
    /// Explizit Opt-in strategy. Falls back to RRF if signal degradation is detected.
    ScoreNormalized,
}

/// Strategy configuration mapping per retrieval signal (vector, text, graph).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
// ANCHOR[contextra-types:SAOS-SIGNALSTRAT]
pub struct SignalFusionStrategies {
    /// Strategy used for vector search signal fusion.
    pub vector: FusionStrategy,
    /// Strategy used for full-text search signal fusion.
    pub text: FusionStrategy,
    /// Strategy used for graph search signal fusion.
    pub graph: FusionStrategy,
}

impl Default for SignalFusionStrategies {
    fn default() -> Self {
        Self {
            vector: FusionStrategy::Rrf,
            text: FusionStrategy::Rrf,
            graph: FusionStrategy::Rrf,
        }
    }
}

impl From<FusionStrategy> for SignalFusionStrategies {
    fn from(s: FusionStrategy) -> Self {
        Self {
            vector: s,
            text: s,
            graph: s,
        }
    }
}

impl SignalFusionStrategies {
    /// Creates a uniform configuration where all signals use the specified strategy.
    pub fn uniform(strategy: FusionStrategy) -> Self {
        strategy.into()
    }

    /// Returns the fusion strategy configured for a specific signal name ("vector", "text", "graph").
    pub fn strategy_for_signal(&self, signal_name: &str) -> FusionStrategy {
        match signal_name {
            "vector" => self.vector,
            "text" => self.text,
            "graph" => self.graph,
            _ => FusionStrategy::Rrf,
        }
    }
}

impl<'de> Deserialize<'de> for SignalFusionStrategies {
    fn deserialize<D>(deserializer: D) -> std::result::Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        #[derive(Deserialize)]
        #[serde(untagged)]
        enum StrategyHelper {
            Single(FusionStrategy),
            PerSignal {
                #[serde(default)]
                vector: FusionStrategy,
                #[serde(default)]
                text: FusionStrategy,
                #[serde(default)]
                graph: FusionStrategy,
            },
        }

        match StrategyHelper::deserialize(deserializer)? {
            StrategyHelper::Single(s) => Ok(SignalFusionStrategies::from(s)),
            StrategyHelper::PerSignal {
                vector,
                text,
                graph,
            } => Ok(SignalFusionStrategies {
                vector,
                text,
                graph,
            }),
        }
    }
}

/// Strategy used for graph retrieval in hybrid search queries.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
// ANCHOR[contextra-types:SAOS-GRAPHTRAV]
pub enum GraphTraversalStrategy {
    /// Multi-hop BFS traversal with hop score decay (default max_hops = 3).
    Hops {
        /// Maximum traversal hop depth.
        max_hops: usize,
    },
    /// Personalized PageRank power iteration starting from seed nodes.
    PersonalizedPageRank(PprConfig),
    /// PathRAG bidirectional Dijkstra traversal with sufficiency filtering.
    PathRag {
        /// Maximum traversal hop depth.
        max_hops: usize,
        /// Sufficiency threshold for filtering low-confidence paths (default 0.1).
        sufficiency_threshold: f64,
    },
}

impl Default for GraphTraversalStrategy {
    fn default() -> Self {
        Self::Hops { max_hops: 3 }
    }
}

/// Normalized fusion weights for hybrid search.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
// ANCHOR[contextra-types:SAOS-WEIGHTS]
pub struct FusionWeights {
    vector: f32,
    text: f32,
    graph: f32,
    /// Reserved for future metadata-signal fusion; currently always 0.0. Do not expose a public constructor parameter for this until the fusion logic is implemented (see TRACKING-ISSUE #144).
    metadata: f32,
}

impl Default for FusionWeights {
    fn default() -> Self {
        Self {
            vector: 1.0 / 3.0,
            text: 1.0 / 3.0,
            graph: 1.0 / 3.0,
            metadata: 0.0,
        }
    }
}

impl FusionWeights {
    /// Creates 3-signal fusion weights (vector, text, graph) summing to 1.0.
    pub fn new(vector: f32, text: f32, graph: f32) -> Result<Self> {
        if vector.is_nan() || text.is_nan() || graph.is_nan() {
            return Err(ContextraError::InvalidInput(
                "Fusion weights must not be NaN".into(),
            ));
        }
        if !vector.is_finite() || !text.is_finite() || !graph.is_finite() {
            return Err(ContextraError::InvalidInput(
                "Fusion weights must be finite numbers".into(),
            ));
        }
        // FIND-COR-004: Guard against negative weights
        if vector < 0.0 || text < 0.0 || graph < 0.0 {
            return Err(ContextraError::InvalidInput(
                "Fusion weights must be non-negative".into(),
            ));
        }
        let sum = vector + text + graph;
        if (sum - 1.0).abs() > 1e-6 {
            return Err(ContextraError::InvalidInput(format!(
                "Fusion weights must sum exactly to 1.0, got {}",
                sum
            )));
        }
        Ok(Self {
            vector,
            text,
            graph,
            metadata: 0.0,
        })
    }

    /// Returns the vector signal weight component.
    pub fn vector(&self) -> f32 {
        self.vector
    }

    /// Returns the text signal weight component.
    pub fn text(&self) -> f32 {
        self.text
    }

    /// Returns the graph signal weight component.
    pub fn graph(&self) -> f32 {
        self.graph
    }

    /// Returns the metadata signal weight component.
    /// Reserved for future metadata-signal fusion; currently always 0.0. Do not expose a public constructor parameter for this until the fusion logic is implemented (see TRACKING-ISSUE #144).
    pub fn metadata(&self) -> f32 {
        self.metadata
    }
}

/// A chunk of context for LLM budget allocation.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
// ANCHOR[contextra-types:SAOS-CHUNK]
pub struct ContextChunk {
    /// Document identifier associated with this chunk.
    pub doc_id: DocId,
    /// Text content of the chunk.
    pub content: String,
    /// Computed relevance score.
    pub relevance: f32,
    /// Estimated token count for LLM context calculation.
    pub token_count: usize,
    /// Optional metadata associated with the chunk.
    pub metadata: Option<serde_json::Value>,
    /// LLM-generiertes Kontextpräfix (50–100 Tokens).
    /// None = kein Contextual Retrieval für diesen Chunk.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub contextual_prefix: Option<String>,
    /// Zettelkasten Memory Links associated with this chunk.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub links: Vec<crate::types::domain::MemoryLink>,
}

impl ContextChunk {
    /// Kombinierten Text für Text-Indizierung und Embedding.
    /// Entspricht dem etablierten Contextual-Schema: prefix + "\n\n" + content.
    ///
    /// Allokiert nur wenn `contextual_prefix` gesetzt. Akzeptabel für
    /// Ingestion-Pipeline (1× pro Chunk, kein Hot-Path).
    pub fn combined_text_owned(&self) -> String {
        match &self.contextual_prefix {
            Some(prefix) if !prefix.is_empty() => {
                let mut combined = String::with_capacity(prefix.len() + 2 + self.content.len());
                combined.push_str(prefix);
                combined.push_str("\n\n");
                combined.push_str(&self.content);
                combined
            }
            _ => self.content.clone(),
        }
    }

    /// Kombinierter Token-Count (Heuristik: chars/4 ≈ Tokens).
    /// Verwendet für Budget-Management in `contextra-db/src/context.rs`.
    pub fn combined_token_count(&self) -> usize {
        match &self.contextual_prefix {
            Some(p) if !p.is_empty() => self.token_count + p.len() / 4,
            _ => self.token_count,
        }
    }

    /// Gibt true zurück wenn contextual_prefix gesetzt und nicht leer.
    pub fn has_context_prefix(&self) -> bool {
        self.contextual_prefix
            .as_deref()
            .is_some_and(|p| !p.is_empty())
    }
}

/// An aggregated context window constrained by a token budget.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
// ANCHOR[contextra-types:SAOS-WINDOW]
pub struct ContextWindow {
    /// List of included context chunks.
    pub chunks: Vec<ContextChunk>,
    /// Total aggregated token count.
    pub total_tokens: usize,
    /// Indicates whether context chunks were truncated to fit the budget.
    pub truncated: bool,
}

impl std::fmt::Display for ContextWindow {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        for (i, chunk) in self.chunks.iter().enumerate() {
            if i > 0 {
                writeln!(f)?;
            }
            write!(f, "{}", chunk.content)?;
        }
        Ok(())
    }
}

/// Individual retrieval signal (vector, text, graph) in multi-signal hybrid search.
///
/// # Abgrenzung
/// Dieser Typ `contextra_types::Signal` beschreibt das ungewichtete Domänen-Enum der drei
/// primären Suchkanäle (`Vector`, `Text`, `Graph`) für das Query-Interface systemweit.
/// Im Gegensatz dazu ist `contextra_rank::fusion::types::Signal` eine interne Signal-Repräsentation
/// der Rank-Engine zur Gewichtsmodulation und Z-Score/RRF-Kalibrierung.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
// ANCHOR[contextra-types:SAOS-SIGNAL]
pub enum Signal {
    /// Dense vector embedding search signal.
    Vector,
    /// Lexical full-text search signal.
    Text,
    /// Graph traversal / PageRank signal.
    Graph,
}

impl std::fmt::Display for Signal {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Vector => write!(f, "Vector"),
            Self::Text => write!(f, "Text"),
            Self::Graph => write!(f, "Graph"),
        }
    }
}

/// Strategy for handling actual signal failures during hybrid search orchestration (Spec Teil 6.5).
///
/// **Semantik**:
/// - `Fail` (Default): If an individual signal fails due to an underlying internal error
///   (e.g., vector index failure or timeout), the search aborts immediately and returns a
///   structured error (`ContextraError`) explicitly identifying the failing signal.
/// - `Degrade`: If an individual signal fails, the search logs a warning and proceeds with
///   fusion across the remaining successful signals. The returned results bear a non-empty
///   `degraded_signals` list detailing which signals failed.
///
/// *Note*: An empty but valid result from a signal (e.g. no documents matched lexical text or zero vector)
/// is NOT a signal failure and does not trigger this behavior.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default, Serialize, Deserialize)]
// ANCHOR[contextra-types:SAOS-FAILPOLICY]
pub enum OnSignalFailure {
    /// Abort hybrid search and return an error on signal failure (Default per Spec Teil 6.5 P1).
    #[default]
    Fail,
    /// Degrade search gracefully using remaining active signals and report failed signals in `degraded_signals`.
    Degrade,
}

/// Output of a query rewriter containing text, semantic, and graph anchor reformulations.
#[derive(Debug, Clone, PartialEq, Default, Serialize, Deserialize)]
// ANCHOR[contextra-types:SAOS-REWRITE]
pub struct QueryRewriteOutput {
    /// Textual reformulation intended for lexical keyword search.
    pub text_query: Option<String>,
    /// Semantic reformulation intended for dense vector embedding search.
    pub semantic_query: Option<String>,
    /// Extracted anchor entity identifiers or names intended for graph traversal search.
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub anchor_entities: Vec<String>,
}

impl QueryRewriteOutput {
    /// Creates a new `QueryRewriteOutput` with text, semantic, and anchor entity reformulations.
    pub fn new(
        text_query: Option<String>,
        semantic_query: Option<String>,
        anchor_entities: Vec<String>,
    ) -> Self {
        Self {
            text_query,
            semantic_query,
            anchor_entities,
        }
    }

    /// Creates a simple text-only `QueryRewriteOutput`.
    pub fn text_only(text: impl Into<String>) -> Self {
        Self {
            text_query: Some(text.into()),
            semantic_query: None,
            anchor_entities: Vec::new(),
        }
    }

    /// Returns `true` if all reformulation components are empty or None.
    pub fn is_empty(&self) -> bool {
        self.text_query.as_ref().is_none_or(|s| s.trim().is_empty())
            && self
                .semantic_query
                .as_ref()
                .is_none_or(|s| s.trim().is_empty())
            && self.anchor_entities.is_empty()
    }
}

/// Evaluated result for hybrid/4-signal search.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
// ANCHOR[contextra-types:SAOS-SCOREDENTRY]
pub struct ScoredEntry {
    /// Unique result identifier.
    pub id: String,
    /// Combined final score after signal fusion.
    pub final_score: f32,
    /// Associated entry metadata.
    pub metadata: Option<serde_json::Value>,
}

/// A unified query traversing multiple index signals.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
// ANCHOR[contextra-types:SAOS-HYBRIDQUERY]
pub struct HybridQuery {
    /// Optional full-text query string.
    pub text_query: Option<String>,
    /// Optional vector query embedding.
    pub vector_query: Option<Vec<f32>>,
    /// Optional starting node ID for graph traversal search.
    pub graph_start_node: Option<String>,
    /// Graph traversal strategy (Hops or PersonalizedPageRank).
    #[serde(default)]
    pub graph_strategy: GraphTraversalStrategy,
    /// Fusion weights across vector, text, and graph signals.
    pub fusion_weights: FusionWeights,
    /// Fusion strategy used to combine search signals (default: all Rrf).
    #[serde(default)]
    pub fusion_strategy: SignalFusionStrategies,
    /// Optional metadata expression filter.
    pub filter: Option<FilterExpr>,
    /// Optional entity ID to filter/boost results in the same community.
    pub same_community_as: Option<EntityId>,
    /// Pre-RRF filter: only return results whose memory_type metadata field
    /// matches one of these types. None = no filter (default behaviour unchanged).
    #[serde(default)]
    pub memory_type_filter: Option<Vec<MemoryType>>,
    /// Controls whether superseded Zettelkasten memory chunks are included in results (ADR-038). Default: false.
    #[serde(default)]
    pub include_superseded: bool,
    /// Controls whether ProvenanceRecord is attached to SearchResult output. Default: false.
    #[serde(default)]
    pub include_provenance: bool,
    /// Candidate pool multiplier for pre-reranking retrieval (default: 10).
    /// Grounded in empirical evaluation from T2-RAGBench (arXiv:2604.01733), showing Recall@5 = 0.888
    /// with ~100 candidate items compared to 0.458 with only 20 candidates.
    #[serde(default)]
    pub rerank_pool_multiplier: Option<usize>,
    /// Upper bound cap for pre-reranking candidate pool expansion (default: 200).
    /// Prevents retrieval cost explosion for large k queries.
    #[serde(default)]
    pub rerank_pool_max: Option<usize>,
    /// Whether a cross-encoder reranker is attached to this query.
    /// Controls candidate pool expansion: only expand when true.
    #[serde(default)]
    pub has_reranker: bool,
    /// Controls behavior when an individual retrieval signal fails (Spec Teil 6.5). Default: Fail.
    #[serde(default)]
    pub on_signal_failure: OnSignalFailure,
    /// Maximum number of search results to return.
    pub k: usize,
}

/// Alias for [`HybridQuery`] representing query options for hybrid retrieval operations (Spec Teil 6.5).
pub type QueryOptions = HybridQuery;

impl HybridQuery {
    /// Creates a new `HybridQueryBuilder`.
    pub fn builder() -> HybridQueryBuilder {
        HybridQueryBuilder::default()
    }
}

/// Builder for HybridQuery to improve DX.
///
/// # Abgrenzung
/// `contextra_types::HybridQueryBuilder` ist ein speicherfreier, reiner Value-Builder in Ring 0,
/// der eine unveränderliche `HybridQuery`-Value-Instanz erzeugt.
/// Im Gegensatz dazu ist `contextra_engine::collection::query_builder::builder::HybridQueryBuilder`
/// an eine aktive `Collection`-Instanz mit Storage- und Vektorindex-Handles gebunden und führt
/// die Abfrage über `.execute()` direkt auf der Datenbank aus.
#[derive(Default)]
// ANCHOR[contextra-types:SAOS-BUILDER]
pub struct HybridQueryBuilder {
    text_query: Option<String>,
    vector_query: Option<Vec<f32>>,
    graph_start_node: Option<String>,
    graph_strategy: Option<GraphTraversalStrategy>,
    fusion_weights: Option<FusionWeights>,
    fusion_strategy: Option<SignalFusionStrategies>,
    filter: Option<FilterExpr>,
    same_community_as: Option<EntityId>,
    memory_type_filter: Option<Vec<MemoryType>>,
    include_superseded: bool,
    include_provenance: bool,
    rerank_pool_multiplier: Option<usize>,
    rerank_pool_max: Option<usize>,
    on_signal_failure: OnSignalFailure,
    k: Option<usize>,
}

/// Alias for [`HybridQueryBuilder`] representing a query options builder for hybrid retrieval operations (Spec Teil 6.5).
pub type QueryOptionsBuilder = HybridQueryBuilder;

impl HybridQueryBuilder {
    /// Creates a new `HybridQueryBuilder` with empty default options.
    pub fn new() -> Self {
        Self::default()
    }

    /// Sets the full-text search query string.
    pub fn with_text_query(mut self, q: impl Into<String>) -> Self {
        self.text_query = Some(q.into());
        self
    }

    /// Sets the vector query embedding.
    pub fn with_vector_query(mut self, v: Vec<f32>) -> Self {
        self.vector_query = Some(v);
        self
    }

    /// Sets the graph start node for graph traversal search.
    pub fn with_graph_start_node(mut self, start: impl Into<String>) -> Self {
        self.graph_start_node = Some(start.into());
        self
    }

    /// Sets the graph traversal strategy (Hops or PersonalizedPageRank).
    pub fn with_graph_strategy(mut self, strategy: GraphTraversalStrategy) -> Self {
        self.graph_strategy = Some(strategy);
        self
    }

    /// Sets custom signal fusion weights.
    pub fn with_fusion_weights(mut self, weights: FusionWeights) -> Self {
        self.fusion_weights = Some(weights);
        self
    }

    /// Sets search fusion strategy per signal or globally (`FusionStrategy` or `SignalFusionStrategies`).
    pub fn with_fusion_strategy(mut self, strategy: impl Into<SignalFusionStrategies>) -> Self {
        self.fusion_strategy = Some(strategy.into());
        self
    }

    /// Sets a metadata expression filter on the query.
    pub fn with_filter(mut self, filter: FilterExpr) -> Self {
        self.filter = Some(filter);
        self
    }

    /// Sets the community context entity filter/boost.
    pub fn with_same_community_as(mut self, entity_id: EntityId) -> Self {
        self.same_community_as = Some(entity_id);
        self
    }

    /// Sets the memory_type pre-RRF filter.
    pub fn with_memory_type_filter(mut self, types: Vec<MemoryType>) -> Self {
        self.memory_type_filter = Some(types);
        self
    }

    /// Sets whether to include superseded memory chunks (ADR-038).
    pub fn with_include_superseded(mut self, include: bool) -> Self {
        self.include_superseded = include;
        self
    }

    /// Sets whether to calculate and attach ProvenanceRecord to output results.
    pub fn with_include_provenance(mut self, include: bool) -> Self {
        self.include_provenance = include;
        self
    }

    /// Sets the candidate pool multiplier for pre-reranking retrieval.
    pub fn with_rerank_pool_multiplier(mut self, multiplier: usize) -> Self {
        self.rerank_pool_multiplier = Some(multiplier);
        self
    }

    /// Sets the upper bound cap for pre-reranking candidate pool expansion.
    pub fn with_rerank_pool_max(mut self, max: usize) -> Self {
        self.rerank_pool_max = Some(max);
        self
    }

    /// Sets the signal failure policy ([`OnSignalFailure`]) for the query (Spec Teil 6.5).
    pub fn with_on_signal_failure(mut self, policy: OnSignalFailure) -> Self {
        self.on_signal_failure = policy;
        self
    }

    /// Sets the top-K limit for the query.
    pub fn with_k(mut self, k: usize) -> Self {
        self.k = Some(k);
        self
    }

    /// Builds the `HybridQuery` instance.
    ///
    /// # Errors
    /// Returns `Err` if query parameters or fusion weights fail validation.
    pub fn build(self) -> Result<HybridQuery> {
        Ok(HybridQuery {
            text_query: self.text_query,
            vector_query: self.vector_query,
            graph_start_node: self.graph_start_node,
            graph_strategy: self.graph_strategy.unwrap_or_default(),
            fusion_weights: self.fusion_weights.unwrap_or_default(),
            fusion_strategy: self.fusion_strategy.unwrap_or_default(),
            filter: self.filter,
            same_community_as: self.same_community_as,
            memory_type_filter: self.memory_type_filter,
            include_superseded: self.include_superseded,
            include_provenance: self.include_provenance,
            rerank_pool_multiplier: self.rerank_pool_multiplier,
            rerank_pool_max: self.rerank_pool_max,
            has_reranker: false,
            on_signal_failure: self.on_signal_failure,
            k: self.k.unwrap_or(10),
        })
    }
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
mod tests {
    use super::*;
    use crate::TokenBudget;

    #[test]
    fn test_fusion_weights_valid() {
        let w = FusionWeights::new(0.5, 0.5, 0.0).expect("valid"); // expect
        assert_eq!(w.vector(), 0.5);
        assert_eq!(w.text(), 0.5);
    }

    #[test]
    fn test_fusion_weights_invalid_sum() {
        let result = FusionWeights::new(0.5, 0.6, 0.0);
        assert!(result.is_err());
        if let Err(ContextraError::InvalidInput(msg)) = result {
            assert!(msg.contains("must sum exactly to 1.0"));
        } else {
            panic!("Expected InvalidInput error");
        }
    }

    #[test]
    fn test_fusion_weights_default_is_balanced() {
        let w = FusionWeights::default();
        let eps = 1e-5f32;
        assert!(
            (w.vector() - 1.0 / 3.0).abs() < eps,
            "Default vector weight must be 1/3"
        );
        assert!(
            (w.text() - 1.0 / 3.0).abs() < eps,
            "Default text weight must be 1/3"
        );
        assert!(
            (w.graph() - 1.0 / 3.0).abs() < eps,
            "Default graph weight must be 1/3"
        );
    }

    #[test]
    fn test_hybrid_query_builder_default_uses_balanced_weights() {
        let query = HybridQueryBuilder::new()
            .with_text_query("test query")
            .with_k(10)
            .build()
            .unwrap();
        let eps = 1e-5f32;
        assert!((query.fusion_weights.vector() - 1.0 / 3.0).abs() < eps);
        assert!((query.fusion_weights.text() - 1.0 / 3.0).abs() < eps);
        assert!((query.fusion_weights.graph() - 1.0 / 3.0).abs() < eps);
    }

    #[test]
    fn test_hybrid_query_builder_happy_path() {
        let query = HybridQuery::builder()
            .with_text_query("test query")
            .with_vector_query(vec![0.1, 0.2])
            .with_k(5)
            .build()
            .expect("build ok"); // expect

        assert_eq!(query.text_query.unwrap(), "test query"); // unwrap
        assert_eq!(query.vector_query.unwrap(), vec![0.1, 0.2]); // unwrap
        assert_eq!(query.k, 5);
        // Default weights: balanced 1/3 each
        let eps = 1e-5f32;
        assert!((query.fusion_weights.vector() - 1.0 / 3.0).abs() < eps);
        assert!((query.fusion_weights.text() - 1.0 / 3.0).abs() < eps);
        assert!((query.fusion_weights.graph() - 1.0 / 3.0).abs() < eps);
    }

    #[test]
    fn test_hybrid_query_builder_custom_weights() {
        let weights = FusionWeights::new(0.4, 0.5, 0.1).unwrap(); // unwrap
        let query = HybridQuery::builder()
            .with_fusion_weights(weights.clone())
            .build()
            .unwrap(); // unwrap

        assert_eq!(query.fusion_weights, weights);
    }

    #[test]
    fn test_hybrid_query_builder_defaults() {
        let query = HybridQuery::builder().build().unwrap(); // unwrap
        assert_eq!(query.k, 10);
        let eps = 1e-5f32;
        assert!((query.fusion_weights.vector() - 1.0 / 3.0).abs() < eps);
        assert!((query.fusion_weights.text() - 1.0 / 3.0).abs() < eps);
        assert!((query.fusion_weights.graph() - 1.0 / 3.0).abs() < eps);
        assert!(query.text_query.is_none());
        assert!(query.vector_query.is_none());
    }

    #[test]
    fn test_token_budget_edge_cases() {
        let budget = TokenBudget::new(100, 20);
        assert_eq!(budget.available(), 80);

        budget.consume(50);
        assert_eq!(budget.available(), 30);

        budget.consume(40); // Over consumption
        assert_eq!(budget.available(), 0);
        assert_eq!(budget.consumed(), 90);
    }

    #[test]
    fn test_fusion_weights_negative_or_infinite() {
        let res_neg = FusionWeights::new(-0.1, 0.6, 0.5);
        assert!(res_neg.is_err());
        if let Err(ContextraError::InvalidInput(msg)) = res_neg {
            assert_eq!(msg, "Fusion weights must be non-negative");
        }

        let res_inf = FusionWeights::new(f32::INFINITY, 0.5, 0.5);
        assert!(res_inf.is_err());
        if let Err(ContextraError::InvalidInput(msg)) = res_inf {
            assert_eq!(msg, "Fusion weights must be finite numbers");
        }
    }

    #[test]
    fn test_fusion_weights_nan() {
        let res = FusionWeights::new(f32::NAN, 0.5, 0.5);
        assert!(res.is_err());
        if let Err(ContextraError::InvalidInput(msg)) = res {
            assert_eq!(msg, "Fusion weights must not be NaN");
        } else {
            panic!("Expected InvalidInput error");
        }
    }

    proptest::proptest! {
        #[test]
        fn prop_fusion_weights_never_panics(
            v in proptest::num::f32::ANY,
            t in proptest::num::f32::ANY,
            g in proptest::num::f32::ANY,
        ) {
            let res = FusionWeights::new(v, t, g);
            if v.is_nan() || t.is_nan() || g.is_nan() {
                let err = res.expect_err("NaN inputs must return an error"); // expect allowed
                if let ContextraError::InvalidInput(msg) = err {
                    proptest::prop_assert_eq!(msg, "Fusion weights must not be NaN");
                } else {
                    proptest::prop_assert!(false, "Expected InvalidInput for NaN");
                }
            } else if !v.is_finite() || !t.is_finite() || !g.is_finite() {
                proptest::prop_assert!(res.is_err());
            }
        }
    }

    #[test]
    fn test_context_window_serialization() {
        let chunk = ContextChunk {
            doc_id: DocId::new(1),
            content: "hello".to_string(),
            relevance: 1.0,
            token_count: 1,
            metadata: None,
            contextual_prefix: None,
            links: Vec::new(),
        };
        let window = ContextWindow {
            chunks: vec![chunk],
            total_tokens: 1,
            truncated: false,
        };
        let ser = serde_json::to_string(&window).unwrap(); // unwrap
        let deser: ContextWindow = serde_json::from_str(&ser).unwrap(); // unwrap
        assert_eq!(deser.total_tokens, 1);
        assert_eq!(deser.chunks.len(), 1);
        assert!(deser
            .chunks
            .first()
            .expect("chunk")
            .contextual_prefix
            .is_none());
    }

    #[test]
    fn test_combined_text_with_prefix() {
        let chunk = ContextChunk {
            doc_id: DocId::new(1),
            content: "Raw content".to_string(),
            relevance: 1.0,
            token_count: 2,
            metadata: None,
            contextual_prefix: Some("Dokument Kontext".to_string()),
            links: Vec::new(),
        };
        assert_eq!(
            chunk.combined_text_owned(),
            "Dokument Kontext\n\nRaw content"
        );
        assert!(chunk.has_context_prefix());
    }

    #[test]
    fn test_combined_text_without_prefix_returns_content() {
        let chunk = ContextChunk {
            doc_id: DocId::new(1),
            content: "Raw content".to_string(),
            relevance: 1.0,
            token_count: 2,
            metadata: None,
            contextual_prefix: None,
            links: Vec::new(),
        };
        assert_eq!(chunk.combined_text_owned(), "Raw content");
        assert!(!chunk.has_context_prefix());
    }

    #[test]
    fn test_combined_text_empty_prefix_returns_content() {
        let chunk = ContextChunk {
            doc_id: DocId::new(1),
            content: "Raw content".to_string(),
            relevance: 1.0,
            token_count: 2,
            metadata: None,
            contextual_prefix: Some("".to_string()),
            links: Vec::new(),
        };
        assert_eq!(chunk.combined_text_owned(), "Raw content");
        assert!(!chunk.has_context_prefix());
    }

    #[test]
    fn test_serde_backward_compat_no_prefix_field() {
        let json = r#"{"doc_id":1,"content":"X","relevance":0.5,"token_count":1}"#;
        let chunk: ContextChunk = serde_json::from_str(json).expect("deserialize"); // expect
        assert!(chunk.contextual_prefix.is_none());
    }

    #[test]
    fn test_combined_token_count_with_prefix() {
        let chunk_no_prefix = ContextChunk {
            doc_id: DocId::new(1),
            content: "Raw content".to_string(),
            relevance: 1.0,
            token_count: 10,
            metadata: None,
            contextual_prefix: None,
            links: Vec::new(),
        };
        assert_eq!(chunk_no_prefix.combined_token_count(), 10);

        let chunk_with_prefix = ContextChunk {
            doc_id: DocId::new(1),
            content: "Raw content".to_string(),
            relevance: 1.0,
            token_count: 10,
            metadata: None,
            contextual_prefix: Some("1234567812345678".to_string()), // 16 chars -> +4 tokens
            links: Vec::new(),
        };
        assert_eq!(chunk_with_prefix.combined_token_count(), 14);
        assert!(chunk_with_prefix.combined_token_count() > chunk_with_prefix.token_count);
    }

    #[test]
    fn test_hybrid_query_builder_all_options() {
        use crate::types::domain::MemoryType;
        use crate::types::filter::FilterExpr;
        use crate::types::saos::GraphTraversalStrategy;

        let filter = FilterExpr::Eq {
            field: "author".to_string(),
            value: serde_json::json!("Alice"),
        };

        let query = HybridQuery::builder()
            .with_text_query("knowledge graph")
            .with_vector_query(vec![0.5, 0.5])
            .with_graph_start_node("node_42")
            .with_graph_strategy(GraphTraversalStrategy::Hops { max_hops: 3 })
            .with_filter(filter.clone())
            .with_same_community_as(EntityId::new(100))
            .with_memory_type_filter(vec![MemoryType::Episodic, MemoryType::Semantic])
            .with_include_superseded(true)
            .with_k(25)
            .build()
            .expect("build hybrid query"); // expect

        assert_eq!(query.text_query.as_deref(), Some("knowledge graph"));
        assert_eq!(query.vector_query.as_deref(), Some(&[0.5, 0.5][..]));
        assert_eq!(query.graph_start_node.as_deref(), Some("node_42"));
        assert_eq!(
            query.graph_strategy,
            GraphTraversalStrategy::Hops { max_hops: 3 }
        );
        assert_eq!(query.filter, Some(filter));
        assert_eq!(query.same_community_as, Some(EntityId::new(100)));
        assert_eq!(
            query.memory_type_filter,
            Some(vec![MemoryType::Episodic, MemoryType::Semantic])
        );
        assert!(query.include_superseded);
        assert_eq!(query.k, 25);
    }
}
