//! # Integrationstest: Deep-Tests für Kalibrierung (Isotonisch, Platt)
//!
//! **Crate:** `contextra-rank`
//!
//! Prüft die Korrektheit, Stabilität und Invarianten der Ranking- und Kalibrierungskomponenten.

#![allow(clippy::unwrap_used, clippy::expect_used, clippy::panic)]
// ZWECK: Deep integration, proptest, and adversarial test suite for contextra-rank calibration.
// INVARIANTEN: INV-CAL-1 (no silent fallback before warmup), INV-CAL-2 (invalidation resets observations/weights), P8 compliance.

use contextra_rank::ConfigFingerprint;
use contextra_rank::{IsotonicCalibrator, PlattScaler};
use proptest::prelude::*;

// ============================================================================
// 1. ISOTONIC CALIBRATOR TESTS (PAVA & ECE)
// ============================================================================
#[test]
fn test_isotonic_warmup_invariant_inv_cal1() {
    let mut cal = IsotonicCalibrator::new(20, 100);
    for i in 0..19 {
        cal.record_outcome(i as f32 / 20.0, i % 2 == 0);
    }
    // INV-CAL-1: Must return None before warmup threshold is reached.
    assert!(cal.calibrated_probability(0.5).is_none());
    assert!(!cal.is_calibrated());

    // Record 20th observation to reach warmup
    cal.record_outcome(0.95, true);
    assert!(cal.is_calibrated());
    assert!(cal.calibrated_probability(0.5).is_some());
}

// Testet das erwartete Verhalten und mathematische Invarianten.
#[test]
fn test_isotonic_invalidation_invariant_inv_cal2() {
    let mut cal = IsotonicCalibrator::new(5, 100);
    for i in 0..10 {
        cal.record_outcome(i as f32 / 10.0, true);
    }
    assert_eq!(cal.observation_count(), 10);
    assert!(cal.is_calibrated());

    let fp1 = ConfigFingerprint::new("model-1", "Q4_0", "tmpl-1", 0.7);
    cal.invalidate_on_config_change(fp1.clone());

    // INV-CAL-2: Observations cleared, calibration status lost
    assert_eq!(cal.observation_count(), 0);
    assert!(!cal.is_calibrated());
    assert!(cal.calibrated_probability(0.5).is_none());

    // Passing the exact same fingerprint must NOT invalidate
    for i in 0..5 {
        cal.record_outcome(i as f32 / 5.0, true);
    }
    assert_eq!(cal.observation_count(), 5);
    cal.invalidate_on_config_change(fp1);
    assert_eq!(cal.observation_count(), 5);
}

// Testet das erwartete Verhalten und mathematische Invarianten.
#[test]
fn test_isotonic_pava_monotonicity_and_bounds() {
    let mut cal = IsotonicCalibrator::new(10, 100);
    let inputs = vec![
        (0.1, false),
        (0.9, true),
        (0.2, true),
        (0.8, false),
        (0.3, false),
        (0.7, true),
        (0.4, true),
        (0.6, false),
        (0.5, true),
        (0.55, true),
    ];
    for (score, outcome) in inputs {
        cal.record_outcome(score, outcome);
    }

    let test_scores = vec![0.0, 0.1, 0.25, 0.5, 0.75, 0.9, 1.0];
    let mut prev_prob = -1.0f32;

    for &score in &test_scores {
        let prob = cal.calibrated_probability(score).unwrap();
        assert!(
            (0.0..=1.0).contains(&prob),
            "Probability out of [0,1]: {prob}"
        );
        assert!(
            prob >= prev_prob - 1e-6,
            "PAVA monotonicity violated at score {score}: {prob} < {prev_prob}"
        );
        prev_prob = prob;
    }
}

// Testet das erwartete Verhalten und mathematische Invarianten.
#[test]
fn test_isotonic_ece_calculation() {
    let mut cal = IsotonicCalibrator::new(20, 200);

    // Before warmup ECE is None
    assert!(cal.expected_calibration_error().is_none());

    for i in 0..100 {
        let score = i as f32 / 100.0;
        let outcome = score > 0.5;
        cal.record_outcome(score, outcome);
    }

    let ece = cal.expected_calibration_error();
    assert!(ece.is_some());
    let ece_val = ece.unwrap();
    assert!(ece_val >= 0.0, "ECE must be non-negative");
    assert!(ece_val < 0.20, "ECE for well-behaved signal should be low");
}

// Testet das erwartete Verhalten und mathematische Invarianten.
#[test]
fn test_isotonic_nan_and_extreme_inputs() {
    let mut cal = IsotonicCalibrator::new(5, 50);
    for _ in 0..5 {
        cal.record_outcome(0.5, true);
    }

    // Lookup with NaN, infinity, or negative values
    let prob_nan = cal.calibrated_probability(f32::NAN);
    assert!(prob_nan.is_some());
    let prob_inf = cal.calibrated_probability(f32::INFINITY);
    assert!(prob_inf.is_some());
    let prob_neg_inf = cal.calibrated_probability(f32::NEG_INFINITY);
    assert!(prob_neg_inf.is_some());
}

// Testet das erwartete Verhalten und mathematische Invarianten.
#[test]
fn test_isotonic_duplicate_raw_score_pooling() {
    let mut cal = IsotonicCalibrator::new(4, 50);
    // Duplicate raw scores with conflicting outcomes
    cal.record_outcome(0.5, true);
    cal.record_outcome(0.5, false);
    cal.record_outcome(0.5, true);
    cal.record_outcome(0.5, false);

    // Warmup reached (4 obs)
    assert!(cal.is_calibrated());
    let prob = cal.calibrated_probability(0.5).unwrap();
    // Pre-aggregation merges all four score 0.5 obs into 1 block with avg 0.5
    assert!((prob - 0.5).abs() < 1e-5, "Expected 0.5, got {prob}");
}

// ============================================================================
// 2. PLATT SCALER TESTS
// ============================================================================

// Testet das erwartete Verhalten und mathematische Invarianten.
#[test]
fn test_platt_scaler_defaults_and_identity() {
    let scaler = PlattScaler::default();
    assert!(scaler.is_identity());
    assert!(!scaler.is_fitted());
    assert_eq!(scaler.params(), (1.0, 0.0));

    // sigmoid(0.0) = 0.5
    assert!((scaler.predict(0.0) - 0.5).abs() < 1e-6);
    assert!((scaler.apply(0.0) - 0.5).abs() < 1e-6);
    assert!((scaler.transform(0.0) - 0.5).abs() < 1e-6);
}

// Testet das erwartete Verhalten und mathematische Invarianten.
#[test]
fn test_platt_scaler_nan_logit_fallback() {
    let scaler = PlattScaler::new(2.0, 1.0);
    assert_eq!(scaler.transform(f32::NAN), 0.5);
    assert_eq!(scaler.predict(f32::NAN), 0.5);
}

// Testet das erwartete Verhalten und mathematische Invarianten.
#[test]
fn test_platt_scaler_fit_behavior() {
    // Empty observations -> returns identity
    let empty_scaler = PlattScaler::fit(&[]);
    assert!(empty_scaler.is_identity());

    // Single class positive
    let pos_obs = vec![(0.5, true), (0.8, true), (0.9, true)];
    let pos_scaler = PlattScaler::fit(&pos_obs);
    assert!(pos_scaler.predict(0.8) > 0.5);

    // Single class negative
    let neg_obs = vec![(-0.5, false), (-0.8, false), (-0.9, false)];
    let neg_scaler = PlattScaler::fit(&neg_obs);
    assert!(neg_scaler.predict(-0.8) < 0.5);
}

// Testet das erwartete Verhalten und mathematische Invarianten.
#[test]
fn test_platt_scaler_invalidation() {
    let mut scaler = PlattScaler::new(3.0, -1.0);
    assert!(!scaler.is_identity());

    let fp = ConfigFingerprint::new("model-a", "Q8_0", "tmpl-a", 0.1);
    scaler.invalidate_on_config_change(fp.clone());

    // Resets to identity (A=1.0, B=0.0)
    assert!(scaler.is_identity());
    assert_eq!(scaler.params(), (1.0, 0.0));
}

// ============================================================================
// 3. EDGE-CASE & ANTI-MIRRORING HARDENING TESTS
// ============================================================================

// Testet das erwartete Verhalten und mathematische Invarianten.
#[test]
fn test_isotonic_pava_block_merging_fluctuating_sequence() {
    let mut cal = IsotonicCalibrator::new(6, 100);
    // Non-monotone outcome sequence for strictly increasing raw scores
    let sequence = vec![
        (0.1, true),
        (0.2, false),
        (0.3, true),
        (0.4, false),
        (0.5, true),
        (0.6, false),
    ];
    for (score, outcome) in sequence {
        cal.record_outcome(score, outcome);
    }

    assert!(cal.is_calibrated());
    cal.force_rebuild();

    let p1 = cal.calibrated_probability(0.1).unwrap();
    let p2 = cal.calibrated_probability(0.3).unwrap();
    let p3 = cal.calibrated_probability(0.6).unwrap();

    assert!(p1 <= p2, "p1 ({p1}) must be <= p2 ({p2})");
    assert!(p2 <= p3, "p2 ({p2}) must be <= p3 ({p3})");
    assert!(
        (p2 - 0.5).abs() < 1e-5,
        "Expected 0.5 pooled average, got {p2}"
    );
}

// Testet das erwartete Verhalten und mathematische Invarianten.
#[test]
fn test_platt_scaler_gradient_clipping_and_extreme_logits() {
    let mut obs = Vec::new();
    for i in -50..=50 {
        let logit = i as f32 * 10.0;
        let outcome = logit > 0.0;
        obs.push((logit, outcome));
    }

    let scaler = PlattScaler::fit(&obs);
    assert!(scaler.is_fitted());
    let (a, b) = scaler.params();
    assert!(
        a.is_finite() && b.is_finite(),
        "Params must remain finite despite extreme logits"
    );

    let p_pos = scaler.predict(1000.0);
    let p_neg = scaler.predict(-1000.0);
    assert!(
        p_pos > 0.90,
        "Expected high confidence for large positive logit"
    );
    assert!(
        p_neg < 0.10,
        "Expected low confidence for large negative logit"
    );
}

// ============================================================================
// 4. PROPTEST PROPERTY TESTS
// ============================================================================

proptest! {
    // Testet das erwartete Verhalten und mathematische Invarianten.
    #[test]
    fn prop_platt_scaler_bounded_output(logit in -100.0f32..100.0f32, a in -5.0f32..5.0f32, b in -5.0f32..5.0f32) {
        let scaler = PlattScaler::new(a, b);
        let prob = scaler.transform(logit);
        prop_assert!((0.0..=1.0).contains(&prob), "Probability out of bounds: {}", prob);
    }
}
