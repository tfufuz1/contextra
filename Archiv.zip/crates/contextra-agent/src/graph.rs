// FILE-CONTEXT Header (Format v3)
// ZWECK: Declarative StateGraph definition routing workflow step transitions.
// INVARIANTEN: Distinct from contextra-graph::csr; validates node IDs, handler names, descriptions, and edge conditions.
// NICHT-OFFENSICHTLICH: try_add_node validates handler when present; add_node/add_edge marked #[deprecated].
// HOTSPOTS: try_add_node (ll. 60-110), try_add_edge (ll. 130-160).
// STAND: TS:2026-10-01T00:00:00Z (SESSION: 5a38054a)

//! Declarative StateGraph definition for Agent Workflows.

use crate::context::{validate_node_id, MAX_ID_LEN};
use crate::goal_condition::{parse_legacy_condition_string, GoalCondition};
use crate::step::StepResult;
use contextra_types::{ContextraError, Result};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

/// Type alias for node identifiers in the state graph.
pub type NodeId = String;

/// Maximum allowed length in bytes for descriptions and conditions.
pub const MAX_TEXT_LEN: usize = 65_536;

/// Type of node within the declarative agent state graph.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum NodeType {
    /// Initial workflow entry point node.
    Start,
    /// Operational task step executing a registered tool handler.
    Task,
    /// Conditional branching node evaluating context conditions.
    Decision,
    /// Terminal workflow exit node.
    End,
}

/// Represents a single specialized node in the workflow.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentNode {
    /// Unique identifier of the node.
    pub id: NodeId,
    /// Text description of the node's task or role.
    pub description: String,
    /// Functional type category of the node.
    pub node_type: NodeType,
    /// Registered name of the tool/function to execute, if applicable.
    pub handler: Option<String>,
}

/// Represents a conditional transition between two graph nodes.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WorkflowEdge {
    /// Origin node identifier of the transition.
    pub from: NodeId,
    /// Target node identifier of the transition.
    pub to: NodeId,
    /// Legacy text-based condition string (maintained for 100% backward compatibility).
    pub condition: Option<String>,
    /// Transition evaluation priority order (higher priority evaluated first).
    pub priority: u8,
    /// Structured GoalCondition for deterministic evaluation.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub goal: Option<GoalCondition>,
}

impl WorkflowEdge {
    /// Returns whether this edge has an explicit condition or goal attached.
    pub fn has_condition(&self) -> bool {
        self.goal.is_some()
            || self
                .condition
                .as_ref()
                .is_some_and(|c| !c.trim().is_empty())
    }

    /// Evaluates whether this edge's condition/goal is satisfied against a [`StepResult`].
    ///
    /// # Evaluation Order & Fail-Closed Semantics:
    /// 1. If `goal` is present, it is evaluated directly.
    /// 2. If `goal` is absent but a legacy `condition` string is present:
    ///    - Parses `condition` via [`parse_legacy_condition_string`].
    ///    - If parsing succeeds, evaluates the resulting [`GoalCondition`].
    ///    - If parsing fails (unparseable non-empty legacy string), fails closed (returns `false`)
    ///      and logs a warning via `tracing::warn!`.
    /// 3. If neither `goal` nor `condition` is present, returns `true` (unconditional edge).
    pub fn evaluate_condition(&self, result: &StepResult) -> bool {
        if let Some(ref goal) = self.goal {
            return goal.evaluate(result);
        }

        if let Some(ref cond_str) = self.condition {
            let trimmed = cond_str.trim();
            if trimmed.is_empty() {
                return true;
            }
            if let Some(goal) = parse_legacy_condition_string(trimmed) {
                return goal.evaluate(result);
            }
            tracing::warn!(
                from = %self.from,
                to = %self.to,
                condition = %cond_str,
                "WorkflowEdge legacy condition string could not be parsed into GoalCondition; failing closed (false)"
            );
            return false;
        }

        true
    }
}

/// Core declarative structure routing autonomous agent steps.
#[derive(Debug, Default, Clone, Serialize, Deserialize)]
pub struct StateGraph {
    /// Map of node identifiers to workflow nodes.
    pub nodes: BTreeMap<NodeId, AgentNode>,
    /// List of directional conditional transition edges.
    pub edges: Vec<WorkflowEdge>,
}

impl StateGraph {
    /// Creates a new empty [`StateGraph`].
    pub fn new() -> Self {
        Self::default()
    }

    /// Tries to insert a new node into the state graph after validating bounds.
    // AI-TAG[HARDENING][CRITICAL] RESOLVED: Validates non-empty Node ID and description for graph nodes. (TS:2026-08-30T15:00:19Z) (SESSION: 283abf0f)
    pub fn try_add_node(
        &mut self,
        id: &str,
        description: &str,
        node_type: NodeType,
        handler: Option<&str>,
    ) -> Result<()> {
        validate_node_id(id)?;

        if description.len() > MAX_TEXT_LEN {
            return Err(ContextraError::InvalidInput(format!(
                "Node description length {} exceeds maximum allowed length of {}",
                description.len(),
                MAX_TEXT_LEN
            )));
        }
        if description.contains('\0') {
            return Err(ContextraError::InvalidInput(
                "Node description cannot contain null bytes".to_string(),
            ));
        }
        if description.trim().is_empty() {
            return Err(contextra_types::ContextraError::InvalidInput(
                "StateGraph node description must not be empty".to_string(),
            ));
        }

        if let Some(h) = handler {
            if h.trim().is_empty() {
                return Err(ContextraError::InvalidInput(
                    "Node handler cannot be empty when provided".to_string(),
                ));
            }
            if h.len() > MAX_ID_LEN {
                return Err(ContextraError::InvalidInput(format!(
                    "Node handler length {} exceeds maximum allowed length of {}",
                    h.len(),
                    MAX_ID_LEN
                )));
            }
            if h.contains('\0') {
                return Err(ContextraError::InvalidInput(
                    "Node handler cannot contain null bytes".to_string(),
                ));
            }
        }

        self.nodes.insert(
            id.to_string(),
            AgentNode {
                id: id.to_string(),
                description: description.to_string(),
                node_type,
                handler: handler.map(|s| s.to_string()),
            },
        );
        Ok(())
    }

    /// Adds a node to the graph, panicking if validation fails.
    #[deprecated(note = "Use try_add_node instead to handle validation errors without panicking")]
    pub fn add_node(
        &mut self,
        id: &str,
        description: &str,
        node_type: NodeType,
        handler: Option<&str>,
    ) {
        if let Err(e) = self.try_add_node(id, description, node_type, handler) {
            tracing::warn!("StateGraph::add_node failed validation: {}", e);
        }
    }

    /// Tries to insert a new edge between nodes in the state graph after validating bounds.
    // AI-TAG[HARDENING][CRITICAL] RESOLVED: Validates non-empty from/to endpoints for workflow edges. (TS:2026-08-30T15:00:19Z) (SESSION: 283abf0f)
    pub fn try_add_edge(
        &mut self,
        from: &str,
        to: &str,
        condition: Option<&str>,
        priority: u8,
    ) -> Result<()> {
        validate_node_id(from)?;
        validate_node_id(to)?;

        let parsed_goal = condition.and_then(|c| parse_legacy_condition_string(c.trim()));

        if let Some(cond) = condition {
            if cond.len() > MAX_TEXT_LEN {
                return Err(ContextraError::InvalidInput(format!(
                    "Edge condition length {} exceeds maximum allowed length of {}",
                    cond.len(),
                    MAX_TEXT_LEN
                )));
            }
            if cond.contains('\0') {
                return Err(ContextraError::InvalidInput(
                    "Edge condition cannot contain null bytes".to_string(),
                ));
            }
        }

        self.edges.push(WorkflowEdge {
            from: from.to_string(),
            to: to.to_string(),
            condition: condition.map(|s| s.to_string()),
            priority,
            goal: parsed_goal,
        });
        Ok(())
    }

    /// Tries to insert a new edge with an explicit [`GoalCondition`].
    pub fn try_add_edge_with_goal(
        &mut self,
        from: &str,
        to: &str,
        goal: GoalCondition,
        priority: u8,
    ) -> Result<()> {
        validate_node_id(from)?;
        validate_node_id(to)?;

        self.edges.push(WorkflowEdge {
            from: from.to_string(),
            to: to.to_string(),
            condition: Some(goal.describe()),
            priority,
            goal: Some(goal),
        });
        Ok(())
    }

    /// Adds an edge to the graph, panicking if validation fails.
    #[deprecated(note = "Use try_add_edge instead to handle validation errors without panicking")]
    pub fn add_edge(&mut self, from: &str, to: &str, condition: Option<&str>, priority: u8) {
        if let Err(e) = self.try_add_edge(from, to, condition, priority) {
            tracing::warn!("StateGraph::add_edge failed validation: {}", e);
        }
    }

    /// Looks up a node by its identifier.
    pub fn get_node(&self, id: &str) -> Option<&AgentNode> {
        self.nodes.get(id)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_graph_add_node_validation() {
        let mut graph = StateGraph::new();
        assert!(graph
            .try_add_node("start", "Start Node", NodeType::Start, None)
            .is_ok());

        // Empty ID
        assert!(matches!(
            graph.try_add_node("", "desc", NodeType::Task, None),
            Err(ContextraError::InvalidInput(_))
        ));

        // Oversized description
        let huge_desc = "d".repeat(MAX_TEXT_LEN + 1);
        assert!(matches!(
            graph.try_add_node("task1", &huge_desc, NodeType::Task, None),
            Err(ContextraError::InvalidInput(_))
        ));

        // Empty handler name
        assert!(matches!(
            graph.try_add_node("task2", "desc", NodeType::Task, Some("")),
            Err(ContextraError::InvalidInput(_))
        ));
    }

    #[test]
    fn test_graph_add_edge_validation() {
        let mut graph = StateGraph::new();
        assert!(graph.try_add_edge("start", "end", None, 1).is_ok());

        // Null byte in endpoint
        assert!(matches!(
            graph.try_add_edge("start\0", "end", None, 1),
            Err(ContextraError::InvalidInput(_))
        ));

        // Oversized condition
        let huge_cond = "c".repeat(MAX_TEXT_LEN + 1);
        assert!(matches!(
            graph.try_add_edge("start", "end", Some(&huge_cond), 1),
            Err(ContextraError::InvalidInput(_))
        ));
    }
}
