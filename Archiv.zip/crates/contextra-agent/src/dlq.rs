// FILE-CONTEXT Header (Format v3)
// ZWECK: Persistent dead-letter queue storage abstraction for failed agent steps.
// INVARIANTEN: Key prefix "dlq:" for LSM prefix isolation; atomic put/delete operations.
// NICHT-OFFENSICHTLICH: drain reads all DLQ entries and deletes them atomically in a single batch transaction.
// HOTSPOTS: push (ll. 25-45), drain (ll. 50-80).
// STAND: TS:2026-09-06T11:18:35Z (SESSION: 820afd9c)

// AI-TAG[INVENTORY-DRIFT][MINOR] RESOLVED: AGT-AGENT-0399362d — Documented dlq.rs inventory drift in audit report. (TS: 2026-09-06T11:18:35Z) (SESSION: 820afd9c)

//! Persistent Dead-Letter-Queue for failed agent step executions.

use crate::step::StepDeadLetter;
use contextra_ports::StorageEngine;
use contextra_types::{ContextraError, Result, TxId};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;
use tokio::sync::OnceCell;

fn extract_tx_id(val: &serde_json::Value) -> Option<u64> {
    val.as_u64()
        .or_else(|| val.as_str().and_then(|s| s.parse::<u64>().ok()))
}

fn check_json_for_tx_id(val_bytes: &[u8], target_tx_id: u64) -> bool {
    if let Ok(meta) = serde_json::from_slice::<serde_json::Value>(val_bytes) {
        let tx_val = meta.get("tx_id").and_then(extract_tx_id).or_else(|| {
            meta.get("metadata")
                .and_then(|m| m.get("tx_id"))
                .and_then(extract_tx_id)
        });
        if let Some(tx_u64) = tx_val {
            if tx_u64 == target_tx_id {
                return true;
            }
        }
    }
    false
}

/// Persistente Dead-Letter-Queue für fehlgeschlagene Agent-Schritte.
/// Verwendet denselben Storage wie der Agent (LSM) mit einem fixen Key-Prefix.
pub struct DeadLetterQueue {
    storage: Arc<dyn StorageEngine>,
    next_tx: OnceCell<AtomicU64>,
    metrics_sink: Option<Arc<dyn contextra_ports::MetricsSink>>,
}

impl DeadLetterQueue {
    /// LSM key prefix used to isolate DLQ records.
    pub const PREFIX: &'static [u8] = b"dlq:";

    /// Constructs a new [`DeadLetterQueue`] backed by the provided storage engine.
    pub fn new(storage: Arc<dyn StorageEngine>) -> Self {
        Self {
            storage,
            next_tx: OnceCell::new(),
            metrics_sink: None,
        }
    }

    /// Attaches a metrics sink for DLQ gauge telemetry (Builder pattern).
    pub fn with_metrics_sink(mut self, sink: Arc<dyn contextra_ports::MetricsSink>) -> Self {
        self.metrics_sink = Some(sink);
        self
    }

    /// Helper constructor creating a [`DeadLetterQueue`] with an explicit metrics sink.
    pub fn new_with_metrics(
        storage: Arc<dyn StorageEngine>,
        sink: Arc<dyn contextra_ports::MetricsSink>,
    ) -> Self {
        Self {
            storage,
            next_tx: OnceCell::new(),
            metrics_sink: Some(sink),
        }
    }

    async fn report_depth(&self) -> Result<usize> {
        let letters = self.list().await?;
        Ok(letters.len())
    }

    /// Pushes a failed step record to the persistent Dead-Letter Queue.
    pub async fn push(&self, letter: &StepDeadLetter) -> Result<()> {
        let key = format!(
            "dlq:{}:{}:{}",
            letter.session_id, letter.node_id, letter.step_index
        );
        let value =
            serde_json::to_vec(letter).map_err(|e| ContextraError::Serialization(e.to_string()))?;

        let tx = self.allocate_tx().await?;
        if let Err(e) = self.storage.put(tx, key.as_bytes(), &value).await {
            if let Err(rollback_err) = self.storage.rollback(tx).await {
                tracing::error!(error = %rollback_err, "Failed to rollback transaction after put failure in DLQ");
            }
            return Err(e);
        }
        if let Err(e) = self.storage.commit(tx).await {
            if let Err(rollback_err) = self.storage.rollback(tx).await {
                tracing::error!(error = %rollback_err, "Failed to rollback transaction after commit failure in DLQ");
            }
            return Err(e);
        }
        self.report_depth().await?;
        Ok(())
    }

    /// Reads and removes all dead-letter records atomically from storage.
    pub async fn drain(&self) -> Result<Vec<StepDeadLetter>> {
        let entries = self.storage.scan_prefix(Self::PREFIX).await?;
        let mut letters = Vec::with_capacity(entries.len());
        let mut keys_to_delete = Vec::with_capacity(entries.len());

        for (key, val) in entries {
            let letter: StepDeadLetter = serde_json::from_slice(&val)
                .map_err(|e| ContextraError::Serialization(e.to_string()))?;
            letters.push(letter);
            keys_to_delete.push(key);
        }

        if !keys_to_delete.is_empty() {
            let tx = self.allocate_tx().await?;
            if let Err(e) = self.storage.delete_many(tx, keys_to_delete).await {
                if let Err(rollback_err) = self.storage.rollback(tx).await {
                    tracing::error!(error = %rollback_err, "Failed to rollback transaction after delete_many failure in DLQ");
                }
                return Err(e);
            }
            if let Err(e) = self.storage.commit(tx).await {
                if let Err(rollback_err) = self.storage.rollback(tx).await {
                    tracing::error!(error = %rollback_err, "Failed to rollback transaction after commit failure in DLQ");
                }
                return Err(e);
            }
        }

        if let Some(ref sink) = self.metrics_sink {
            sink.record_gauge("dlq_depth", 0.0, &[]);
        }

        Ok(letters)
    }

    /// Lists all current dead-letter records without removing them.
    pub async fn list(&self) -> Result<Vec<StepDeadLetter>> {
        let entries = self.storage.scan_prefix(Self::PREFIX).await?;
        let mut letters = Vec::with_capacity(entries.len());

        for (_key, val) in entries {
            let letter: StepDeadLetter = serde_json::from_slice(&val)
                .map_err(|e| ContextraError::Serialization(e.to_string()))?;
            letters.push(letter);
        }

        if let Some(ref sink) = self.metrics_sink {
            sink.record_gauge("dlq_depth", letters.len() as f64, &[]);
        }

        Ok(letters)
    }

    /// Entfernt einen spezifischen DLQ-Eintrag anhand seines `(session_id, node_id, step_index)` Schlüssels.
    pub async fn remove(&self, letter: &StepDeadLetter) -> Result<bool> {
        let key = format!(
            "dlq:{}:{}:{}",
            letter.session_id, letter.node_id, letter.step_index
        );
        let tx = self.allocate_tx().await?;
        if let Err(e) = self.storage.delete(tx, key.as_bytes()).await {
            if let Err(rollback_err) = self.storage.rollback(tx).await {
                tracing::error!(error = %rollback_err, "Failed to rollback transaction after delete failure in DLQ");
            }
            return Err(e);
        }
        if let Err(e) = self.storage.commit(tx).await {
            if let Err(rollback_err) = self.storage.rollback(tx).await {
                tracing::error!(error = %rollback_err, "Failed to rollback transaction after commit failure in DLQ");
            }
            return Err(e);
        }
        self.report_depth().await?;
        Ok(true)
    }

    /// Prüft vor dem Replay eines DLQ-Eintrags, ob die im Eintrag assoziierte `TxId`
    /// bereits im WAL/Storage für denselben `(Session, Node, Step)`-Schlüssel committet ist.
    ///
    /// Gibt `Ok(true)` zurück, falls das Event bereits erfolgreich committet wurde (Replay = No-Op).
    /// Gibt `Ok(false)` zurück, falls das Event noch nicht committet wurde und neu ausgeführt werden muss.
    pub async fn is_already_committed(&self, letter: &StepDeadLetter) -> Result<bool> {
        let letter_tx_id = match letter.tx_id {
            Some(tx) => tx,
            None => return Ok(false),
        };

        let state_doc_id = format!("task:{}:step:{}", letter.session_id, letter.step_index);
        let audit_id = format!("audit:{}:step:{}", letter.session_id, letter.step_index);

        for doc_id in [&state_doc_id, &audit_id] {
            if let Ok(Some(val_bytes)) = self.storage.get(doc_id.as_bytes()).await {
                if check_json_for_tx_id(&val_bytes, letter_tx_id.0) {
                    return Ok(true);
                }
            }
            let namespaced_doc_key = format!("__col:agent:\x000{}", doc_id);
            if let Ok(Some(val_bytes)) = self.storage.get(namespaced_doc_key.as_bytes()).await {
                if check_json_for_tx_id(&val_bytes, letter_tx_id.0) {
                    return Ok(true);
                }
            }
        }

        let entries = self.storage.scan_prefix(b"").await?;
        for (k, val_bytes) in entries {
            let key_str = String::from_utf8_lossy(&k);
            if (key_str.contains(&state_doc_id) || key_str.contains(&audit_id))
                && check_json_for_tx_id(&val_bytes, letter_tx_id.0)
            {
                return Ok(true);
            }
        }

        Ok(false)
    }

    /// Allocates a unique sequence transaction ID for DLQ storage mutations.
    pub async fn allocate_tx(&self) -> Result<TxId> {
        let counter = self
            .next_tx
            .get_or_try_init(|| async {
                let last_tx = self.storage.last_tx_id().await?.0;
                Ok::<AtomicU64, ContextraError>(AtomicU64::new(last_tx + 1))
            })
            .await?;

        // AI-TAG[SMELL][MINOR] RESOLVED: AGT-AGENT-49bfd02e — Replaced non-atomic last_tx_id + 1 read with OnceCell initialized AtomicU64 fetch_add. (TS: 2026-09-11T14:30:00Z)
        let tx_val = counter.fetch_add(1, Ordering::SeqCst);
        Ok(TxId::new(tx_val))
    }
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used)]
mod tests {
    use super::*;
    use crate::step::DeadLetterReason;
    use contextra_testkit::InMemoryStorageEngine;

    #[tokio::test]
    async fn test_dlq_push_list_drain() -> Result<()> {
        let storage = Arc::new(InMemoryStorageEngine::new());
        let dlq = DeadLetterQueue::new(storage);

        let letter1 = StepDeadLetter {
            session_id: "sess-1".to_string(),
            node_id: "node-a".to_string(),
            step_index: 0,
            tx_id: None,
            failure_reason: DeadLetterReason::Timeout { timeout_ms: 5000 },
            input: serde_json::json!({"query": "test"}),
            attempt: 0,
            failed_at_secs: 1000,
        };

        let letter2 = StepDeadLetter {
            session_id: "sess-1".to_string(),
            node_id: "node-b".to_string(),
            step_index: 1,
            tx_id: None,
            failure_reason: DeadLetterReason::ToolError {
                message: "Tool failed".to_string(),
            },
            input: serde_json::json!({"action": "exec"}),
            attempt: 1,
            failed_at_secs: 1005,
        };

        dlq.push(&letter1).await?;
        dlq.push(&letter2).await?;

        let listed = dlq.list().await?;
        assert_eq!(listed.len(), 2);

        let drained = dlq.drain().await?;
        assert_eq!(drained.len(), 2);

        let listed_after_drain = dlq.list().await?;
        assert!(listed_after_drain.is_empty());
        Ok(())
    }

    #[tokio::test]
    async fn test_dlq_allocate_tx_uniqueness() -> Result<()> {
        let storage = Arc::new(InMemoryStorageEngine::new());
        let dlq = DeadLetterQueue::new(storage);

        let tx1 = dlq.allocate_tx().await?;
        let tx2 = dlq.allocate_tx().await?;
        assert_ne!(tx1, tx2);
        Ok(())
    }

    #[tokio::test]
    async fn test_dlq_metrics_gauge_depth() -> Result<()> {
        use contextra_testkit::{MetricEvent, TestMetricsSink};

        let storage = Arc::new(InMemoryStorageEngine::new());
        let metrics = Arc::new(TestMetricsSink::new());
        let dlq = DeadLetterQueue::new(storage)
            .with_metrics_sink(metrics.clone() as Arc<dyn contextra_ports::MetricsSink>);

        let letter1 = StepDeadLetter {
            session_id: "sess-1".to_string(),
            node_id: "node-a".to_string(),
            step_index: 0,
            tx_id: None,
            failure_reason: DeadLetterReason::Timeout { timeout_ms: 5000 },
            input: serde_json::json!({"query": "test"}),
            attempt: 0,
            failed_at_secs: 1000,
        };

        let letter2 = StepDeadLetter {
            session_id: "sess-1".to_string(),
            node_id: "node-b".to_string(),
            step_index: 1,
            tx_id: None,
            failure_reason: DeadLetterReason::ToolError {
                message: "Tool failed".to_string(),
            },
            input: serde_json::json!({"action": "exec"}),
            attempt: 1,
            failed_at_secs: 1005,
        };

        // 1. Push letter1 -> Gauge depth = 1.0
        dlq.push(&letter1).await?;
        let events = metrics.events();
        assert!(!events.is_empty());
        let last_event = events.last().cloned().unwrap();
        assert_eq!(
            last_event,
            MetricEvent::Gauge {
                name: "dlq_depth".to_string(),
                value: 1.0,
                labels: vec![],
            }
        );

        // 2. Push letter2 -> Gauge depth = 2.0
        metrics.clear();
        dlq.push(&letter2).await?;
        let events = metrics.events();
        let last_event = events.last().cloned().unwrap();
        assert_eq!(
            last_event,
            MetricEvent::Gauge {
                name: "dlq_depth".to_string(),
                value: 2.0,
                labels: vec![],
            }
        );

        // 3. Remove letter1 -> Gauge depth = 1.0
        metrics.clear();
        let removed = dlq.remove(&letter1).await?;
        assert!(removed);
        let events = metrics.events();
        let last_event = events.last().cloned().unwrap();
        assert_eq!(
            last_event,
            MetricEvent::Gauge {
                name: "dlq_depth".to_string(),
                value: 1.0,
                labels: vec![],
            }
        );

        // 4. Drain remaining -> Gauge depth = 0.0
        metrics.clear();
        let drained = dlq.drain().await?;
        assert_eq!(drained.len(), 1);
        let events = metrics.events();
        let last_event = events.last().cloned().unwrap();
        assert_eq!(
            last_event,
            MetricEvent::Gauge {
                name: "dlq_depth".to_string(),
                value: 0.0,
                labels: vec![],
            }
        );

        Ok(())
    }

    #[tokio::test]
    async fn test_dlq_new_with_metrics_constructor() -> Result<()> {
        use contextra_testkit::TestMetricsSink;
        let storage = Arc::new(InMemoryStorageEngine::new());
        let metrics = Arc::new(TestMetricsSink::new());
        let dlq = DeadLetterQueue::new_with_metrics(storage, metrics);
        let list = dlq.list().await?;
        assert!(list.is_empty());
        Ok(())
    }
}
